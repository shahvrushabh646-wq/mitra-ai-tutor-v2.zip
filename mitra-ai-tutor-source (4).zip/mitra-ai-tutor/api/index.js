// server.ts
import "dotenv/config";
import fs4 from "node:fs";
import path4 from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import multer from "multer";

// server/aiProvider.ts
import fs from "node:fs";
import path from "node:path";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

// server/offlineTutor.ts
var OFFLINE_CMAT_LESSONS = [
  {
    id: "quant_ratio_prop",
    section: "Quantitative Techniques & DI",
    title: "Ratio, Proportion & Mixtures",
    keywords: ["ratio", "proportion", "mixture", "alligation", "continue", "aage", "anupat"],
    hinglishSummary: `**Zero se samajhte hain (Cafe-style):** Ratio bas do quantities ka fair comparison (hissa) hota hai. Jab $A : B$ aur $B : C$ alag-alag diye hon, toh beech wale common member **$B$** ko LCM lekar barabar bana do!`,
    stepByStepExample: `1. **Chained Ratio Merge:** Suppose $A : B = 2 : 3$ and $B : C = 4 : 5$.
   - Common term $B$ ke numbers hain $3$ aur $4$. $\\text{LCM}(3, 4) = 12$.
   - First ratio $\\times 4 \\Rightarrow 8 : 12$. Second ratio $\\times 3 \\Rightarrow 12 : 15$.
   - Combined: **$A : B : C = 8 : 12 : 15$**.
2. **Fractional Ratio Shortcut (NTA CMAT 2025 Slot 1 Q.9):**
   - Ratio $\\frac{1}{2} : \\frac{1}{3} : \\frac{1}{5} : \\frac{1}{8}$ ko whole numbers mein badalne ke liye $\\text{LCM}(2, 3, 5, 8) = 120$ se multiply karo:
   - $60 : 40 : 24 : 15 \\Rightarrow$ Minimum whole items $= 60 + 40 + 24 + 15 = 139$.`,
    checkQuestion: `**1-Question Try Check:** Agar $A : B = 3 : 5$ aur $B : C = 10 : 7$ hai, toh combined ratio $A : B : C$ kya hoga?
(A) 3 : 10 : 7
(B) 6 : 10 : 7
(C) 6 : 15 : 7
(D) 30 : 50 : 70`,
    followups: ["(B) 6 : 10 : 7", "Hint dikhao bina answer ke", "Live AI dubara try karo"]
  },
  {
    id: "quant_profit_pct",
    section: "Quantitative Techniques & DI",
    title: "Percentages, Profit & Loss & SI/CI",
    keywords: ["percent", "profit", "loss", "discount", "interest", "ci", "si", "markup"],
    hinglishSummary: `**Core Rule:** Profit% aur Loss% hamesha **Cost Price (CP)** par nikalta hai, jabki Discount% hamesha **Marked Price (MP)** par lagta hai! Successive change ke liye $a + b + \\frac{ab}{100}$ lagao.`,
    stepByStepExample: `1. **Reverse Percentage:** Agar kisi item ka price $+25\\%$ ($+\\frac{1}{4}$) badh gaya ($4 \\rightarrow 5$), toh wapas purane kharche par aane ke liye $\\frac{1}{5} = 20\\%$ kam karna padega.
2. **Markup + Discount Formula:**
   $$\\frac{\\text{CP}}{\\text{MP}} = \\frac{100 - \\text{Discount\\%}}{100 + \\text{Profit\\%}}$$
   - Example: $20\\%$ discount dekar bhi $12\\%$ profit chahiye $\\Rightarrow \\frac{\\text{CP}}{\\text{MP}} = \\frac{80}{112} = \\frac{5}{7}$ (Markup $= \\frac{2}{5} = 40\\%$).
3. **2-Year CI vs SI Shortcut:** Difference $= P \\left(\\frac{R}{100}\\right)^2$.`,
    checkQuestion: `**1-Question Try Check:** Ek shopkeeper CP se $50\\%$ upar MP rakhta hai aur $20\\%$ discount deta hai. Uska net profit percentage kitna hai?
(A) 30%
(B) 25%
(C) 20%
(D) 15%`,
    followups: ["(C) 20%", "Step-by-step hint do", "Time & Work sikhana"]
  },
  {
    id: "quant_tsd_work",
    section: "Quantitative Techniques & DI",
    title: "Time & Work + Time, Speed & Distance",
    keywords: ["work", "speed", "distance", "train", "boat", "race", "efficiency", "pipe"],
    hinglishSummary: `**LCM Total Work Trick:** Fractions ($1/12 + 1/15$) se bacho! Days ka LCM lekar "Total Chocolates / Units" maan lo \u2014 har step integer mein solve hoga.`,
    stepByStepExample: `1. **Time & Work:** $A$ finishes in $12$ days, $B$ in $15$ days.
   - Total Work $= \\text{LCM}(12, 15) = 60$ units.
   - Efficiency: $A = 60/12 = 5$ units/day; $B = 60/15 = 4$ units/day.
   - Together $= 5 + 4 = 9$ units/day $\\Rightarrow \\text{Time} = \\frac{60}{9} = 6\\frac{2}{3}$ days.
2. **Average Speed (Equal Distance):** $\\text{Avg Speed} = \\frac{2xy}{x + y}$ (kabhi $\\frac{x+y}{2}$ mat lagana!).`,
    checkQuestion: `**1-Question Try Check:** Car $A\\rightarrow B$ $40\\text{ km/h}$ se jaati hai aur $B\\rightarrow A$ $60\\text{ km/h}$ se wapas aati hai. Round-trip average speed kya hai?
(A) 50 km/h
(B) 48 km/h
(C) 45 km/h
(D) 52 km/h`,
    followups: ["(B) 48 km/h", "Ratio lesson dikhao", "Live AI retry karo"]
  },
  {
    id: "lr_series_coding",
    section: "Logical Reasoning",
    title: "Number Series, Coding-Decoding & Arrangements",
    keywords: ["series", "coding", "decoding", "direction", "seating", "blood", "syllogism", "logical", "reasoning", "mistake"],
    hinglishSummary: `**CMAT LR Golden Checklist:** Number series mein pehle **difference** check karo; agar numbers tezi se badhein ($>2\\times$) toh **multiplication + offset** check karo; aur $64, 125, 216, 343$ ke aas-paas hamesha **$n^3 \\pm k$** dekho!`,
    stepByStepExample: `1. **Cube Offset Pattern (Day 1 Error Log Concept):**
   - Series: $0, 7, 26, 63, 124, ?$
   - Notice: $1^3 - 1 = 0,\\; 2^3 - 1 = 7,\\; 3^3 - 1 = 26,\\; 4^3 - 1 = 63,\\; 5^3 - 1 = 124$.
   - Next term $= 6^3 - 1 = 216 - 1 = \\mathbf{215}$.
2. **Alphabet Coding (EJOTY + Opposite Pairs):**
   - EJOTY $= 5, 10, 15, 20, 25$. Opposite letters ka sum hamesha **$27$** hota hai ($A(1)+Z(26)=27$, $M(13)+N(14)=27$).`,
    checkQuestion: `**1-Question Try Check:** Find the next term in the series: $2, 9, 28, 65, 126, ?$
(A) 197
(B) 215
(C) 217
(D) 225`,
    followups: ["(C) 217", "Grammar rules dikhao", "Live AI retry karo"]
  },
  {
    id: "lang_verbal",
    section: "Language Comprehension",
    title: "Grammar, Fixed Prepositions, Voice & RC Strategy",
    keywords: ["grammar", "english", "language", "preposition", "article", "voice", "narration", "passage", "rc", "vocab", "idiom"],
    hinglishSummary: `**CMAT Verbal High-Yield Trap:** Active-Passive mein har jagah *"by"* nahi aata \u2014 kuch verbs apna fixed preposition lete hain (*known to*, *pleased with*, *contained in*, *surprised at*).`,
    stepByStepExample: `1. **Fixed Prepositions:**
   - *Senior / Junior / Superior / Prefer* ke baad **"than"** nahi, hamesha **"to"** aata hai (*"He prefers tea to coffee"*).
2. **Subject-Verb Agreement:**
   - *"Neither of"*, *"Each of"*, *"One of"* ke baad **plural noun** aata hai par **singular verb** lagta hai: *"One of the students **is** absent."*
3. **RC Elimination Rule:** Extreme words (*always, never, only, completely*) waale options CMAT inference questions mein 90% galat hote hain jab tak passage mein explicitly na likha ho.`,
    checkQuestion: `**1-Question Try Check:** Spot the correct sentence:
(A) She is senior than me by two years.
(B) One of my friend are coming today.
(C) I prefer walking to cycling.
(D) The box is contained by five books.`,
    followups: ["(C) I prefer walking to cycling.", "GK Polity notes dikhao", "Live AI retry karo"]
  },
  {
    id: "gk_polity_econ",
    section: "General Knowledge",
    title: "Indian Constitution, Economy (RBI) & Static GK",
    keywords: ["gk", "constitution", "polity", "article", "president", "economy", "rbi", "repo", "amendment", "general knowledge"],
    hinglishSummary: `**CMAT Static GK Anchor:** Polity Articles, Constitutional Amendments, aur RBI Monetary Policy har saal CMAT Slot 1 & Slot 2 dono mein puchte hain!`,
    stepByStepExample: `1. **Constitution Milestones:**
   - Adopted: **26 Nov 1949** \xB7 Enforced: **26 Jan 1950** \xB7 Drafting Committee Chair: **Dr. B. R. Ambedkar**.
   - **42nd Amendment (1976):** Added *Socialist, Secular, Integrity* & **Fundamental Duties (Part IV-A, Art. 51A)** on Swaran Singh Committee recommendation.
   - **Article 32:** Right to Constitutional Remedies (*"Heart & Soul"*).
2. **RBI Monetary Tools:**
   - **Repo Rate:** Rate at which RBI lends short-term funds to commercial banks (inflation rokne ke liye RBI Repo Rate badhata hai).`,
    checkQuestion: `**1-Question Try Check:** Under which Article of the Indian Constitution can a citizen directly move the Supreme Court for enforcement of Fundamental Rights?
(A) Article 19
(B) Article 21
(C) Article 32
(D) Article 226`,
    followups: ["(C) Article 32", "Entrepreneurship basics dikhao", "Live AI retry karo"]
  },
  {
    id: "ent_innovation",
    section: "Innovation & Entrepreneurship",
    title: "Startup Funding Lifecycle, Lean MVP & IPR",
    keywords: ["innovation", "entrepreneur", "startup", "bootstrapping", "angel", "venture", "mvp", "patent", "ipr", "unicorn"],
    hinglishSummary: `**Startup Journey ek line mein:** Khud ki jeb se shuruat = **Bootstrapping** $\\rightarrow$ Early wealthy individual = **Angel Investor** $\\rightarrow$ Institutional high-growth fund = **Venture Capital (VC)** $\\rightarrow$ Public listing = **IPO**.`,
    stepByStepExample: `1. **Lean Startup Terms (Eric Ries):**
   - **MVP (Minimum Viable Product):** Sabse basic working version launch karna taaki real customers ka feedback jaldi mile.
   - **Pivot:** Customer feedback ke baad product strategy ya business model mein smart direction change karna.
2. **Intellectual Property Rights (IPR) in India:**
   - **Patent:** Novel invention ke liye (**20 years** protection).
   - **Trademark:** Brand logo/name ke liye (**10 years**, indefinitely renewable).
   - **Copyright:** Literary/artistic/software code ke liye.`,
    checkQuestion: `**1-Question Try Check:** Starting a company using personal savings and early customer revenue without external investor equity is called:
(A) Venture Capital
(B) Crowdfunding
(C) Bootstrapping
(D) Incubating`,
    followups: ["(C) Bootstrapping", "Ratio & Proportion padhao", "Live AI retry karo"]
  }
];
function selectBestOfflineModule(userMessage, ctx) {
  const haystack = `${userMessage} ${ctx.currentTopicTitle} ${ctx.currentSubject}`.toLowerCase();
  const directUserLower = userMessage.toLowerCase();
  for (const mod of OFFLINE_CMAT_LESSONS) {
    if (mod.keywords.some((kw) => directUserLower.includes(kw))) {
      return mod;
    }
  }
  for (const mod of OFFLINE_CMAT_LESSONS) {
    if (mod.keywords.some((kw) => haystack.includes(kw))) {
      return mod;
    }
  }
  return OFFLINE_CMAT_LESSONS[0];
}
function buildStructuredOfflineFallback(userMessage, ctx, reason) {
  const chosen = selectBestOfflineModule(userMessage, ctx);
  const content = `> **Offline Tutor Fallback Active (Not Live AI)**
> Live AI could not complete this turn (*${reason}*).
> **What works offline:** Curated CMAT lessons, formulas, worked examples, all timed quizzes & mock exams, flashcards, and your Error Log.
> **Offline limitations:** Cannot dynamically read newly uploaded PDFs or generate freeform custom essays until Live AI reconnects.

### ${chosen.section}: ${chosen.title}

${chosen.hinglishSummary}

#### Step-by-Step Worked Notes
${chosen.stepByStepExample}

---

${chosen.checkQuestion}

*Active Study State Preserved:* Day ${ctx.currentDay} \xB7 ${ctx.currentSubject} (${ctx.currentTopicTitle})

<<<FOLLOWUPS: ${JSON.stringify(chosen.followups)}>>>`;
  return {
    content,
    errorReason: reason
  };
}

// server/aiProvider.ts
var DEPRECATED_MODELS = /* @__PURE__ */ new Set([
  "gemini-1.5-flash",
  "gemini-1.5-pro",
  "gemini-pro",
  "gemini-2.0-flash",
  "gemini-2.0-pro",
  "gemini-2.0-flash-thinking"
]);
var FAST_CONVERSATIONAL_MODEL = "gemini-3.1-flash-lite";
var THINKING_TUTOR_MODEL = "gemini-3.8-flash";
var DEFAULT_SUPPORTED_MODEL = FAST_CONVERSATIONAL_MODEL;
var FALLBACK_MODEL_CHAIN = [
  FAST_CONVERSATIONAL_MODEL,
  THINKING_TUTOR_MODEL,
  "gemini-flash-latest"
];
var PRESET_PAPER_PATHS = {
  cmat_2025_slot_1: {
    filePath: path.resolve(process.cwd(), "public/assets/aistudio/CMAT_2025_Slot_1_eb37672b.pdf"),
    mimeType: "application/pdf",
    label: "NTA CMAT Jan 2025 Slot 1 Official Paper (25 Jan 2025, 9 AM - 12 PM)"
  },
  cmat_2025_slot_2: {
    filePath: path.resolve(process.cwd(), "public/assets/aistudio/CMAT_2025_Slot_2_10460396.pdf"),
    mimeType: "application/pdf",
    label: "NTA CMAT Jan 2025 Slot 2 Official Paper (25 Jan 2025, 3 PM - 6 PM)"
  }
};
var pdfBase64Cache = /* @__PURE__ */ new Map();
var modelCooldownMap = /* @__PURE__ */ new Map();
var cachedLiveProbe = null;
function markModelCooldown(modelName, cooldownMs, category, reason) {
  if (cooldownMs <= 0) return;
  modelCooldownMap.set(modelName, {
    untilMs: Date.now() + cooldownMs,
    category,
    reason
  });
}
function isModelInCooldown(modelName) {
  const entry = modelCooldownMap.get(modelName);
  if (!entry) return false;
  if (Date.now() >= entry.untilMs) {
    modelCooldownMap.delete(modelName);
    return false;
  }
  return true;
}
function getActiveCooldownModels() {
  const active = [];
  const now = Date.now();
  for (const [m, entry] of modelCooldownMap.entries()) {
    if (now < entry.untilMs) {
      active.push(m);
    } else {
      modelCooldownMap.delete(m);
    }
  }
  return active;
}
function getApiKey() {
  return (process.env.GEMINI_API_KEY || "").trim();
}
function resolveModelConfig() {
  const configuredRaw = (process.env.GEMINI_MODEL || process.env.MODEL || "").trim();
  if (!configuredRaw) {
    return {
      configuredRaw: DEFAULT_SUPPORTED_MODEL,
      activeModel: DEFAULT_SUPPORTED_MODEL,
      wasNormalizedFromDeprecated: false
    };
  }
  const lower = configuredRaw.toLowerCase();
  if (DEPRECATED_MODELS.has(lower)) {
    return {
      configuredRaw,
      activeModel: DEFAULT_SUPPORTED_MODEL,
      wasNormalizedFromDeprecated: true
    };
  }
  return {
    configuredRaw,
    activeModel: configuredRaw,
    wasNormalizedFromDeprecated: false
  };
}
function classifyProviderError(err) {
  const raw = err instanceof Error ? err.message : String(err);
  const lower = raw.toLowerCase();
  if (raw.includes("401") || raw.includes("403") || lower.includes("api_key_invalid") || lower.includes("api key not valid") || lower.includes("permission_denied") || lower.includes("unauthenticated")) {
    return {
      category: "auth_invalid",
      userMessage: "Live AI authentication failed. Check that GEMINI_API_KEY in Settings > Secrets is valid and active.",
      isRetryableSameModel: false,
      shouldFailoverModel: false,
      cooldownMs: 0
    };
  }
  if (raw.includes("404") || lower.includes("not_found") || lower.includes("not found") || lower.includes("is not supported for generatecontent") || lower.includes("unsupported model")) {
    return {
      category: "model_unsupported",
      userMessage: "The requested model is unavailable for this API key/region; switching to a verified supported model.",
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 15 * 60 * 1e3
      // 15-minute circuit breaker cooldown so we don't retry dead models
    };
  }
  if (raw.includes("429") || lower.includes("resource_exhausted") || lower.includes("quota") || lower.includes("rate limit")) {
    return {
      category: "quota_exhausted",
      userMessage: "Gemini API quota or rate limit reached on this model. Failing over or cooling down briefly before retry.",
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 60 * 1e3
      // 60-second cooldown on rate-limited model
    };
  }
  if (lower.includes("timed out") || lower.includes("timeout") || lower.includes("deadline_exceeded") || lower.includes("aborted")) {
    return {
      category: "timeout",
      userMessage: "Live AI model timed out waiting for response; switching to faster backup model.",
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 30 * 1e3
    };
  }
  return {
    category: "network_error",
    userMessage: raw.slice(0, 220) || "Temporary network interruption reaching the AI provider.",
    isRetryableSameModel: true,
    shouldFailoverModel: true,
    cooldownMs: 10 * 1e3
  };
}
function getAIProviderStatus() {
  const apiKey = getApiKey();
  const hasValidKey = Boolean(apiKey && apiKey !== "MY_GEMINI_API_KEY");
  const { configuredRaw, activeModel, wasNormalizedFromDeprecated } = resolveModelConfig();
  const cooldownModels = getActiveCooldownModels();
  if (!hasValidKey) {
    return {
      liveAvailable: false,
      verifiedLive: false,
      errorCategory: "missing_key",
      cooldownModels,
      provider: "Google Gemini (@google/genai)",
      configuredModel: configuredRaw,
      activeModel,
      endpointType: "Server-side SSE Stream & Voice Adapter (/api/chat/stream)",
      authConfigured: false,
      fallbackModeLabel: "Offline Tutor Fallback",
      diagnosticMessage: "GEMINI_API_KEY is not configured on the server. Structured Offline Tutor mode is active until a key is attached in Settings > Secrets."
    };
  }
  if (cachedLiveProbe && Date.now() < cachedLiveProbe.expiresAtMs) {
    return {
      liveAvailable: cachedLiveProbe.verifiedLive,
      verifiedLive: cachedLiveProbe.verifiedLive,
      lastVerifiedAt: cachedLiveProbe.lastVerifiedAt,
      probeLatencyMs: cachedLiveProbe.probeLatencyMs,
      errorCategory: cachedLiveProbe.errorCategory,
      cooldownModels,
      provider: "Google Gemini (@google/genai)",
      configuredModel: configuredRaw,
      activeModel: cachedLiveProbe.verifiedModel || activeModel,
      endpointType: "Server-side SSE Stream & Voice Adapter (/api/chat/stream)",
      authConfigured: cachedLiveProbe.errorCategory !== "auth_invalid",
      fallbackModeLabel: "Offline Tutor Fallback",
      diagnosticMessage: cachedLiveProbe.diagnosticMessage
    };
  }
  const candidateChain = Array.from(/* @__PURE__ */ new Set([activeModel, ...FALLBACK_MODEL_CHAIN]));
  const healthyModel = candidateChain.find((m) => !isModelInCooldown(m)) || activeModel;
  let diagnosticMessage = `Live AI configured via @google/genai (${healthyModel}). Click "Verify Live AI" to run a real API probe.`;
  if (wasNormalizedFromDeprecated) {
    diagnosticMessage = `Deprecated model "${configuredRaw}" was normalized to supported model "${healthyModel}".`;
  }
  return {
    liveAvailable: true,
    verifiedLive: cachedLiveProbe?.verifiedLive,
    lastVerifiedAt: cachedLiveProbe?.lastVerifiedAt,
    probeLatencyMs: cachedLiveProbe?.probeLatencyMs,
    errorCategory: "none",
    cooldownModels,
    provider: "Google Gemini (@google/genai)",
    configuredModel: configuredRaw,
    activeModel: healthyModel,
    endpointType: "Server-side SSE Stream & Voice Adapter (/api/chat/stream)",
    authConfigured: true,
    fallbackModeLabel: "Offline Tutor Fallback",
    diagnosticMessage
  };
}
function createGenAIClient() {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error("GEMINI_API_KEY is missing on the server.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
}
async function verifyLiveModelAccess(forceRefresh = false) {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return getAIProviderStatus();
  }
  if (!forceRefresh && cachedLiveProbe && Date.now() < cachedLiveProbe.expiresAtMs) {
    return getAIProviderStatus();
  }
  const ai = createGenAIClient();
  const { activeModel } = resolveModelConfig();
  const candidates = Array.from(/* @__PURE__ */ new Set([activeModel, ...FALLBACK_MODEL_CHAIN]));
  let lastCategory = "network_error";
  let lastMessage = "All candidate models failed live verification.";
  for (const modelName of candidates) {
    if (!forceRefresh && isModelInCooldown(modelName)) {
      continue;
    }
    const t0 = Date.now();
    const probeAbort = new AbortController();
    const timer = setTimeout(() => probeAbort.abort(), 6500);
    try {
      const thinkingCfg = modelName === "gemini-3.1-flash-lite" ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } } : modelName.startsWith("gemini-3") ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {};
      const response = await ai.models.generateContent({
        model: modelName,
        contents: "Reply with the single word READY.",
        config: {
          abortSignal: probeAbort.signal,
          ...thinkingCfg
        }
      });
      clearTimeout(timer);
      const text = (response.text || "").trim();
      if (!text) {
        throw new Error("Empty response during model verification probe.");
      }
      const latency = Date.now() - t0;
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      cachedLiveProbe = {
        verifiedLive: true,
        verifiedModel: modelName,
        lastVerifiedAt: nowIso,
        probeLatencyMs: latency,
        errorCategory: "none",
        diagnosticMessage: `Verified live model access on "${modelName}" in ${latency}ms.`,
        expiresAtMs: Date.now() + 5 * 60 * 1e3
      };
      modelCooldownMap.delete(modelName);
      return getAIProviderStatus();
    } catch (err) {
      clearTimeout(timer);
      const classified = classifyProviderError(err);
      lastCategory = classified.category;
      lastMessage = classified.userMessage;
      if (classified.cooldownMs > 0) {
        markModelCooldown(modelName, classified.cooldownMs, classified.category, classified.userMessage);
      }
      if (!classified.shouldFailoverModel) {
        break;
      }
    }
  }
  cachedLiveProbe = {
    verifiedLive: false,
    verifiedModel: activeModel,
    lastVerifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
    probeLatencyMs: 0,
    errorCategory: lastCategory,
    diagnosticMessage: `Live AI verification failed (${lastCategory}): ${lastMessage}`,
    expiresAtMs: Date.now() + 30 * 1e3
  };
  return getAIProviderStatus();
}
function buildMitraSystemInstruction(ctx) {
  const isFriendTone = (ctx.conversationTone || "friend") === "friend";
  const langGuide = ctx.preferredLanguage === "hindi" ? "Talk primarily in warm, natural, everyday spoken Hindi (not stiff textbook Hindi), while always mirroring whatever language the user writes in." : ctx.preferredLanguage === "english" ? "Talk in warm, relaxed, natural conversational English (like a smart close friend), unless the user writes in Hindi or Hinglish\u2014in which case mirror their language effortlessly." : 'Talk in natural, everyday Hinglish\u2014the exact way smart Indian college friends chat with each other (warm Hindi flow + crisp English math/exam words)\u2014and always mirror whichever language (Hinglish, English, or Hindi) and level of informality ("tu/tum/yaar" vs "aap") the user uses.';
  const vibeGuide = isFriendTone ? `**Talk Like a Real Smart Best Friend ("Mitra" = Dost), NEVER Like a Stiff Textbook or Formal Lecturer:**
   - Sound human, relaxed, warm, and genuinely invested in your friend. Use natural conversational connectors (e.g., in Hinglish: *"Arre tension mat le yaar"*, *"Dekh kitna simple hai"*, *"Soch ke dekh..."*, *"Pakad liya na logic?"*, *"Ekdum sahi ja raha hai!"*; or in English: *"Hey, don't stress this one at all"*, *"Think of it like this..."*, *"Ooh, super close!"*, *"Makes sense so far?"*).
   - **Read the room & match their energy:**
     - If your friend just says *"hi"*, *"hey"*, *"kya haal hai"*, *"thak gaya hoon"*, *"exam se dar lag raha hai"*, or chats casually -> **just chat back warmly like a real friend in 2\u20134 short lines!** Check in on how they're doing and ask what they feel like doing\u2014NEVER dump a syllabus table or 10 bullet points when someone just says hello!
     - When explaining any concept -> start from absolute basics if needed, using a relatable everyday example (splitting a pizza/chai bill, cricket run rate, shopping discount, train ride) BEFORE introducing any formula.
     - Avoid robotic textbook headings like \`### 1. Conceptual Overview\` in casual turns. Let your explanation breathe in short paragraphs with crystal-clear step-by-step calculations.` : `**Supportive Exam Coach Tone:** Keep your tone encouraging, clear, structured, and crisp\u2014like a dedicated 1-on-1 CMAT mentor focused on accuracy, speed shortcuts, and step-by-step clarity.`;
  const depthGuide = ctx.explanationDepth === "concise" ? "Keep each reply short, snappy, and conversational (2\u20134 brief paragraphs max) while still showing key calculation steps." : "Start from absolute zero basics whenever a topic feels new or tricky: define unfamiliar terms first, show EVERY intermediate arithmetic step clearly, and explain WHY each shortcut works.";
  return `You are **Mitra** (literally "Friend"), the student's warm, intelligent best friend AND rigorous personal **CMAT 2026** tutor.

### Core Teaching & Conversational Rules
1. ${vibeGuide}
2. **Language:** ${langGuide}
3. **Step-by-Step Clarity:** ${depthGuide}
4. **Interactive One-Question-at-a-Time Practice & Adaptive Difficulty:**
   - When teaching or drilling interactively in chat, give **ONLY ONE practice question at a time** (with options \`(A)\`, \`(B)\`, \`(C)\`, \`(D)\` when appropriate) and wait for the student's answer\u2014never dump 5 ungraded questions at once unless explicitly asked for a worksheet.
   - **Wrong-Answer Diagnostics:** Whenever the student picks a wrong option or makes a calculation slip, NEVER give fake praise or skip straight to the final answer. Explicitly explain **why their chosen option/step went wrong** (e.g., base-shift trap, sign slip, LCM error), show the clean step-by-step fix, and immediately give **1 slightly easier or parallel remedial check** to confirm mastery.
   - **Adaptive Progression:** If the student answers accurately and quickly, step up to intermediate/advanced NTA CMAT PYQ difficulty; if they struggle, simplify and break the concept down further.
5. **Honest Learning State & Source Attribution:**
   - Distinguish strictly between a lesson being **viewed**, a quiz being **attempted**, a quiz being **passed**, and a topic being **mastered**. Never claim a pending assessment is completed.
   - Cite exact Slot & Question numbers when referencing attached **NTA CMAT Jan 2025 Slot 1 or Slot 2** papers; label newly created practice questions as *Mitra Practice Question*.
   - Format mathematical steps cleanly with KaTeX ($...$ inline, $$...$$ display).
6. **Contextual Quick-Reply Suggestions:**
   - At the very end of EVERY reply, on a new final line, append 3 short, natural reply options (max 6 words each, in the student's voice) in this exact format:
     \`<<<FOLLOWUPS: ["First reply", "Second reply", "Third reply"]>>>\`

### Student's Live Learning Context (Use Naturally for Continuity \u2014 Don't Recite Robotically Unless Asked)
- **Current Study Day:** Day ${ctx.currentDay} (${ctx.studyMinutesToday} / 120 mins studied today)
- **Active Topic:** ${ctx.currentSubject} \u2014 ${ctx.currentTopicTitle}
- **Completed / Mastered:** ${ctx.completedTopics.length ? ctx.completedTopics.join("; ") : "None yet"}
- **Viewed / Pending Assessments (NOT yet mastered):** ${ctx.pendingAssessments.length ? ctx.pendingAssessments.join("; ") : "None pending"}
- **Verified Quiz History:** ${ctx.quizSummary.length ? ctx.quizSummary.join(" | ") : "None yet"}
- **Unresolved Mistake Notebook:** ${ctx.unresolvedMistakes.length ? ctx.unresolvedMistakes.join(" || ") : "None"}`;
}
function loadAttachmentPart(attachment, uploadsDir) {
  try {
    if (attachment.presetPaperId && PRESET_PAPER_PATHS[attachment.presetPaperId]) {
      const preset = PRESET_PAPER_PATHS[attachment.presetPaperId];
      if (!fs.existsSync(preset.filePath)) return null;
      let b64 = pdfBase64Cache.get(attachment.presetPaperId);
      if (!b64) {
        b64 = fs.readFileSync(preset.filePath).toString("base64");
        pdfBase64Cache.set(attachment.presetPaperId, b64);
      }
      return {
        inlineData: {
          mimeType: preset.mimeType,
          data: b64
        }
      };
    }
    if (attachment.uploadedFileId) {
      const safeId = path.basename(attachment.uploadedFileId);
      const fullPath = path.join(uploadsDir, safeId);
      if (!fs.existsSync(fullPath)) return null;
      const mime = attachment.mimeType || "application/octet-stream";
      const buffer = fs.readFileSync(fullPath);
      if (mime === "application/pdf" || mime.startsWith("image/")) {
        return {
          inlineData: {
            mimeType: mime,
            data: buffer.toString("base64")
          }
        };
      }
      const rawText = buffer.toString("utf-8").slice(0, 45e3);
      return {
        text: `[Uploaded Document: ${attachment.name}]
\`\`\`
${rawText}
\`\`\``
      };
    }
  } catch (err) {
    console.error("Attachment load error:", err);
  }
  return null;
}
function stripFollowupsMarker(text) {
  return text.replace(/<<<FOLLOWUPS:\s*\[[\s\S]*?\]\s*>>>/g, "").trim();
}
function buildGeminiContents(history, uploadsDir) {
  const recent = history.slice(-24);
  const contents = [];
  const attachedPdfPresetAlready = /* @__PURE__ */ new Set();
  for (let i = 0; i < recent.length; i++) {
    const msg = recent[i];
    const role = msg.role === "assistant" ? "model" : "user";
    const parts = [];
    if (role === "user" && msg.attachments && msg.attachments.length > 0) {
      const isRecentAttachmentTurn = i >= recent.length - 4;
      for (const att of msg.attachments) {
        const key = att.presetPaperId || att.uploadedFileId || att.name;
        if (isRecentAttachmentTurn && !attachedPdfPresetAlready.has(key)) {
          const part = loadAttachmentPart(att, uploadsDir);
          if (part) {
            parts.push(part);
            attachedPdfPresetAlready.add(key);
          }
        } else {
          parts.push({ text: `[Referenced Attachment: ${att.name}]` });
        }
      }
    }
    const cleanedContent = role === "model" ? stripFollowupsMarker(msg.content) : msg.content;
    parts.push({ text: cleanedContent || " " });
    contents.push({ role, parts });
  }
  return contents;
}
function buildOfflineTutorFallback(userMessage, ctx, reason) {
  return buildStructuredOfflineFallback(userMessage, ctx, reason);
}
async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function streamTutorResponse(params) {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    const lastUser2 = params.history[params.history.length - 1]?.content || "";
    const offline2 = buildOfflineTutorFallback(
      lastUser2,
      params.learningContext,
      "GEMINI_API_KEY is missing in server environment."
    );
    params.onChunk(offline2.content, "offline-fallback");
    return {
      fullText: offline2.content,
      sourceMode: "offline",
      modelUsed: "offline-fallback",
      errorReason: offline2.errorReason,
      errorCategory: "missing_key"
    };
  }
  const ai = createGenAIClient();
  const systemInstruction = buildMitraSystemInstruction(params.learningContext);
  const contents = buildGeminiContents(params.history, params.uploadsDir);
  const { activeModel } = resolveModelConfig();
  const preferredPrimary = params.modelTier === "thinking" ? THINKING_TUTOR_MODEL : params.modelTier === "fast" ? FAST_CONVERSATIONAL_MODEL : activeModel;
  const allCandidates = Array.from(/* @__PURE__ */ new Set([preferredPrimary, ...FALLBACK_MODEL_CHAIN]));
  const healthyCandidates = allCandidates.filter((m) => !isModelInCooldown(m));
  const candidateModels = healthyCandidates.length > 0 ? healthyCandidates : [preferredPrimary];
  let lastErrorMsg = "Temporary AI provider failure.";
  let lastCategory = "network_error";
  for (let mIdx = 0; mIdx < candidateModels.length; mIdx++) {
    const modelName = candidateModels[mIdx];
    const maxAttempts = mIdx === 0 ? 1 : 2;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      if (params.signal?.aborted) {
        throw new Error("ABORTED_BY_USER");
      }
      const attemptAbort = new AbortController();
      let timedOutWaitingForFirstChunk = false;
      const timeoutMs = modelName === THINKING_TUTOR_MODEL ? 13e3 : 9500;
      const t0 = Date.now();
      const firstChunkTimer = setTimeout(() => {
        timedOutWaitingForFirstChunk = true;
        attemptAbort.abort();
      }, timeoutMs);
      const onUserAbort = () => attemptAbort.abort();
      params.signal?.addEventListener("abort", onUserAbort, { once: true });
      try {
        const thinkingCfg = modelName === "gemini-3.1-flash-lite" ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } } : modelName.startsWith("gemini-3") ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {};
        const stream = await ai.models.generateContentStream({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            abortSignal: attemptAbort.signal,
            ...thinkingCfg
          }
        });
        let accumulated = "";
        let firstChunkLatency = 0;
        for await (const chunk of stream) {
          clearTimeout(firstChunkTimer);
          if (!firstChunkLatency) {
            firstChunkLatency = Date.now() - t0;
          }
          if (params.signal?.aborted) {
            break;
          }
          const c = chunk;
          const piece = c.text || "";
          if (piece) {
            accumulated += piece;
            params.onChunk(piece, modelName);
          }
        }
        clearTimeout(firstChunkTimer);
        params.signal?.removeEventListener("abort", onUserAbort);
        if (accumulated.trim().length > 0 || params.signal?.aborted) {
          modelCooldownMap.delete(modelName);
          cachedLiveProbe = {
            verifiedLive: true,
            verifiedModel: modelName,
            lastVerifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
            probeLatencyMs: firstChunkLatency || Date.now() - t0,
            errorCategory: "none",
            diagnosticMessage: `Live streaming verified on "${modelName}" (${firstChunkLatency || Date.now() - t0}ms TTFT).`,
            expiresAtMs: Date.now() + 5 * 60 * 1e3
          };
          return {
            fullText: accumulated,
            sourceMode: "live",
            modelUsed: modelName,
            errorCategory: "none"
          };
        }
        throw new Error("Model returned an empty response stream.");
      } catch (err) {
        clearTimeout(firstChunkTimer);
        params.signal?.removeEventListener("abort", onUserAbort);
        if (params.signal?.aborted || err instanceof Error && err.message === "ABORTED_BY_USER") {
          throw new Error("ABORTED_BY_USER");
        }
        if (timedOutWaitingForFirstChunk) {
          lastCategory = "timeout";
          lastErrorMsg = `Model "${modelName}" timed out after ${timeoutMs}ms waiting for initial stream chunk.`;
          markModelCooldown(modelName, 30 * 1e3, "timeout", lastErrorMsg);
          break;
        }
        const classified = classifyProviderError(err);
        lastErrorMsg = classified.userMessage;
        lastCategory = classified.category;
        if (classified.cooldownMs > 0) {
          markModelCooldown(modelName, classified.cooldownMs, classified.category, classified.userMessage);
        }
        if (!classified.shouldFailoverModel) {
          mIdx = candidateModels.length;
          break;
        }
        if (!classified.isRetryableSameModel) {
          break;
        }
        if (attempt === 0 && maxAttempts > 1) {
          await sleep(350);
        }
      }
    }
  }
  cachedLiveProbe = {
    verifiedLive: false,
    verifiedModel: preferredPrimary,
    lastVerifiedAt: (/* @__PURE__ */ new Date()).toISOString(),
    probeLatencyMs: 0,
    errorCategory: lastCategory,
    diagnosticMessage: `Live AI paused (${lastCategory}): ${lastErrorMsg}`,
    expiresAtMs: Date.now() + 25 * 1e3
  };
  const lastUser = params.history[params.history.length - 1]?.content || "";
  const offline = buildOfflineTutorFallback(lastUser, params.learningContext, lastErrorMsg);
  params.onChunk(offline.content, "offline-fallback");
  return {
    fullText: offline.content,
    sourceMode: "offline",
    modelUsed: "offline-fallback",
    errorReason: offline.errorReason,
    errorCategory: lastCategory
  };
}
async function generateTutorActionText(params) {
  let finalOut = "";
  const result = await streamTutorResponse({
    history: [
      {
        role: "user",
        content: params.prompt,
        attachments: params.attachments
      }
    ],
    learningContext: params.learningContext,
    uploadsDir: params.uploadsDir,
    modelTier: "fast",
    onChunk: (delta) => {
      finalOut += delta;
    }
  });
  return {
    text: stripFollowupsMarker(result.fullText || finalOut),
    sourceMode: result.sourceMode,
    modelUsed: result.modelUsed,
    errorReason: result.errorReason,
    errorCategory: result.errorCategory
  };
}
async function transcribeStudentAudio(params) {
  const ai = createGenAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.5-transcribe",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: params.mimeType || "audio/webm",
            data: params.audioBase64
          }
        },
        {
          text: "Transcribe the student speech accurately. Keep Hindi, Hinglish, English words, numbers, and mathematical expressions cleanly readable. Output only the spoken transcript without extra commentary."
        }
      ]
    }
  });
  return {
    text: (response.text || "").trim()
  };
}
function cleanMarkdownForSpeech(markdown) {
  return stripFollowupsMarker(markdown).replace(/```[\s\S]*?```/g, " See the code or calculation block on screen. ").replace(/\$\$([\s\S]*?)\$\$/g, " $1 ").replace(/\$([^$\n]+)\$/g, " $1 ").replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, "$1 over $2").replace(/\\times/g, " times ").replace(/\\div/g, " divided by ").replace(/\\rightarrow/g, " gives ").replace(/[#>*_`~|]/g, " ").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/\s+/g, " ").trim().slice(0, 1600);
}
async function synthesizeTutorSpeech(params) {
  const spokenText = cleanMarkdownForSpeech(params.text);
  if (!spokenText) {
    throw new Error("No readable text provided for speech synthesis.");
  }
  const ai = createGenAIClient();
  const response = await ai.models.generateContent({
    model: "gemini-3.8-flash-lite-tts",
    contents: [
      {
        role: "user",
        parts: [
          {
            text: spokenText,
            speechMetadata: {
              style: "Warm, upbeat, relaxed close friend and study buddy chatting naturally"
            }
          }
        ]
      }
    ],
    config: {
      responseModalities: ["AUDIO"],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: "Puck" }
        }
      }
    }
  });
  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("Speech synthesis did not return audio data.");
  }
  return {
    audioBase64: base64Audio,
    mimeType: "audio/wav"
  };
}

// server/authMiddleware.ts
import crypto from "node:crypto";
import https from "node:https";

// firebase-applet-config.json
var firebase_applet_config_default = {
  projectId: "bustling-bivouac-gbcxw",
  appId: "1:977844280925:web:eeacd315a830f8f703b7b4",
  apiKey: "AIzaSyCtP-0DNmNfoDsbeaZ_xUp_l1WV3rE6718",
  authDomain: "bustling-bivouac-gbcxw.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-mitraaitutor-920f501e-b410-4cca-b248-6a86315419da",
  storageBucket: "bustling-bivouac-gbcxw.firebasestorage.app",
  messagingSenderId: "977844280925",
  measurementId: "",
  oAuthClientId: "977844280925-toj2t1rdg7dlr45ismuvll6odh14opg9.apps.googleusercontent.com",
  recaptchaSiteKey: ""
};

// server/authMiddleware.ts
var FIREBASE_PROJECT_ID = firebase_applet_config_default.projectId;
var GOOGLE_CERTS_URL = "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com";
var GUEST_HMAC_SECRET = process.env.SESSION_HMAC_SECRET || crypto.createHash("sha256").update(`mitra-session-secret-${FIREBASE_PROJECT_ID}-${process.env.VERCEL_PROJECT_ID || "v2"}`).digest("hex");
var cachedGoogleCerts = null;
var cachedGoogleCertsExpiresAt = 0;
function fetchGooglePublicCerts() {
  const now = Date.now();
  if (cachedGoogleCerts && now < cachedGoogleCertsExpiresAt) {
    return Promise.resolve(cachedGoogleCerts);
  }
  return new Promise((resolve, reject) => {
    const req = https.get(GOOGLE_CERTS_URL, { timeout: 5e3 }, (res) => {
      let body = "";
      res.on("data", (chunk) => {
        body += chunk;
      });
      res.on("end", () => {
        try {
          if (res.statusCode !== 200) {
            reject(new Error(`Failed fetching SecureToken certs (HTTP ${res.statusCode})`));
            return;
          }
          const parsed = JSON.parse(body);
          const cacheControl = String(res.headers["cache-control"] || "");
          const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
          const ttlSeconds = maxAgeMatch ? Number(maxAgeMatch[1]) : 3600;
          cachedGoogleCerts = parsed;
          cachedGoogleCertsExpiresAt = Date.now() + ttlSeconds * 1e3;
          resolve(parsed);
        } catch (err) {
          reject(err);
        }
      });
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Timed out fetching Firebase public certificates."));
    });
  });
}
function base64UrlDecode(str) {
  const pad = 4 - str.length % 4;
  const normalized = str.replace(/-/g, "+").replace(/_/g, "/") + (pad < 4 ? "=".repeat(pad) : "");
  return Buffer.from(normalized, "base64");
}
async function verifyFirebaseIdToken(idToken) {
  const parts = idToken.split(".");
  if (parts.length !== 3) {
    throw new Error("Malformed Firebase ID token.");
  }
  const [headerB64, payloadB64, signatureB64] = parts;
  const header = JSON.parse(base64UrlDecode(headerB64).toString("utf8"));
  const payload = JSON.parse(base64UrlDecode(payloadB64).toString("utf8"));
  if (header.alg !== "RS256" || !header.kid) {
    throw new Error("Unsupported token algorithm or missing key ID.");
  }
  const nowSec = Math.floor(Date.now() / 1e3);
  if (!payload.exp || payload.exp < nowSec - 30) {
    throw new Error("Firebase ID token has expired.");
  }
  if (payload.aud !== FIREBASE_PROJECT_ID) {
    throw new Error("Firebase ID token audience mismatch.");
  }
  if (payload.iss !== `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`) {
    throw new Error("Firebase ID token issuer mismatch.");
  }
  if (!payload.sub || typeof payload.sub !== "string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(payload.sub)) {
    throw new Error("Invalid Firebase UID in token.");
  }
  const certs = await fetchGooglePublicCerts();
  const certPem = certs[header.kid];
  if (!certPem) {
    throw new Error("Unknown signing certificate for Firebase ID token.");
  }
  const verifier = crypto.createVerify("RSA-SHA256");
  verifier.update(`${headerB64}.${payloadB64}`);
  verifier.end();
  const signatureValid = verifier.verify(certPem, base64UrlDecode(signatureB64));
  if (!signatureValid) {
    throw new Error("Invalid cryptographic signature on Firebase ID token.");
  }
  return {
    principalId: `firebase:${payload.sub}`,
    authMode: "firebase",
    uid: payload.sub,
    email: payload.email,
    emailVerified: Boolean(payload.email_verified)
  };
}
function issueIsolatedGuestToken(existingSessionId) {
  const cleanExisting = existingSessionId && /^[a-zA-Z0-9_-]{16,64}$/.test(existingSessionId) ? existingSessionId : `gst_${crypto.randomBytes(16).toString("hex")}`;
  const issuedAt = Math.floor(Date.now() / 1e3);
  const body = `${cleanExisting}.${issuedAt}`;
  const sig = crypto.createHmac("sha256", GUEST_HMAC_SECRET).update(body).digest("base64url");
  return {
    token: `mitra_guest.${body}.${sig}`,
    sessionId: cleanExisting,
    principalId: `guest:${cleanExisting}`
  };
}
function verifyIsolatedGuestToken(token) {
  if (!token.startsWith("mitra_guest.")) {
    throw new Error("Not a Mitra guest session token.");
  }
  const parts = token.split(".");
  if (parts.length !== 4) {
    throw new Error("Malformed guest session token.");
  }
  const [, sessionId, issuedAtStr, providedSig] = parts;
  if (!/^[a-zA-Z0-9_-]{16,64}$/.test(sessionId)) {
    throw new Error("Invalid guest session identifier.");
  }
  const issuedAt = Number(issuedAtStr);
  if (!Number.isFinite(issuedAt) || issuedAt <= 0) {
    throw new Error("Invalid guest token timestamp.");
  }
  const expectedSig = crypto.createHmac("sha256", GUEST_HMAC_SECRET).update(`${sessionId}.${issuedAtStr}`).digest("base64url");
  const sigBufA = Buffer.from(providedSig);
  const sigBufB = Buffer.from(expectedSig);
  if (sigBufA.length !== sigBufB.length || !crypto.timingSafeEqual(sigBufA, sigBufB)) {
    throw new Error("Invalid guest session token signature.");
  }
  return {
    principalId: `guest:${sessionId}`,
    authMode: "guest",
    uid: sessionId,
    emailVerified: false
  };
}
function extractBearerToken(req) {
  const authHeader = req.headers.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    const raw = authHeader.slice(7).trim();
    if (raw.length > 0) return raw;
  }
  return null;
}
async function requireAuth(req, res, next) {
  const token = extractBearerToken(req);
  if (!token) {
    res.status(401).json({
      error: "Authentication required. Missing Bearer session or Firebase ID token.",
      code: "UNAUTHENTICATED"
    });
    return;
  }
  try {
    if (token.startsWith("mitra_guest.")) {
      req.principal = verifyIsolatedGuestToken(token);
      next();
      return;
    }
    req.principal = await verifyFirebaseIdToken(token);
    next();
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Invalid authentication token.";
    res.status(401).json({
      error: `Authentication failed: ${msg}`,
      code: "INVALID_TOKEN"
    });
  }
}
function isValidResourceId(id) {
  return typeof id === "string" && /^[a-zA-Z0-9_-]{1,128}$/.test(id);
}

// server/storage.ts
import crypto2 from "node:crypto";
import fs2 from "node:fs";
import os from "node:os";
import path2 from "node:path";

// src/data/cmatCurriculum.ts
var CMAT_SYLLABUS_TOPICS = [
  // DAY 1 TOPICS (Preserved Current State)
  {
    id: "quant_fractions_pct",
    dayNumber: 1,
    subject: "Quantitative Techniques",
    chapter: "Arithmetic Foundations",
    title: "Fractions, Decimals & Percentage Conversions",
    estimatedMinutes: 15,
    summary: "Simplification rules, fraction-to-decimal tables (1/2 to 1/20), and base percentage equivalents.",
    keyConcepts: [
      "BODMAS simplification & mixed fraction operations",
      "Standard fraction-percentage reciprocals (1/8 = 12.5%, 1/6 = 16.67%)",
      "Fast decimal-to-fraction conversion tricks for DI sets"
    ],
    starterPrompt: "Let us revise quick fraction-to-percentage conversion shortcuts for CMAT DI calculations."
  },
  {
    id: "quant_pct_changes",
    dayNumber: 1,
    subject: "Quantitative Techniques",
    chapter: "Arithmetic Foundations",
    title: "Percentage Change, Reverse % & Successive Changes",
    estimatedMinutes: 15,
    summary: "Percentage increase/decrease multipliers, reverse percentage recovery, and net successive formula a + b + ab/100.",
    keyConcepts: [
      "Multiplying factor method (e.g., +25% = 5/4, so reverse reduction = 1/5 = 20%)",
      "Successive percentage change: a + b + (ab)/100",
      "Base-shift traps in Profit/Loss and Data Interpretation"
    ],
    starterPrompt: "Give me 2 intermediate practice problems on reverse percentages and successive percentage change."
  },
  {
    id: "quant_ratio_prop",
    dayNumber: 1,
    subject: "Quantitative Techniques",
    chapter: "Ratio, Proportion & Mixtures",
    title: "Introduction to Ratio & Proportion (Assessment Pending)",
    estimatedMinutes: 25,
    summary: "Combining chained ratios (a:b and b:c), fractional ratios (1/2 : 1/3 : 1/5 : 1/8), proportion rules, and mixture ratios.",
    keyConcepts: [
      "Scaling ratios via LCM of denominators",
      "Merging A:B and B:C using common middle term",
      "Income-expenditure difference method & mixture replacement"
    ],
    linkedQuizId: "quiz_quant_ratio_prop",
    starterPrompt: "Continue our Ratio and Proportion lesson from where we left off, then prepare me for the pending Ratio-Proportion assessment."
  },
  {
    id: "lr_number_series_basic",
    dayNumber: 1,
    subject: "Logical Reasoning",
    chapter: "Series & Patterns",
    title: "Number Series: Consecutive Differences, Multiplication & Division",
    estimatedMinutes: 12,
    summary: "Step-difference ladders, constant/growing multipliers, and division series.",
    keyConcepts: [
      "First-order and second-order difference check",
      "Ratio check when terms grow > 2x per step (e.g., x4 - 1)",
      "Decimal/halving division patterns"
    ],
    linkedQuizId: "quiz_lr_series_basic",
    starterPrompt: "Revise multiplication + constant offset number series like 7, 27, 107, 427, ? from CMAT."
  },
  {
    id: "lr_number_series_adv",
    dayNumber: 1,
    subject: "Logical Reasoning",
    chapter: "Series & Patterns",
    title: "Squares, Cubes, Primes, Alternating & Wrong-Term Series",
    estimatedMinutes: 15,
    summary: "n^2 +- k, n^3 +- k, consecutive prime gaps (29 -> 31), dual alternating sequences, and spotting wrong terms.",
    keyConcepts: [
      "Prime numbers sequence: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37",
      "Cubes & squares neighbourhood recognition (64, 125, 216, 343)",
      "Isolating wrong term in difference series (e.g., 69, 55, 26, 13, 5)"
    ],
    linkedQuizId: "quiz_lr_series_adv",
    starterPrompt: "Help me review the 2 mistakes from my Advanced Number Series quiz (6/8) before we move to Coding-Decoding."
  },
  {
    id: "gk_indian_polity_const",
    dayNumber: 1,
    subject: "General Knowledge",
    chapter: "Indian Polity & Constitution",
    title: "Indian Constitution, Fundamental Rights, Parliament & President",
    estimatedMinutes: 20,
    summary: "Adoption (26 Nov 1949), Commencement (26 Jan 1950), Dr. B. R. Ambedkar & Drafting Committee, FR/FD, 42nd Amendment, Lok Sabha, Rajya Sabha & President.",
    keyConcepts: [
      "26 Nov 1949 (Adoption) vs 26 Jan 1950 (Commencement)",
      "Articles 14, 19, 21, 24, 32, 50 & 42nd Amendment (1976 - Fundamental Duties)",
      "Lok Sabha, Rajya Sabha, Vice-President Electoral College & President powers"
    ],
    linkedQuizId: "quiz_gk_polity_day1",
    starterPrompt: "Give me a quick 3-minute rapid-fire revision of Indian Constitution Articles asked in CMAT 2025."
  },
  // DAY 2 PLANNED TOPICS (Next Study Session)
  {
    id: "lang_grammar_basics",
    dayNumber: 2,
    subject: "Language Comprehension",
    chapter: "Grammar & Usage",
    title: "Basic Grammar, Articles, Fixed Prepositions & Sentence Correction",
    estimatedMinutes: 20,
    summary: "Articles usage, fixed prepositions (pleased with, known to, interested in), active-passive voice, and direct-indirect narration.",
    keyConcepts: [
      'Passive voice without "by" (known to, contained in, interested in)',
      "Articles before titles and generalizations",
      "Direct to indirect speech tense & reporting verb rules (said to -> told)"
    ],
    linkedQuizId: "quiz_lang_grammar_day2",
    starterPrompt: "Start Language Comprehension from absolute basics: teach me Articles, Fixed Prepositions, and Sentence Correction in simple Hinglish."
  },
  {
    id: "lr_coding_direction",
    dayNumber: 2,
    subject: "Logical Reasoning",
    chapter: "Analytical Reasoning",
    title: "Coding-Decoding & Direction Sense",
    estimatedMinutes: 25,
    summary: "EJOTY letter positions, +/- shift patterns (like POETRY -> QONDSQX), shadow & NSEW turn tracking.",
    keyConcepts: [
      "Alphabet position numbers (1-26) and opposite letter pairs (sum = 27)",
      "Reverse + shift coding patterns from CMAT 2025",
      "Net North-South and East-West displacement calculation"
    ],
    starterPrompt: "After revising number series, teach me Coding-Decoding and Direction Sense step by step from basics."
  },
  {
    id: "ent_bootstrapping_vc",
    dayNumber: 2,
    subject: "Innovation & Entrepreneurship",
    chapter: "Startup Financing & Lifecycle",
    title: "Bootstrapping, Angel Funding, Venture Capital & Lean Startup MVP",
    estimatedMinutes: 20,
    summary: "Stages of startup funding (Ideation -> Bootstrapping -> Seed/Angel -> VC -> IPO), MVP, Pivot, and Incubators vs Accelerators.",
    keyConcepts: [
      "Bootstrapping (self-funding) vs Angel Investment vs Venture Capital",
      "Lean Startup: Minimal Viable Product (MVP) & Pivoting",
      "Patent, Copyright, Trademark & Stand-Up India Scheme"
    ],
    linkedQuizId: "quiz_cmat_2025_slot1_pyq",
    starterPrompt: "Teach me Innovation & Entrepreneurship basics for CMAT: Bootstrapping, Angel Investors, Venture Capital, and MVP with simple examples."
  },
  // DAY 3 - DAY 6 STRUCTURED ROADMAP
  {
    id: "quant_profit_loss_sici",
    dayNumber: 3,
    subject: "Quantitative Techniques",
    chapter: "Commercial Arithmetic",
    title: "Profit, Loss, False Weights & Simple/Compound Interest",
    estimatedMinutes: 40,
    summary: "Markup-discount, dishonest dealer false-balance formula, and 2-year/3-year SI vs CI difference.",
    keyConcepts: [
      "Dishonest vendor gain % when cheating on buying and selling",
      "CI vs SI difference for 2 and 3 years (e.g., 30% for 3 yrs: SI=90%, CI=119.7%)",
      "Consignment loss compensation problems"
    ],
    linkedQuizId: "quiz_cmat_2025_slot1_pyq",
    starterPrompt: "Teach me Profit & Loss (including dishonest shopkeeper) and SI vs CI from scratch with CMAT 2025 examples."
  },
  {
    id: "lr_seating_venn_syllogism",
    dayNumber: 3,
    subject: "Logical Reasoning",
    chapter: "Arrangements & Logic",
    title: "Linear/Circular Seating, Venn Diagrams & Statement-Assumptions",
    estimatedMinutes: 25,
    summary: "Facing North linear rows, 6-person circular tables, 3-set overlapping Venn diagrams, and critical reasoning.",
    keyConcepts: [
      "Fixing extreme ends and definite left/right clues first",
      "Exactly-one vs at-least-two regions in 3-circle Venn diagrams",
      "Implicit assumptions vs strong arguments rules"
    ],
    linkedQuizId: "quiz_cmat_2025_slot2_pyq",
    starterPrompt: "Teach me Linear and Circular Seating Arrangement tricks for CMAT step by step."
  },
  {
    id: "quant_di_charts",
    dayNumber: 4,
    subject: "Quantitative Techniques",
    chapter: "Data Interpretation",
    title: "Pie Charts & Double Bar Graphs (CMAT 2025 Slot 1 & 2 Sets)",
    estimatedMinutes: 40,
    summary: "Extracting exact counts vs percentage ratios without unnecessary multiplication in multi-chart DI sets.",
    keyConcepts: [
      "Dual Pie Chart specialization vs placement ratios (Slot 1 Q.1-Q.3)",
      "Grouped Bar Graph multigrain vs whole-wheat store comparisons (Slot 2 Q.1-Q.3)",
      "Approximation techniques for 4-option close percentages"
    ],
    linkedQuizId: "quiz_cmat_2025_slot2_pyq",
    starterPrompt: "Walk me through the Pie Chart DI set from CMAT 2025 Slot 1 and Bar Graph DI set from Slot 2 step by step."
  },
  {
    id: "lang_rc_parajumbles",
    dayNumber: 4,
    subject: "Language Comprehension",
    chapter: "Reading Comprehension & Verbal Logic",
    title: "Reading Comprehension Passages, Tone/Main Idea & Para-Jumbles",
    estimatedMinutes: 25,
    summary: "Eliminating extreme-word traps in RC inference questions, author tone detection, and mandatory pair linking in 4-sentence para-jumbles.",
    keyConcepts: [
      "Main idea vs supporting detail separation in 350-word CMAT passages",
      "Pronoun & chronological connectors in Para-Jumbles",
      'Eliminating out-of-scope and extreme ("always/never") options'
    ],
    linkedQuizId: "mock_cmat_2026_full_diagnostic",
    starterPrompt: "Teach me Reading Comprehension elimination tricks and Para-Jumble mandatory pair rules for CMAT."
  },
  {
    id: "lr_blood_syllogism_cr",
    dayNumber: 4,
    subject: "Logical Reasoning",
    chapter: "Deductive & Critical Reasoning",
    title: "Blood Relations, Syllogisms & Statement-Argument / Cause-Effect",
    estimatedMinutes: 25,
    summary: "Family tree symbols, Venn-based All/Some/No syllogisms, and separating strong vs weak arguments.",
    keyConcepts: [
      "Generation-tree mapping for coded and pointing blood relations",
      "Definite vs possibility conclusions in 3-statement syllogisms",
      "Cause-and-effect vs common-cause distinction in verbal reasoning"
    ],
    linkedQuizId: "mock_cmat_2026_full_diagnostic",
    starterPrompt: "Teach me Blood Relations family tree shortcuts and Venn-diagram Syllogisms from basics."
  },
  {
    id: "quant_tsd_time_work",
    dayNumber: 5,
    subject: "Quantitative Techniques",
    chapter: "Rates & Work",
    title: "Time, Speed, Distance, Races & Time-Work Efficiency",
    estimatedMinutes: 40,
    summary: "LCM total-work method, partial work joins, linear races (A beats B by 30m), and walking-riding round trips.",
    keyConcepts: [
      "Efficiency ratio -> Time ratio inverse rule",
      "Walking + Riding vs Walking both ways shortcut",
      "Linear race start/distance ratio analysis"
    ],
    linkedQuizId: "mock_cmat_2026_full_diagnostic",
    starterPrompt: "Teach me Time & Work (LCM method) and Time-Speed-Distance races from basics."
  },
  {
    id: "lang_vocab_idioms",
    dayNumber: 5,
    subject: "Language Comprehension",
    chapter: "Lexicon & Idiomatic Usage",
    title: "High-Frequency Vocabulary, Idioms, Phrasal Verbs & One-Word Substitution",
    estimatedMinutes: 20,
    summary: "Root-word etymology, contextual synonyms/antonyms, CMAT idioms, and confusable word pairs.",
    keyConcepts: [
      "Latin/Greek roots (bene, mal, chron, loqu,greg) for unknown words",
      'High-frequency CMAT idioms ("in the soup", "burn the midnight oil", "devil\u2019s advocate")',
      "One-word substitutions & phrasal verbs in context"
    ],
    linkedQuizId: "quiz_lang_grammar_day2",
    starterPrompt: "Teach me root-word vocabulary tricks and top 15 CMAT idioms with memorable Hinglish stories."
  },
  {
    id: "ent_ipr_govt_schemes",
    dayNumber: 5,
    subject: "Innovation & Entrepreneurship",
    chapter: "IPR, Policy & Ecosystem",
    title: "Patents, Trademarks, Startup India, MUDRA & Atal Innovation Mission",
    estimatedMinutes: 20,
    summary: "Intellectual Property durations in India, DPIIT Startup recognition criteria, Shishu/Kishore/Tarun MUDRA loans, and Schumpeterian innovation.",
    keyConcepts: [
      "Patent (20 yrs), Trademark (10 yrs renewable), Copyright & GI Tags",
      "MUDRA tiers: Shishu (up to \u20B950k), Kishore (\u20B950k\u2013\u20B95L), Tarun (\u20B95L\u2013\u20B910L)",
      "Intrapreneurship vs Entrepreneurship & Creative Destruction (Schumpeter)"
    ],
    linkedQuizId: "quiz_ent_innovation_sectional",
    starterPrompt: "Teach me IPR (Patents, Trademarks, GI Tags) and Government Startup Schemes (Startup India, MUDRA, AIM) for CMAT."
  },
  {
    id: "gk_static_science_awards",
    dayNumber: 6,
    subject: "General Knowledge",
    chapter: "Static GK & General Science",
    title: "Biosphere Reserves, Classical Dances, Books, Science & Agricultural Revolutions",
    estimatedMinutes: 20,
    summary: "National Parks & Biosphere Reserves, Bharatanatyam/Kathakali/Mohiniyattam, Agricultural Revolutions, and Physics/Biology essentials.",
    keyConcepts: [
      "Simlipal (Odisha), Corbett (Uttarakhand), Dudhwa (UP), Gir (Gujarat)",
      "White (Milk - Verghese Kurien), Yellow (Oilseeds), Blue (Fish) Revolutions",
      "Rayleigh scattering of blue sky, Vitamins, Insulin & SI Units"
    ],
    linkedQuizId: "quiz_gk_econ_static",
    starterPrompt: "Teach me high-yield Static GK topics (National Parks, Dances, Revolutions, General Science) for CMAT."
  },
  {
    id: "gk_economy_rbi_fiscal",
    dayNumber: 6,
    subject: "General Knowledge",
    chapter: "Indian Economy & Banking",
    title: "RBI Monetary Policy, Repo/CRR/SLR, GDP, Fiscal Deficit & International Bodies",
    estimatedMinutes: 25,
    summary: "Monetary Policy Committee tools, inflation control, GST Council (Art. 279A), IMF/World Bank/WTO headquarters, and Five-Year Plan legacy.",
    keyConcepts: [
      "Repo Rate, Reverse Repo, CRR & SLR impact on money supply",
      "Nominal vs Real GDP & GST Council constitutional structure",
      "Headquarters of WTO, IMF, World Bank, ADB & NDB"
    ],
    linkedQuizId: "quiz_gk_econ_static",
    starterPrompt: "Explain RBI Monetary Policy (Repo, Reverse Repo, CRR, SLR) and GDP basics like a friend using everyday bank examples."
  },
  {
    id: "quant_algebra_geometry",
    dayNumber: 7,
    subject: "Quantitative Techniques",
    chapter: "Algebra & Geometry",
    title: "Quadratic Equations, Linear Inequalities, Triangles, Circles & Mensuration",
    estimatedMinutes: 40,
    summary: "Sum and product of roots, Vieta formulas, right-triangle triplets, circle chord/tangent theorems, and 3D cylinder/cone/sphere volumes.",
    keyConcepts: [
      "Sum of roots (-b/a), Product of roots (c/a) & discriminant nature",
      "Pythagorean triplets & equilateral/isosceles area shortcuts",
      "Volume scaling when radius or height changes by x%"
    ],
    linkedQuizId: "mock_cmat_2026_full_diagnostic",
    starterPrompt: "Teach me Quadratic Equations (sum/product of roots) and Mensuration volume formulas from basics."
  },
  {
    id: "quant_pnc_probability",
    dayNumber: 8,
    subject: "Quantitative Techniques",
    chapter: "Modern Math",
    title: "Permutations, Combinations, Probability & Set Theory",
    estimatedMinutes: 35,
    summary: "Fundamental counting principle, arrangement vs selection (nPr vs nCr), coin/dice/card probability, and complementary events.",
    keyConcepts: [
      "When to multiply (AND) vs when to add (OR) in counting",
      "Word arrangements with repeated letters & circular permutations (n-1)!",
      "At-least-one probability = 1 - P(none)"
    ],
    linkedQuizId: "mock_cmat_2026_full_diagnostic",
    starterPrompt: "Start Permutations, Combinations & Probability from zero basics with relatable card and coin examples."
  },
  {
    id: "ent_business_models_strategy",
    dayNumber: 8,
    subject: "Innovation & Entrepreneurship",
    chapter: "Business Models & Scaling",
    title: "B2B/B2C/SaaS Unit Economics, CAC vs LTV, Unicorns & Social Entrepreneurship",
    estimatedMinutes: 20,
    summary: "Customer Acquisition Cost (CAC), Lifetime Value (LTV), Burn Rate, Runway, Unicorn valuation ($1B+), and Blue Ocean vs Red Ocean strategy.",
    keyConcepts: [
      "Healthy startup unit economics: LTV >= 3x CAC, Burn Rate & Runway",
      "Unicorn ($1B), Decacorn ($10B) & Soonicorn definitions",
      "Social Entrepreneurship (triple bottom line: People, Planet, Profit)"
    ],
    linkedQuizId: "quiz_ent_innovation_sectional",
    starterPrompt: "Explain Startup Unit Economics (CAC, LTV, Burn Rate, Runway) and Blue Ocean Strategy simply."
  }
];
var INITIAL_USER_PROFILE = {
  ownerId: "local-student",
  displayName: "CMAT Aspirant",
  preferredLanguage: "hinglish",
  explanationDepth: "step_by_step",
  currentDay: 1,
  currentSubject: "Quantitative Techniques",
  currentTopicId: "quant_ratio_prop",
  studyMinutesToday: 95,
  totalStudyMinutes: 95,
  missedDaysOffset: 0,
  createdAt: "2026-10-23T09:00:00.000Z",
  updatedAt: "2026-10-24T08:00:00.000Z"
};
var INITIAL_TOPIC_PROGRESS = [
  {
    topicId: "quant_fractions_pct",
    subject: "Quantitative Techniques",
    status: "mastered",
    bestScore: 5,
    totalQuestions: 5,
    attemptsCount: 1,
    timeSpentMinutes: 15,
    createdAt: "2026-10-23T09:15:00.000Z",
    updatedAt: "2026-10-23T09:30:00.000Z"
  },
  {
    topicId: "quant_pct_changes",
    subject: "Quantitative Techniques",
    status: "mastered",
    bestScore: 5,
    totalQuestions: 5,
    attemptsCount: 1,
    timeSpentMinutes: 15,
    createdAt: "2026-10-23T09:30:00.000Z",
    updatedAt: "2026-10-23T09:45:00.000Z"
  },
  {
    topicId: "quant_ratio_prop",
    subject: "Quantitative Techniques",
    // Strictly 'viewed' — ratio-proportion assessment is STILL PENDING!
    status: "viewed",
    bestScore: 0,
    totalQuestions: 6,
    attemptsCount: 0,
    timeSpentMinutes: 15,
    createdAt: "2026-10-23T09:45:00.000Z",
    updatedAt: "2026-10-23T10:00:00.000Z"
  },
  {
    topicId: "lr_number_series_basic",
    subject: "Logical Reasoning",
    status: "mastered",
    bestScore: 5,
    totalQuestions: 5,
    attemptsCount: 1,
    timeSpentMinutes: 12,
    createdAt: "2026-10-23T10:05:00.000Z",
    updatedAt: "2026-10-23T10:17:00.000Z"
  },
  {
    topicId: "lr_number_series_adv",
    subject: "Logical Reasoning",
    // 6/8 before reviewing mistakes — marked quiz_attempted (needs mistake review/revision to reach full mastery)
    status: "quiz_attempted",
    bestScore: 6,
    totalQuestions: 8,
    attemptsCount: 1,
    timeSpentMinutes: 18,
    createdAt: "2026-10-23T10:18:00.000Z",
    updatedAt: "2026-10-23T10:36:00.000Z"
  },
  {
    topicId: "gk_indian_polity_const",
    subject: "General Knowledge",
    status: "mastered",
    bestScore: 7,
    totalQuestions: 7,
    attemptsCount: 1,
    timeSpentMinutes: 20,
    createdAt: "2026-10-23T10:40:00.000Z",
    updatedAt: "2026-10-23T11:00:00.000Z"
  }
];
var INITIAL_QUIZ_ATTEMPTS = [
  {
    id: "att_day1_lr_basic",
    quizId: "quiz_lr_series_basic",
    title: "Day 1: Basic Number Series Quiz",
    subject: "Logical Reasoning",
    topicId: "lr_number_series_basic",
    score: 5,
    total: 5,
    accuracyPercent: 100,
    durationSeconds: 340,
    passed: true,
    status: "completed",
    createdAt: "2026-10-23T10:16:00.000Z"
  },
  {
    id: "att_day1_lr_adv",
    quizId: "quiz_lr_series_adv",
    title: "Day 1: Advanced Number Series Quiz",
    subject: "Logical Reasoning",
    topicId: "lr_number_series_adv",
    score: 6,
    total: 8,
    accuracyPercent: 75,
    durationSeconds: 580,
    passed: true,
    status: "completed",
    createdAt: "2026-10-23T10:35:00.000Z"
  },
  {
    id: "att_day1_gk_polity",
    quizId: "quiz_gk_polity_day1",
    title: "Day 1: Indian Constitution & Polity GK Quiz",
    subject: "General Knowledge",
    topicId: "gk_indian_polity_const",
    score: 7,
    total: 7,
    accuracyPercent: 100,
    durationSeconds: 310,
    passed: true,
    status: "completed",
    createdAt: "2026-10-23T10:58:00.000Z"
  }
];
var INITIAL_ERROR_LOG = [
  {
    id: "err_day1_lr_wrong_term",
    questionId: "q_lr_adv_7",
    subject: "Logical Reasoning",
    topicId: "lr_number_series_adv",
    questionText: "Identify the wrong term in the series: 69, 55, 26, 13, 5",
    studentAnswer: "13",
    correctAnswer: "55 (or pattern sum/product of digits + 1: 6*9+1=55, 5*5+1=26, 2*6+1=13, 1*3+1=4 -> 5 is wrong; in consecutive difference check review carefully)",
    mistakeType: "conceptual",
    explanation: "Each next term follows (product of digits of previous term) + 1: 6x9 + 1 = 55; 5x5 + 1 = 26; 2x6 + 1 = 13; 1x3 + 1 = 4 (not 5). Always test digit-product patterns when differences jump irregularly.",
    resolved: false,
    createdAt: "2026-10-23T10:35:30.000Z",
    updatedAt: "2026-10-23T10:35:30.000Z"
  },
  {
    id: "err_day1_lr_alternating_cubes",
    questionId: "q_lr_adv_5",
    subject: "Logical Reasoning",
    topicId: "lr_number_series_adv",
    questionText: "Find the missing term in the series: 2, 9, 28, 65, 126, ?",
    studentAnswer: "215",
    correctAnswer: "217",
    mistakeType: "calculation",
    explanation: "The pattern is n^3 + 1 (not n^3 - 1): 1^3+1=2, 2^3+1=9, 3^3+1=28, 4^3+1=65, 5^3+1=126, so 6^3+1 = 216 + 1 = 217. Watch the +1 vs -1 sign on cube series.",
    resolved: false,
    createdAt: "2026-10-23T10:35:45.000Z",
    updatedAt: "2026-10-23T10:35:45.000Z"
  }
];
var INITIAL_NOTES = [
  {
    id: "note_day1_quant_pct_ratio",
    title: "Day 1 Quant Notes: Percentages, Successive Change & Ratio Intro",
    subject: "Quantitative Techniques",
    topicId: "quant_ratio_prop",
    content: `### 1. Core Percentage Multipliers
- **+20% increase** $\\rightarrow \\times \\frac{6}{5}$; to return to original base, reduce by $\\frac{1}{6} = 16.67\\%$.
- **+25% increase** $\\rightarrow \\times \\frac{5}{4}$; reverse reduction $= \\frac{1}{5} = 20\\%$.
- **Successive Change Formula:** Net $\\% = a + b + \\frac{ab}{100}$.

### 2. Ratio & Proportion Foundations (Assessment Pending)
- If $A:B = 2:3$ and $B:C = 4:5$, make middle term $B$ equal ($\\text{LCM}(3,4)=12$):
  $$A:B:C = 8:12:15$$
- **Fractional Ratio Rule:** For $\\frac{1}{2} : \\frac{1}{3} : \\frac{1}{5} : \\frac{1}{8}$, multiply all terms by $\\text{LCM}(2,3,5,8) = 120$:
  $$60 : 40 : 24 : 15 \\quad (\\text{Sum} = 139)$$`,
    createdAt: "2026-10-23T10:00:00.000Z",
    updatedAt: "2026-10-23T10:00:00.000Z"
  },
  {
    id: "note_day1_gk_constitution",
    title: "Day 1 GK Notes: Indian Constitution & Polity (7/7 Mastered)",
    subject: "General Knowledge",
    topicId: "gk_indian_polity_const",
    content: `### Key Constitutional Milestones
- **Adopted on:** 26 November 1949 (Constitution Day / Samvidhan Divas)
- **Came into force (Commencement):** 26 January 1950
- **Drafting Committee Chairman:** Dr. B. R. Ambedkar
- **42nd Constitutional Amendment (1976):** Added Fundamental Duties (Part IV-A, Article 51A) & words *Socialist, Secular, Integrity* to the Preamble.
- **High-Yield Articles (CMAT 2025):**
  - **Article 14:** Equality before law
  - **Article 21:** Protection of life and personal liberty
  - **Article 24:** Prohibition of employment of children in factories
  - **Article 50:** Separation of judiciary from executive`,
    createdAt: "2026-10-23T11:00:00.000Z",
    updatedAt: "2026-10-23T11:00:00.000Z"
  }
];
var INITIAL_CONVERSATIONS = [
  {
    id: "conv_day1_cmat_session",
    title: "Day 1 Session: Quant Ratios, LR Number Series & Polity GK",
    subjectTag: "CMAT 2026 Course",
    archived: false,
    messageCount: 4,
    lastMessagePreview: "Shabash! Bilkul sahi \u2014 29 ke baad agla prime number 31 aata hai. Next: Ratio & Proportion assessment.",
    createdAt: "2026-10-23T09:05:00.000Z",
    updatedAt: "2026-10-23T11:02:00.000Z"
  }
];
var INITIAL_MESSAGES = {
  conv_day1_cmat_session: [
    {
      id: "msg_seed_1",
      conversationId: "conv_day1_cmat_session",
      role: "user",
      content: "Mitra, humne Quant mein Fractions, Decimals, Percentages finish kar liya aur Ratio & Proportion ka intro dekha. LR mein Basic Series (5/5) aur Advanced Series (6/8) kiya. Prime number wale follow-up ka answer: 29 ke baad 31 aata hai na?",
      sourceMode: "user",
      modelUsed: "user",
      attachmentName: "none",
      createdAt: "2026-10-23T10:59:00.000Z"
    },
    {
      id: "msg_seed_2",
      conversationId: "conv_day1_cmat_session",
      role: "assistant",
      content: `Bilkul sahi jawab! **29 ke turant baad agla prime number 31 hi aata hai** (kyunki 30 toh 2, 3, 5 se divide ho jata hai, jabki 31 sirf 1 aur 31 se divide hota hai).

### Aapka Day 1 Saved Summary
| Subject | Completed Work | Current Status |
|---|---|---|
| **Quantitative Techniques** | Fractions, Decimals, % Changes + Intro to Ratio & Proportion | Lesson viewed \xB7 **Ratio-Proportion Assessment Pending** |
| **Logical Reasoning** | Basic Series (**5/5**), Advanced Series (**6/8**), Prime check (29 $\\rightarrow$ 31) | 2 mistakes saved in Error Log for quick review |
| **General Knowledge** | Indian Constitution (26 Nov 1949 / 26 Jan 1950, Dr. Ambedkar, FR/FD, 42nd Amendment, Parliament & President) | Day 1 GK Quiz **7/7 Passed** |

### Agla Kadam (Next Planned Session)
1. **Quant:** Ratio & Proportion ko continue karke uska pending assessment complete karenge.
2. **Logical Reasoning:** Advanced Series ki 2 galtiyan (6/8) revise karke naya topic (**Coding-Decoding / Direction Sense**) shuru karenge.
3. **Language Comprehension:** Basic Grammar aur Sentence Correction bilkul zero se start karenge.

Jab bhi aap taiyar hon, bas **"Continue"**, **"Aage badho"**, ya **"Quiz me on Ratio & Proportion"** likhein!`,
      sourceMode: "live",
      modelUsed: "gemini-3.8-flash",
      attachmentName: "none",
      createdAt: "2026-10-23T11:00:30.000Z"
    }
  ]
};

// server/storage.ts
var ForbiddenOwnershipError = class extends Error {
  constructor(message = "Forbidden: Resource belongs to a different user workspace.") {
    super(message);
    this.statusCode = 403;
    this.name = "ForbiddenOwnershipError";
  }
};
var IS_SERVERLESS_RUNTIME = Boolean(process.env.VERCEL) || Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME);
var DATA_DIR = IS_SERVERLESS_RUNTIME ? path2.join(os.tmpdir(), "mitra-data") : path2.resolve(process.cwd(), "data");
var PRINCIPALS_DIR = path2.join(DATA_DIR, "principals");
var UPLOADS_DIR = path2.join(DATA_DIR, "uploads");
function ensureDirs() {
  if (!fs2.existsSync(PRINCIPALS_DIR)) {
    fs2.mkdirSync(PRINCIPALS_DIR, { recursive: true });
  }
  if (!fs2.existsSync(UPLOADS_DIR)) {
    fs2.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}
function hashPrincipalKey(principalId) {
  return crypto2.createHash("sha256").update(principalId).digest("hex").slice(0, 32);
}
function getPrincipalUploadsDir(principalId) {
  ensureDirs();
  const dir = path2.join(UPLOADS_DIR, hashPrincipalKey(principalId));
  if (!fs2.existsSync(dir)) {
    fs2.mkdirSync(dir, { recursive: true });
  }
  return dir;
}
function getPrincipalStorePath(principalId) {
  return path2.join(PRINCIPALS_DIR, `${hashPrincipalKey(principalId)}.json`);
}
function createInitialStoreForPrincipal(principalId) {
  const shortSuffix = hashPrincipalKey(principalId).slice(0, 8);
  const seededConvs = structuredClone(INITIAL_CONVERSATIONS).map((c) => ({
    ...c,
    id: `${c.id}_${shortSuffix}`
  }));
  const seededMessages = {};
  for (let i = 0; i < INITIAL_CONVERSATIONS.length; i++) {
    const origId = INITIAL_CONVERSATIONS[i].id;
    const scopedId = seededConvs[i].id;
    seededMessages[scopedId] = (structuredClone(INITIAL_MESSAGES[origId]) || []).map((m) => ({
      ...m,
      id: `${m.id}_${shortSuffix}`,
      conversationId: scopedId
    }));
  }
  return {
    ownerPrincipalId: principalId,
    profile: {
      ...structuredClone(INITIAL_USER_PROFILE),
      ownerId: principalId
    },
    conversations: seededConvs,
    messagesByConversation: seededMessages,
    topicProgress: structuredClone(INITIAL_TOPIC_PROGRESS),
    quizAttempts: structuredClone(INITIAL_QUIZ_ATTEMPTS),
    errorLog: structuredClone(INITIAL_ERROR_LOG),
    notes: structuredClone(INITIAL_NOTES),
    uploadedDocuments: []
  };
}
var memoryStores = /* @__PURE__ */ new Map();
var conversationOwnerRegistry = /* @__PURE__ */ new Map();
var noteOwnerRegistry = /* @__PURE__ */ new Map();
var errorOwnerRegistry = /* @__PURE__ */ new Map();
function registerOwnership(store) {
  for (const c of store.conversations) {
    conversationOwnerRegistry.set(c.id, store.ownerPrincipalId);
  }
  for (const n of store.notes) {
    noteOwnerRegistry.set(n.id, store.ownerPrincipalId);
  }
  for (const e of store.errorLog) {
    errorOwnerRegistry.set(e.id, store.ownerPrincipalId);
  }
}
function assertConversationOwnership(principalId, conversationId) {
  const knownOwner = conversationOwnerRegistry.get(conversationId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError("Access denied: Conversation belongs to another student.");
  }
}
function assertNoteOwnership(principalId, noteId) {
  const knownOwner = noteOwnerRegistry.get(noteId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError("Access denied: Study note belongs to another student.");
  }
}
function assertErrorItemOwnership(principalId, errorId) {
  const knownOwner = errorOwnerRegistry.get(errorId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError("Access denied: Error log item belongs to another student.");
  }
}
function getStore(principalId) {
  if (!principalId || typeof principalId !== "string") {
    throw new Error("principalId is required to access workspace storage.");
  }
  ensureDirs();
  const cached = memoryStores.get(principalId);
  if (cached) return cached;
  const isCloudFirebaseUser = principalId.startsWith("firebase:");
  if (!isCloudFirebaseUser) {
    const filePath = getPrincipalStorePath(principalId);
    if (fs2.existsSync(filePath)) {
      try {
        const raw = fs2.readFileSync(filePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed && parsed.ownerPrincipalId === principalId && parsed.profile && Array.isArray(parsed.topicProgress)) {
          memoryStores.set(principalId, parsed);
          registerOwnership(parsed);
          return parsed;
        }
      } catch (err) {
        console.error("Isolated principal store read error, re-initializing:", err);
      }
    }
  }
  const fresh = createInitialStoreForPrincipal(principalId);
  saveStore(principalId, fresh);
  return fresh;
}
function saveStore(principalId, store) {
  ensureDirs();
  store.ownerPrincipalId = principalId;
  memoryStores.set(principalId, store);
  registerOwnership(store);
  if (principalId.startsWith("firebase:")) {
    return;
  }
  const filePath = getPrincipalStorePath(principalId);
  const tmpPath = `${filePath}.tmp`;
  fs2.writeFileSync(tmpPath, JSON.stringify(store, null, 2), "utf-8");
  fs2.renameSync(tmpPath, filePath);
}
function updateProfile(principalId, patch) {
  const store = getStore(principalId);
  const safePatch = {};
  if (typeof patch.displayName === "string") safePatch.displayName = patch.displayName.slice(0, 100);
  if (patch.preferredLanguage && ["hinglish", "english", "hindi"].includes(patch.preferredLanguage)) {
    safePatch.preferredLanguage = patch.preferredLanguage;
  }
  if (patch.explanationDepth && ["step_by_step", "concise"].includes(patch.explanationDepth)) {
    safePatch.explanationDepth = patch.explanationDepth;
  }
  if (typeof patch.currentDay === "number" && Number.isFinite(patch.currentDay)) {
    safePatch.currentDay = Math.max(1, Math.min(365, Math.round(patch.currentDay)));
  }
  if (typeof patch.currentSubject === "string") {
    safePatch.currentSubject = patch.currentSubject.slice(0, 80);
  }
  if (typeof patch.currentTopicId === "string") {
    safePatch.currentTopicId = patch.currentTopicId.slice(0, 128);
  }
  if (typeof patch.studyMinutesToday === "number" && Number.isFinite(patch.studyMinutesToday)) {
    safePatch.studyMinutesToday = Math.max(0, Math.min(1440, Math.round(patch.studyMinutesToday)));
  }
  if (typeof patch.totalStudyMinutes === "number" && Number.isFinite(patch.totalStudyMinutes)) {
    safePatch.totalStudyMinutes = Math.max(0, Math.min(5e5, Math.round(patch.totalStudyMinutes)));
  }
  if (typeof patch.missedDaysOffset === "number" && Number.isFinite(patch.missedDaysOffset)) {
    safePatch.missedDaysOffset = Math.max(0, Math.min(60, Math.round(patch.missedDaysOffset)));
  }
  store.profile = {
    ...store.profile,
    ...safePatch,
    ownerId: principalId,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  saveStore(principalId, store);
  return store.profile;
}
function createConversation(principalId, title, subjectTag) {
  const store = getStore(principalId);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const conv = {
    id: `conv_${Date.now()}_${crypto2.randomBytes(4).toString("hex")}`,
    title: (title || "New Tutoring Session").slice(0, 160),
    subjectTag: (subjectTag || store.profile.currentSubject || "General Tutoring").slice(0, 80),
    archived: false,
    messageCount: 0,
    lastMessagePreview: "",
    createdAt: now,
    updatedAt: now
  };
  store.conversations.unshift(conv);
  store.messagesByConversation[conv.id] = [];
  conversationOwnerRegistry.set(conv.id, principalId);
  saveStore(principalId, store);
  return conv;
}
function updateConversationMeta(principalId, conversationId, patch) {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const idx = store.conversations.findIndex((c) => c.id === conversationId);
  if (idx === -1) return null;
  store.conversations[idx] = {
    ...store.conversations[idx],
    ...patch.title !== void 0 ? { title: String(patch.title).slice(0, 160) } : {},
    ...patch.archived !== void 0 ? { archived: Boolean(patch.archived) } : {},
    ...patch.subjectTag !== void 0 ? { subjectTag: String(patch.subjectTag).slice(0, 80) } : {},
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  saveStore(principalId, store);
  return store.conversations[idx];
}
function deleteConversation(principalId, conversationId) {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const before = store.conversations.length;
  store.conversations = store.conversations.filter((c) => c.id !== conversationId);
  delete store.messagesByConversation[conversationId];
  if (store.conversations.length < before) {
    conversationOwnerRegistry.delete(conversationId);
  }
  saveStore(principalId, store);
  return store.conversations.length < before;
}
function appendMessage(principalId, conversationId, message) {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  let conv = store.conversations.find((c) => c.id === conversationId);
  if (!conv) {
    const now2 = (/* @__PURE__ */ new Date()).toISOString();
    conv = {
      id: conversationId,
      title: "Study Session",
      subjectTag: store.profile.currentSubject || "General Tutoring",
      archived: false,
      messageCount: 0,
      lastMessagePreview: "",
      createdAt: now2,
      updatedAt: now2
    };
    store.conversations.unshift(conv);
    conversationOwnerRegistry.set(conv.id, principalId);
  }
  const list = store.messagesByConversation[conv.id] || [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const item = {
    id: message.id || `msg_${Date.now()}_${crypto2.randomBytes(3).toString("hex")}`,
    conversationId: conv.id,
    role: message.role,
    content: message.content,
    sourceMode: message.sourceMode,
    modelUsed: message.modelUsed,
    attachmentName: message.attachmentName || "none",
    attachments: message.attachments,
    errorReason: message.errorReason,
    errorCategory: message.errorCategory,
    createdAt: now
  };
  list.push(item);
  store.messagesByConversation[conv.id] = list;
  if (message.role === "user" && (conv.title === "New Tutoring Session" || conv.title === "Study Session" || conv.title === "New Chat") && message.content.trim().length > 0) {
    const clean = message.content.replace(/\s+/g, " ").trim();
    conv.title = clean.length > 52 ? `${clean.slice(0, 52)}...` : clean;
  }
  conv.messageCount = list.length;
  conv.lastMessagePreview = message.content.replace(/\s+/g, " ").trim().slice(0, 220);
  conv.updatedAt = now;
  store.conversations = [
    conv,
    ...store.conversations.filter((c) => c.id !== conv.id)
  ];
  saveStore(principalId, store);
  return item;
}
function truncateConversationFromMessage(principalId, conversationId, messageId) {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const list = store.messagesByConversation[conversationId] || [];
  const idx = list.findIndex((m) => m.id === messageId);
  if (idx !== -1) {
    store.messagesByConversation[conversationId] = list.slice(0, idx);
    const conv = store.conversations.find((c) => c.id === conversationId);
    if (conv) {
      const remaining = store.messagesByConversation[conversationId];
      conv.messageCount = remaining.length;
      conv.lastMessagePreview = remaining[remaining.length - 1]?.content.slice(0, 220) || "";
      conv.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
    saveStore(principalId, store);
  }
  return store.messagesByConversation[conversationId] || [];
}
function upsertTopicProgress(principalId, record) {
  const store = getStore(principalId);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const idx = store.topicProgress.findIndex((t) => t.topicId === record.topicId);
  if (idx >= 0) {
    store.topicProgress[idx] = {
      ...store.topicProgress[idx],
      ...record,
      updatedAt: now
    };
    saveStore(principalId, store);
    return store.topicProgress[idx];
  }
  const created = {
    ...record,
    createdAt: now,
    updatedAt: now
  };
  store.topicProgress.push(created);
  saveStore(principalId, store);
  return created;
}
function recordQuizSubmission(principalId, params) {
  const store = getStore(principalId);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const attempt = {
    ...params.attempt,
    id: `att_${Date.now()}_${crypto2.randomBytes(3).toString("hex")}`,
    status: "completed",
    createdAt: now
  };
  store.quizAttempts.unshift(attempt);
  const existingTopic = store.topicProgress.find((t) => t.topicId === attempt.topicId);
  const bestScore = Math.max(existingTopic?.bestScore || 0, attempt.score);
  const attemptsCount = (existingTopic?.attemptsCount || 0) + 1;
  const timeSpentMinutes = (existingTopic?.timeSpentMinutes || 0) + Math.max(1, params.timeSpentMinutes);
  let nextStatus = "quiz_attempted";
  if (attempt.accuracyPercent >= 85) {
    nextStatus = "mastered";
  } else if (attempt.passed) {
    nextStatus = "quiz_passed";
  } else if (existingTopic?.status === "mastered" || existingTopic?.status === "quiz_passed") {
    nextStatus = existingTopic.status;
  }
  const topicProgress = upsertTopicProgress(principalId, {
    topicId: attempt.topicId,
    subject: attempt.subject,
    status: nextStatus,
    bestScore,
    totalQuestions: attempt.total,
    attemptsCount,
    timeSpentMinutes
  });
  store.profile.studyMinutesToday += Math.max(1, params.timeSpentMinutes);
  store.profile.totalStudyMinutes += Math.max(1, params.timeSpentMinutes);
  store.profile.updatedAt = now;
  const addedErrors = [];
  for (const errItem of params.newErrors) {
    const existingErrIdx = store.errorLog.findIndex(
      (e) => e.questionId === errItem.questionId && !e.resolved
    );
    if (existingErrIdx >= 0) {
      store.errorLog[existingErrIdx] = {
        ...store.errorLog[existingErrIdx],
        studentAnswer: errItem.studentAnswer,
        updatedAt: now
      };
      addedErrors.push(store.errorLog[existingErrIdx]);
    } else {
      const createdErr = {
        ...errItem,
        id: `err_${Date.now()}_${crypto2.randomBytes(3).toString("hex")}`,
        resolved: false,
        createdAt: now,
        updatedAt: now
      };
      store.errorLog.unshift(createdErr);
      errorOwnerRegistry.set(createdErr.id, principalId);
      addedErrors.push(createdErr);
    }
  }
  saveStore(principalId, store);
  return { attempt, topicProgress, addedErrors };
}
function updateErrorLogItem(principalId, errorId, patch) {
  assertErrorItemOwnership(principalId, errorId);
  const store = getStore(principalId);
  const idx = store.errorLog.findIndex((e) => e.id === errorId);
  if (idx === -1) return null;
  store.errorLog[idx] = {
    ...store.errorLog[idx],
    ...patch,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  saveStore(principalId, store);
  return store.errorLog[idx];
}
function saveStudyNote(principalId, note) {
  if (note.id) {
    assertNoteOwnership(principalId, note.id);
  }
  const store = getStore(principalId);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  if (note.id) {
    const idx = store.notes.findIndex((n) => n.id === note.id);
    if (idx >= 0) {
      store.notes[idx] = {
        ...store.notes[idx],
        title: String(note.title || "Untitled Note").slice(0, 180),
        subject: note.subject,
        topicId: String(note.topicId || "general").slice(0, 128),
        content: String(note.content || "").slice(0, 16e3),
        updatedAt: now
      };
      saveStore(principalId, store);
      return store.notes[idx];
    }
  }
  const created = {
    id: `note_${Date.now()}_${crypto2.randomBytes(3).toString("hex")}`,
    title: String(note.title || "Untitled Note").slice(0, 180),
    subject: note.subject,
    topicId: String(note.topicId || "general").slice(0, 128),
    content: String(note.content || "").slice(0, 16e3),
    createdAt: now,
    updatedAt: now
  };
  store.notes.unshift(created);
  noteOwnerRegistry.set(created.id, principalId);
  saveStore(principalId, store);
  return created;
}
function deleteStudyNote(principalId, noteId) {
  assertNoteOwnership(principalId, noteId);
  const store = getStore(principalId);
  const before = store.notes.length;
  store.notes = store.notes.filter((n) => n.id !== noteId);
  if (store.notes.length < before) {
    noteOwnerRegistry.delete(noteId);
  }
  saveStore(principalId, store);
  return store.notes.length < before;
}
function registerUploadedDocument(principalId, doc) {
  const store = getStore(principalId);
  store.uploadedDocuments.unshift(doc);
  saveStore(principalId, store);
  return doc;
}

// server/githubOAuth.ts
var githubByPrincipal = /* @__PURE__ */ new Map();
function parseCookies(cookieHeader) {
  const out = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(";")) {
    const idx = part.indexOf("=");
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = decodeURIComponent(part.slice(idx + 1).trim());
      out[k] = v;
    }
  }
  return out;
}
function getRedirectUri(req) {
  const fromQuery = typeof req.query.origin === "string" ? req.query.origin.trim() : "";
  const appUrl = (process.env.APP_URL || "").replace(/\/+$/, "");
  const base = fromQuery || appUrl || `${req.protocol}://${req.get("host")}`;
  return `${base.replace(/\/+$/, "")}/auth/github/callback`;
}
function registerGitHubRoutes(app2) {
  app2.get("/api/github/status", requireAuth, async (req, res) => {
    const principalId = req.principal.principalId;
    const clientId = (process.env.GITHUB_CLIENT_ID || "").trim();
    const clientSecret = (process.env.GITHUB_CLIENT_SECRET || "").trim();
    const oauthConfigured = Boolean(clientId && clientSecret);
    const cookies = parseCookies(req.headers.cookie);
    const existing = githubByPrincipal.get(principalId);
    const token = cookies.mitra_gh_token || existing?.token || null;
    let ghUser = existing?.user || null;
    if (token && !ghUser) {
      try {
        const ghRes = await fetch("https://api.github.com/user", {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "Mitra-AI-Tutor"
          }
        });
        if (ghRes.ok) {
          const data = await ghRes.json();
          ghUser = {
            login: data.login,
            avatar_url: data.avatar_url,
            html_url: data.html_url
          };
          githubByPrincipal.set(principalId, { token, user: ghUser });
        }
      } catch {
      }
    }
    res.json({
      oauthConfigured,
      connected: Boolean(token && ghUser),
      user: ghUser,
      callbackPath: "/auth/github/callback"
    });
  });
  app2.get("/api/github/auth/url", requireAuth, (req, res) => {
    const clientId = (process.env.GITHUB_CLIENT_ID || "").trim();
    if (!clientId) {
      res.status(400).json({
        error: "GITHUB_CLIENT_ID is not configured yet. Add GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET in AI Studio Secrets to connect GitHub OAuth."
      });
      return;
    }
    const redirectUri = getRedirectUri(req);
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      scope: "repo gist read:user"
    });
    res.json({
      url: `https://github.com/login/oauth/authorize?${params.toString()}`,
      redirectUri
    });
  });
  const callbackHandler = async (req, res) => {
    const code = typeof req.query.code === "string" ? req.query.code : "";
    const clientId = (process.env.GITHUB_CLIENT_ID || "").trim();
    const clientSecret = (process.env.GITHUB_CLIENT_SECRET || "").trim();
    if (!code || !clientId || !clientSecret) {
      res.status(400).send("GitHub OAuth callback missing code or server credentials.");
      return;
    }
    try {
      const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          code
        })
      });
      const tokenData = await tokenRes.json();
      if (!tokenData.access_token) {
        res.status(400).send(`GitHub token exchange failed: ${tokenData.error || "Unknown error"}`);
        return;
      }
      res.setHeader(
        "Set-Cookie",
        `mitra_gh_token=${encodeURIComponent(
          tokenData.access_token
        )}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=2592000`
      );
      res.send(`<!doctype html>
<html>
  <body style="font-family: system-ui, sans-serif; padding: 2rem; text-align: center;">
    <h3>GitHub Connected Successfully</h3>
    <p>Returning to Mitra AI Tutor...</p>
    <script>
      if (window.opener) {
        window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', provider: 'github' }, '*');
        window.close();
      } else {
        window.location.href = '/';
      }
    </script>
  </body>
</html>`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).send(`GitHub OAuth error: ${msg}`);
    }
  };
  app2.get(["/auth/github/callback", "/auth/github/callback/"], callbackHandler);
  app2.post("/api/github/export-gist", requireAuth, async (req, res) => {
    const principalId = req.principal.principalId;
    const cookies = parseCookies(req.headers.cookie);
    const token = cookies.mitra_gh_token || githubByPrincipal.get(principalId)?.token;
    if (!token) {
      res.status(401).json({ error: "GitHub account is not connected." });
      return;
    }
    const store = getStore(principalId);
    const markdown = buildProgressExportMarkdown(store);
    try {
      const ghRes = await fetch("https://api.github.com/gists", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/vnd.github+json",
          "Content-Type": "application/json",
          "User-Agent": "Mitra-AI-Tutor"
        },
        body: JSON.stringify({
          description: `Mitra AI Tutor \u2014 CMAT 2026 Day ${store.profile.currentDay} Progress, Notes & Error Log`,
          public: false,
          files: {
            "Mitra_CMAT_2026_Study_Vault.md": {
              content: markdown
            }
          }
        })
      });
      if (!ghRes.ok) {
        const errBody = await ghRes.text();
        res.status(ghRes.status).json({ error: `GitHub API error: ${errBody.slice(0, 200)}` });
        return;
      }
      const gist = await ghRes.json();
      res.json({ url: gist.html_url, id: gist.id });
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });
}
function buildProgressExportMarkdown(store) {
  const lines = [
    `# Mitra AI Tutor \u2014 CMAT 2026 Learning Vault`,
    `Generated: ${(/* @__PURE__ */ new Date()).toISOString()}`,
    `Current Study Day: Day ${store.profile.currentDay} \xB7 Total Study Time: ${store.profile.totalStudyMinutes} mins`,
    ``,
    `## 1. Topic Progress`,
    ...store.topicProgress.map(
      (t) => `- **${t.topicId}** (${t.subject}): Status = \`${t.status}\` \xB7 Best = ${t.bestScore}/${t.totalQuestions} \xB7 Attempts = ${t.attemptsCount}`
    ),
    ``,
    `## 2. Verified Quiz Attempts`,
    ...store.quizAttempts.map(
      (q) => `- **${q.title}** (${q.subject}): **${q.score}/${q.total}** (${q.accuracyPercent}%) \xB7 ${q.passed ? "Passed" : "Needs Retry"}`
    ),
    ``,
    `## 3. Personal Error Log`,
    ...store.errorLog.map(
      (e) => `- [${e.resolved ? "Resolved" : "Needs Review"}] **${e.subject}** (${e.mistakeType}): ${e.questionText}
  - Your Answer: ${e.studentAnswer} | Correct: ${e.correctAnswer}
  - Explanation: ${e.explanation}`
    ),
    ``,
    `## 4. Saved Study Notes & Bookmarks`,
    ...store.notes.map(
      (n) => `### ${n.title} (${n.subject})

${n.content}
`
    )
  ];
  return lines.join("\n");
}

// server/zipExporter.ts
import fs3 from "fs";
import path3 from "path";
import zlib from "zlib";
var EXCLUDED_DIRS = /* @__PURE__ */ new Set([
  "node_modules",
  "dist",
  ".git",
  ".aistudio",
  "data",
  "uploads",
  ".vite",
  ".cache",
  "coverage"
]);
var EXCLUDED_FILES = /* @__PURE__ */ new Set([
  ".env",
  ".env.local",
  ".env.production",
  ".env.development",
  ".DS_Store",
  "bun.lock",
  "package-lock.json"
]);
var CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();
function crc32(buf) {
  let crc = 4294967295;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 255] ^ crc >>> 8;
  }
  return (crc ^ 4294967295) >>> 0;
}
function toDosDateTime(date) {
  const year = Math.max(1980, date.getFullYear());
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = Math.floor(date.getSeconds() / 2);
  const dosTime = (hours & 31) << 11 | (minutes & 63) << 5 | seconds & 31;
  const dosDate = (year - 1980 & 127) << 9 | (month & 15) << 5 | day & 31;
  return { dosTime, dosDate };
}
function collectProjectFiles(rootDir, currentDir, acc) {
  const entries = fs3.readdirSync(currentDir, { withFileTypes: true });
  entries.sort((a, b) => a.name.localeCompare(b.name));
  for (const entry of entries) {
    const name = entry.name;
    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS.has(name)) continue;
      collectProjectFiles(rootDir, path3.join(currentDir, name), acc);
    } else if (entry.isFile()) {
      if (EXCLUDED_FILES.has(name)) continue;
      if (name.startsWith(".env.") && name !== ".env.example") continue;
      if (name.endsWith(".zip") || name.endsWith(".log")) continue;
      const absPath = path3.join(currentDir, name);
      const stat = fs3.statSync(absPath);
      if (stat.size > 10 * 1024 * 1024) continue;
      const relPath = path3.relative(rootDir, absPath).split(path3.sep).join("/");
      acc.push({
        relPath: `mitra-ai-tutor/${relPath}`,
        absPath,
        mtime: stat.mtime
      });
    }
  }
}
function buildProjectZipBuffer(rootDir) {
  const files = [];
  collectProjectFiles(rootDir, rootDir, files);
  const localParts = [];
  const centralParts = [];
  let localOffset = 0;
  for (const file of files) {
    const rawData = fs3.readFileSync(file.absPath);
    const uncompressedSize = rawData.length;
    const checksum = crc32(rawData);
    const deflated = zlib.deflateRawSync(rawData, { level: 6 });
    const useDeflate = deflated.length < uncompressedSize;
    const payload = useDeflate ? deflated : rawData;
    const method = useDeflate ? 8 : 0;
    const compressedSize = payload.length;
    const nameBuf = Buffer.from(file.relPath, "utf8");
    const { dosTime, dosDate } = toDosDateTime(file.mtime);
    const generalPurposeFlag = 2048;
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(67324752, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(generalPurposeFlag, 6);
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(checksum, 14);
    localHeader.writeUInt32LE(compressedSize, 18);
    localHeader.writeUInt32LE(uncompressedSize, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);
    localParts.push(localHeader, nameBuf, payload);
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(33639248, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(generalPurposeFlag, 8);
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(checksum, 16);
    centralHeader.writeUInt32LE(compressedSize, 20);
    centralHeader.writeUInt32LE(uncompressedSize, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(localOffset, 42);
    centralParts.push(centralHeader, nameBuf);
    localOffset += localHeader.length + nameBuf.length + payload.length;
  }
  const centralDirBuffer = Buffer.concat(centralParts);
  const centralDirSize = centralDirBuffer.length;
  const centralDirOffset = localOffset;
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(101010256, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(centralDirSize, 12);
  eocd.writeUInt32LE(centralDirOffset, 16);
  eocd.writeUInt16LE(0, 20);
  return Buffer.concat([...localParts, centralDirBuffer, eocd]);
}

// server.ts
var PORT = Number(process.env.PORT) || 3e3;
var upload = multer({
  storage: multer.diskStorage({
    destination: (req, _file, cb) => {
      const principalId = req.principal?.principalId || "guest:default";
      const destDir = getPrincipalUploadsDir(principalId);
      cb(null, destDir);
    },
    filename: (_req, file, cb) => {
      const safeBase = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
      cb(null, `${Date.now()}_${safeBase}`);
    }
  }),
  limits: {
    fileSize: 15 * 1024 * 1024
  }
});
function buildLearningContextFromStore(principalId, overrideCtx) {
  const store = getStore(principalId);
  const activeTopic = CMAT_SYLLABUS_TOPICS.find((t) => t.id === store.profile.currentTopicId) || CMAT_SYLLABUS_TOPICS[2];
  const completedTopics = store.topicProgress.filter((t) => t.status === "mastered" || t.status === "quiz_passed").map((t) => {
    const meta = CMAT_SYLLABUS_TOPICS.find((s) => s.id === t.topicId);
    return `${meta?.title || t.topicId} (${t.status})`;
  });
  const pendingAssessments = store.topicProgress.filter((t) => t.status === "viewed" || t.status === "quiz_attempted").map((t) => {
    const meta = CMAT_SYLLABUS_TOPICS.find((s) => s.id === t.topicId);
    return `${meta?.title || t.topicId} [status: ${t.status}]`;
  });
  const quizSummary = store.quizAttempts.slice(0, 8).map((q) => `${q.title}: ${q.score}/${q.total} (${q.accuracyPercent}%)`);
  const unresolvedMistakes = store.errorLog.filter((e) => !e.resolved).slice(0, 6).map(
    (e) => `[${e.subject} \xB7 ${e.mistakeType}] Q: "${e.questionText.slice(0, 95)}..." -> Student answered: ${e.studentAnswer} | Correct: ${e.correctAnswer}`
  );
  return {
    preferredLanguage: overrideCtx?.preferredLanguage || store.profile.preferredLanguage,
    explanationDepth: overrideCtx?.explanationDepth || store.profile.explanationDepth,
    conversationTone: overrideCtx?.conversationTone || "friend",
    currentDay: overrideCtx?.currentDay ?? store.profile.currentDay,
    currentSubject: overrideCtx?.currentSubject || store.profile.currentSubject,
    currentTopicTitle: overrideCtx?.currentTopicTitle || activeTopic.title,
    studyMinutesToday: overrideCtx?.studyMinutesToday ?? store.profile.studyMinutesToday,
    completedTopics: overrideCtx?.completedTopics || completedTopics,
    pendingAssessments: overrideCtx?.pendingAssessments || pendingAssessments,
    quizSummary: overrideCtx?.quizSummary || quizSummary,
    unresolvedMistakes: overrideCtx?.unresolvedMistakes || unresolvedMistakes
  };
}
function handleRouteError(res, err) {
  if (err instanceof ForbiddenOwnershipError) {
    res.status(403).json({ error: err.message, code: "FORBIDDEN_OWNERSHIP" });
    return;
  }
  const msg = err instanceof Error ? err.message : String(err);
  res.status(500).json({ error: msg });
}
function createMitraApiApp() {
  const app2 = express();
  app2.use(express.json({ limit: "15mb" }));
  app2.post("/api/auth/guest-session", (req, res) => {
    const existingSessionId = typeof req.body?.sessionId === "string" ? req.body.sessionId.trim() : void 0;
    const issued = issueIsolatedGuestToken(existingSessionId);
    res.json(issued);
  });
  app2.get("/api/ai/status", async (req, res) => {
    try {
      const shouldVerify = req.query.verify === "1" || req.query.verify === "true";
      const status = shouldVerify ? await verifyLiveModelAccess(false) : getAIProviderStatus();
      res.json(status);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/ai/verify", async (_req, res) => {
    try {
      const status = await verifyLiveModelAccess(true);
      res.json(status);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.get("/api/workspace/download-zip", (_req, res) => {
    try {
      const zipBuffer = buildProjectZipBuffer(process.cwd());
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="mitra-ai-tutor-source.zip"');
      res.setHeader("Content-Length", String(zipBuffer.length));
      res.setHeader("Cache-Control", "no-store");
      res.send(zipBuffer);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.get("/api/workspace", requireAuth, (req, res) => {
    try {
      const principalId = req.principal.principalId;
      const store = getStore(principalId);
      res.json({
        ...store,
        authPrincipal: {
          principalId,
          authMode: req.principal.authMode,
          uid: req.principal.uid
        },
        aiStatus: getAIProviderStatus()
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.get("/api/workspace/export-markdown", requireAuth, (req, res) => {
    try {
      const principalId = req.principal.principalId;
      const store = getStore(principalId);
      const md = buildProgressExportMarkdown(store);
      res.setHeader("Content-Type", "text/markdown; charset=utf-8");
      res.send(md);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.patch("/api/profile", requireAuth, (req, res) => {
    try {
      if (!req.body || typeof req.body !== "object") {
        res.status(400).json({ error: "Profile update payload must be a JSON object." });
        return;
      }
      const updated = updateProfile(req.principal.principalId, req.body);
      res.json(updated);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/conversations", requireAuth, (req, res) => {
    try {
      const { title, subjectTag } = req.body || {};
      const conv = createConversation(
        req.principal.principalId,
        typeof title === "string" ? title : void 0,
        typeof subjectTag === "string" ? subjectTag : void 0
      );
      res.json(conv);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.get("/api/conversations/:id/messages", requireAuth, (req, res) => {
    try {
      const convId = String(req.params.id);
      if (!isValidResourceId(convId)) {
        res.status(400).json({ error: "Invalid conversation ID format." });
        return;
      }
      assertConversationOwnership(req.principal.principalId, convId);
      const store = getStore(req.principal.principalId);
      if (!store.conversations.some((c) => c.id === convId)) {
        res.status(404).json({ error: "Conversation not found in your workspace." });
        return;
      }
      res.json(store.messagesByConversation[convId] || []);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.patch("/api/conversations/:id", requireAuth, (req, res) => {
    try {
      const convId = String(req.params.id);
      if (!isValidResourceId(convId)) {
        res.status(400).json({ error: "Invalid conversation ID format." });
        return;
      }
      const updated = updateConversationMeta(req.principal.principalId, convId, req.body || {});
      if (!updated) {
        res.status(404).json({ error: "Conversation not found in your workspace." });
        return;
      }
      res.json(updated);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.delete("/api/conversations/:id", requireAuth, (req, res) => {
    try {
      const convId = String(req.params.id);
      if (!isValidResourceId(convId)) {
        res.status(400).json({ error: "Invalid conversation ID format." });
        return;
      }
      const ok = deleteConversation(req.principal.principalId, convId);
      if (!ok) {
        res.status(404).json({ error: "Conversation not found in your workspace." });
        return;
      }
      res.json({ deleted: true });
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post(
    "/api/documents/upload",
    requireAuth,
    upload.single("file"),
    (req, res) => {
      try {
        if (!req.file) {
          res.status(400).json({ error: "No file uploaded." });
          return;
        }
        const attachment = {
          id: `att_doc_${Date.now()}`,
          name: req.file.originalname,
          mimeType: req.file.mimetype || "application/octet-stream",
          sizeBytes: req.file.size,
          uploadedFileId: req.file.filename
        };
        registerUploadedDocument(req.principal.principalId, attachment);
        res.json(attachment);
      } catch (err) {
        handleRouteError(res, err);
      }
    }
  );
  app2.post("/api/chat/stream", requireAuth, async (req, res) => {
    const principalId = req.principal.principalId;
    const {
      conversationId,
      message,
      attachments,
      editMessageId,
      regenerateOnly,
      modelTier,
      historyOverride,
      learningContextOverride
    } = req.body;
    if (conversationId) {
      if (!isValidResourceId(conversationId)) {
        res.status(400).json({ error: "Invalid conversationId." });
        return;
      }
      try {
        assertConversationOwnership(principalId, conversationId);
      } catch (err) {
        handleRouteError(res, err);
        return;
      }
    }
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders?.();
    const abortController = new AbortController();
    const keepAliveTimer = setInterval(() => {
      if (!res.writableEnded) {
        res.write(": keepalive\n\n");
      }
    }, 1e4);
    res.on("close", () => {
      clearInterval(keepAliveTimer);
      if (!res.writableEnded) {
        abortController.abort();
      }
    });
    const sendEvent = (event, payload) => {
      if (!res.writableEnded) {
        res.write(`event: ${event}
data: ${JSON.stringify(payload)}

`);
      }
    };
    try {
      const store = getStore(principalId);
      let activeConvId = conversationId;
      if (!activeConvId) {
        const created = createConversation(principalId);
        activeConvId = created.id;
      }
      if (editMessageId && isValidResourceId(editMessageId)) {
        truncateConversationFromMessage(principalId, activeConvId, editMessageId);
      } else if (regenerateOnly) {
        const currentMsgs = store.messagesByConversation[activeConvId] || [];
        const lastMsg = currentMsgs[currentMsgs.length - 1];
        if (lastMsg && lastMsg.role === "assistant") {
          truncateConversationFromMessage(principalId, activeConvId, lastMsg.id);
        }
      }
      let savedUserMsg = null;
      if (!regenerateOnly && typeof message === "string" && message.trim().length > 0) {
        savedUserMsg = appendMessage(principalId, activeConvId, {
          role: "user",
          content: message.trim().slice(0, 32e3),
          sourceMode: "user",
          modelUsed: "user",
          attachmentName: attachments && attachments.length > 0 ? attachments.map((a) => a.name).join(", ") : "none",
          attachments
        });
      }
      const historyForModel = Array.isArray(historyOverride) && historyOverride.length > 0 ? historyOverride.filter((m) => m && (m.role === "user" || m.role === "assistant")).map((m) => ({
        role: m.role,
        content: String(m.content || "").slice(0, 32e3),
        attachments: m.attachments
      })) : (getStore(principalId).messagesByConversation[activeConvId] || []).map((m) => ({
        role: m.role,
        content: m.content,
        attachments: m.attachments
      }));
      if (historyForModel.length === 0) {
        sendEvent("error", { message: "Cannot stream response for an empty message." });
        res.end();
        return;
      }
      sendEvent("meta", {
        conversationId: activeConvId,
        userMessage: savedUserMsg
      });
      const learningCtx = buildLearningContextFromStore(principalId, learningContextOverride);
      const principalUploadsDir = getPrincipalUploadsDir(principalId);
      const streamResult = await streamTutorResponse({
        history: historyForModel,
        learningContext: learningCtx,
        uploadsDir: principalUploadsDir,
        modelTier,
        signal: abortController.signal,
        onChunk: (deltaText, modelUsed) => {
          sendEvent("chunk", { delta: deltaText, modelUsed });
        }
      });
      const finalContent = streamResult.fullText.trim() || "*(Generation stopped before completion.)*";
      const savedAssistantMsg = appendMessage(principalId, activeConvId, {
        role: "assistant",
        content: finalContent,
        sourceMode: streamResult.sourceMode,
        modelUsed: streamResult.modelUsed,
        attachmentName: "none",
        errorReason: streamResult.errorReason,
        errorCategory: streamResult.errorCategory
      });
      const existingConv = getStore(principalId).conversations.find((c) => c.id === activeConvId);
      if (existingConv && (existingConv.title === "New Tutoring Session" || existingConv.title === "New Chat" || existingConv.title === "Study Session") && typeof message === "string" && message.trim().length > 0) {
        const cleanTitle = message.trim().replace(/\s+/g, " ").slice(0, 48);
        updateConversationMeta(principalId, activeConvId, {
          title: cleanTitle.length < message.trim().length ? `${cleanTitle}\u2026` : cleanTitle
        });
      }
      const updatedConv = getStore(principalId).conversations.find((c) => c.id === activeConvId);
      sendEvent("done", {
        conversation: updatedConv,
        assistantMessage: savedAssistantMsg,
        aiStatus: getAIProviderStatus()
      });
      res.end();
    } catch (err) {
      if (abortController.signal.aborted || err instanceof Error && err.message === "ABORTED_BY_USER") {
        res.end();
        return;
      }
      const msg = err instanceof Error ? err.message : String(err);
      sendEvent("error", { message: msg });
      res.end();
    } finally {
      clearInterval(keepAliveTimer);
    }
  });
  app2.post("/api/ai/tool", requireAuth, async (req, res) => {
    try {
      const principalId = req.principal.principalId;
      const { prompt, attachments, learningContextOverride } = req.body;
      if (!prompt || !prompt.trim()) {
        res.status(400).json({ error: "Prompt is required." });
        return;
      }
      const learningCtx = buildLearningContextFromStore(principalId, learningContextOverride);
      const out = await generateTutorActionText({
        prompt: prompt.trim().slice(0, 16e3),
        attachments,
        learningContext: learningCtx,
        uploadsDir: getPrincipalUploadsDir(principalId)
      });
      res.json(out);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/ai/transcribe", requireAuth, async (req, res) => {
    try {
      const { audioBase64, mimeType } = req.body;
      if (!audioBase64) {
        res.status(400).json({ error: "Audio data is required." });
        return;
      }
      const out = await transcribeStudentAudio({
        audioBase64,
        mimeType: mimeType || "audio/webm"
      });
      res.json(out);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/ai/tts", requireAuth, async (req, res) => {
    try {
      const { text } = req.body;
      if (!text || !text.trim()) {
        res.status(400).json({ error: "Text is required for speech synthesis." });
        return;
      }
      const out = await synthesizeTutorSpeech({ text });
      res.json(out);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/learning/topic", requireAuth, (req, res) => {
    try {
      if (!req.body?.topicId || !isValidResourceId(req.body.topicId)) {
        res.status(400).json({ error: "Valid topicId is required." });
        return;
      }
      const updated = upsertTopicProgress(req.principal.principalId, req.body);
      res.json(updated);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/learning/quiz-submit", requireAuth, (req, res) => {
    try {
      const principalId = req.principal.principalId;
      if (!req.body?.attempt || typeof req.body.attempt.quizId !== "string") {
        res.status(400).json({ error: "Valid quiz attempt payload is required." });
        return;
      }
      const result = recordQuizSubmission(principalId, {
        attempt: req.body.attempt,
        newErrors: Array.isArray(req.body.newErrors) ? req.body.newErrors : [],
        timeSpentMinutes: Number(req.body.timeSpentMinutes) || 1
      });
      res.json({
        ...result,
        profile: getStore(principalId).profile
      });
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.patch("/api/learning/error-log/:id", requireAuth, (req, res) => {
    try {
      const errId = String(req.params.id);
      if (!isValidResourceId(errId)) {
        res.status(400).json({ error: "Invalid error log ID." });
        return;
      }
      const updated = updateErrorLogItem(req.principal.principalId, errId, req.body || {});
      if (!updated) {
        res.status(404).json({ error: "Error log entry not found in your workspace." });
        return;
      }
      res.json(updated);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.post("/api/learning/notes", requireAuth, (req, res) => {
    try {
      if (!req.body?.title || typeof req.body.content !== "string") {
        res.status(400).json({ error: "Note title and content are required." });
        return;
      }
      const saved = saveStudyNote(req.principal.principalId, req.body);
      res.json(saved);
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  app2.delete("/api/learning/notes/:id", requireAuth, (req, res) => {
    try {
      const noteId = String(req.params.id);
      if (!isValidResourceId(noteId)) {
        res.status(400).json({ error: "Invalid note ID." });
        return;
      }
      const ok = deleteStudyNote(req.principal.principalId, noteId);
      if (!ok) {
        res.status(404).json({ error: "Study note not found in your workspace." });
        return;
      }
      res.json({ deleted: true });
    } catch (err) {
      handleRouteError(res, err);
    }
  });
  registerGitHubRoutes(app2);
  return app2;
}
async function startServer() {
  const app2 = createMitraApiApp();
  const distPath = path4.resolve(process.cwd(), "dist");
  const isProd = process.env.NODE_ENV === "production" && fs4.existsSync(path4.join(distPath, "index.html"));
  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app2.use(vite.middlewares);
  } else {
    app2.use(express.static(distPath));
    app2.get("*", (_req, res) => {
      res.sendFile(path4.join(distPath, "index.html"));
    });
  }
  app2.listen(PORT, "0.0.0.0", () => {
    const status = getAIProviderStatus();
    console.log(
      `Mitra AI Tutor server listening on http://0.0.0.0:${PORT} | AI: ${status.provider} (${status.activeModel}) | Live=${status.liveAvailable}`
    );
  });
}
var currentFilePath = fileURLToPath(import.meta.url);
var entryArgPath = process.argv[1] ? path4.resolve(process.argv[1]) : "";
if (currentFilePath === entryArgPath && !process.env.VERCEL) {
  startServer().catch((err) => {
    console.error("Fatal server startup error:", err);
    process.exit(1);
  });
}

// server/vercelEntry.ts
var app = createMitraApiApp();
var vercelEntry_default = app;
export {
  vercelEntry_default as default
};
