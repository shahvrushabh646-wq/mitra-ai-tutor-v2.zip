import assert from 'node:assert/strict';
import http from 'node:http';
import { createMitraApiApp } from '../server.ts';

async function runApiSecurityAndPersistenceTests() {
  const app = createMitraApiApp();
  const server = http.createServer(app);

  await new Promise<void>((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve());
  });

  const addr = server.address();
  assert.ok(addr && typeof addr === 'object', 'Ephemeral test server must bind a port');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  try {
    // 1. Unauthenticated Requests to Private Endpoints MUST Return 401 (P0)
    const privateEndpoints: Array<{ method: string; path: string; body?: unknown }> = [
      { method: 'GET', path: '/api/workspace' },
      { method: 'PATCH', path: '/api/profile', body: { studyMinutesToday: 120 } },
      { method: 'POST', path: '/api/conversations', body: { title: 'Test' } },
      { method: 'POST', path: '/api/chat/stream', body: { conversationId: 'conv_day1_session', message: 'Hi' } },
      { method: 'POST', path: '/api/learning/notes', body: { title: 'Note', subject: 'General Knowledge', topicId: 't1', content: 'abc' } },
      { method: 'POST', path: '/api/learning/quiz-submit', body: {} },
      { method: 'GET', path: '/api/workspace/export-markdown' },
    ];

    for (const ep of privateEndpoints) {
      const noAuthRes = await fetch(`${baseUrl}${ep.path}`, {
        method: ep.method,
        headers: ep.body ? { 'Content-Type': 'application/json' } : undefined,
        body: ep.body ? JSON.stringify(ep.body) : undefined,
      });
      assert.equal(
        noAuthRes.status,
        401,
        `Unauthenticated ${ep.method} ${ep.path} must return 401, got ${noAuthRes.status}`
      );

      // Forged token must also return 401
      const forgedRes = await fetch(`${baseUrl}${ep.path}`, {
        method: ep.method,
        headers: {
          Authorization: 'Bearer mitra_guest.fake_session.1700000000.forgedsignature',
          ...(ep.body ? { 'Content-Type': 'application/json' } : {}),
        },
        body: ep.body ? JSON.stringify(ep.body) : undefined,
      });
      assert.equal(
        forgedRes.status,
        401,
        `Forged token on ${ep.method} ${ep.path} must return 401, got ${forgedRes.status}`
      );
    }

    // 2. Provision Two Distinct Student Principals (Student A & Student B)
    const sessionARes = await fetch(`${baseUrl}/api/auth/guest-session`, { method: 'POST' });
    assert.equal(sessionARes.status, 200);
    const sessionA = (await sessionARes.json()) as { token: string; principalId: string };
    assert.ok(sessionA.token.startsWith('mitra_guest.'));

    const sessionBRes = await fetch(`${baseUrl}/api/auth/guest-session`, { method: 'POST' });
    assert.equal(sessionBRes.status, 200);
    const sessionB = (await sessionBRes.json()) as { token: string; principalId: string };
    assert.notEqual(sessionA.principalId, sessionB.principalId);

    const headersA = {
      Authorization: `Bearer ${sessionA.token}`,
      'Content-Type': 'application/json',
    };
    const headersB = {
      Authorization: `Bearer ${sessionB.token}`,
      'Content-Type': 'application/json',
    };

    // 3. Student A Creates Private Conversation & Note; Student B Must Get 403 & Zero Data Leakage (P0)
    const convARes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: headersA,
      body: JSON.stringify({
        title: 'Student A Private Quant Session',
        subjectTag: 'Quantitative Techniques',
      }),
    });
    assert.ok(convARes.ok, `Expected 2xx creating conversation, got ${convARes.status}`);
    const convA = (await convARes.json()) as { id: string; title: string };

    const noteARes = await fetch(`${baseUrl}/api/learning/notes`, {
      method: 'POST',
      headers: headersA,
      body: JSON.stringify({
        title: 'Student A Secret Formula Sheet',
        subject: 'Quantitative Techniques',
        topicId: 'quant_ratio_prop',
        content: 'CI - SI for 2 years = P(R/100)^2',
      }),
    });
    assert.ok(noteARes.ok, `Expected 2xx creating note, got ${noteARes.status}`);
    const noteA = (await noteARes.json()) as { id: string };

    // Student B loads their own workspace — must NOT contain Student A's conversation or note
    const wsBRes = await fetch(`${baseUrl}/api/workspace`, { headers: headersB });
    assert.equal(wsBRes.status, 200);
    const wsB = await wsBRes.json();
    assert.equal(
      wsB.conversations.some((c: { id: string }) => c.id === convA.id),
      false,
      'Student B workspace must NEVER leak Student A conversations'
    );
    assert.equal(
      wsB.notes.some((n: { id: string }) => n.id === noteA.id),
      false,
      'Student B workspace must NEVER leak Student A study notes'
    );

    // Student B attempts direct ID access/mutation/deletion on Student A's resources -> 403 Forbidden
    const crossReadMsgs = await fetch(`${baseUrl}/api/conversations/${convA.id}/messages`, {
      headers: headersB,
    });
    assert.equal(crossReadMsgs.status, 403, 'Cross-user message read must return 403');

    const crossPatchConv = await fetch(`${baseUrl}/api/conversations/${convA.id}`, {
      method: 'PATCH',
      headers: headersB,
      body: JSON.stringify({ title: 'Hacked Title' }),
    });
    assert.equal(crossPatchConv.status, 403, 'Cross-user conversation rename must return 403');

    const crossDeleteConv = await fetch(`${baseUrl}/api/conversations/${convA.id}`, {
      method: 'DELETE',
      headers: headersB,
    });
    assert.equal(crossDeleteConv.status, 403, 'Cross-user conversation delete must return 403');

    const crossDeleteNote = await fetch(`${baseUrl}/api/learning/notes/${noteA.id}`, {
      method: 'DELETE',
      headers: headersB,
    });
    assert.equal(crossDeleteNote.status, 403, 'Cross-user note delete must return 403');

    // 4. Quiz Submission Persistence & Isolation (+4 / -1 NTA Raw Marks)
    const quizSubRes = await fetch(`${baseUrl}/api/learning/quiz-submit`, {
      method: 'POST',
      headers: headersA,
      body: JSON.stringify({
        attempt: {
          quizId: 'sec_quant_di_timed',
          title: 'Timed Sectional Test 1: Quant & DI',
          subject: 'Quantitative Techniques',
          topicId: 'quant_ratio_prop',
          examFormat: 'sectional_test',
          score: 5,
          total: 6,
          rawMarks: 19,
          maxMarks: 24,
          unattemptedCount: 0,
          accuracyPercent: 83,
          durationSeconds: 310,
          passed: true,
        },
        newErrors: [
          {
            questionId: 'sec_q_6',
            subject: 'Quantitative Techniques',
            topicId: 'quant_tsd_time_work',
            questionText: 'Sample wrong question for Student A',
            studentAnswer: 'Option 1',
            correctAnswer: 'Option 2',
            mistakeType: 'calculation',
            explanation: 'Check LCM rate carefully.',
          },
        ],
        timeSpentMinutes: 6,
      }),
    });
    assert.ok(quizSubRes.ok, `Expected 2xx submitting quiz, got ${quizSubRes.status}`);
    const quizSubData = await quizSubRes.json();
    assert.equal(quizSubData.attempt.rawMarks, 19);
    assert.equal(quizSubData.topicProgress.status, 'quiz_passed');

    // Reload Student A workspace and verify persistence
    const wsAReloadRes = await fetch(`${baseUrl}/api/workspace`, { headers: headersA });
    const wsAReload = await wsAReloadRes.json();
    assert.ok(
      wsAReload.quizAttempts.some((a: { quizId: string; rawMarks?: number }) => a.quizId === 'sec_quant_di_timed' && a.rawMarks === 19),
      'Submitted sectional test with NTA rawMarks must persist on reload'
    );

    // 5. SSE Streaming Endpoint & History Preservation Test
    const streamRes = await fetch(`${baseUrl}/api/chat/stream`, {
      method: 'POST',
      headers: headersA,
      body: JSON.stringify({
        conversationId: convA.id,
        message: 'Teach me Time and Work LCM trick in brief.',
        modelTier: 'fast',
      }),
    });
    assert.equal(streamRes.status, 200);
    assert.ok(
      streamRes.headers.get('content-type')?.includes('text/event-stream'),
      'Chat stream must return text/event-stream content type'
    );

    const rawSse = await streamRes.text();
    assert.ok(rawSse.includes('event: chunk'), 'SSE stream must emit chunk events');
    assert.ok(rawSse.includes('event: done'), 'SSE stream must emit final done event');

    // Verify both user prompt and assistant response persisted in Student A's conversation
    const savedMsgsRes = await fetch(`${baseUrl}/api/conversations/${convA.id}/messages`, {
      headers: headersA,
    });
    assert.equal(savedMsgsRes.status, 200);
    const savedMsgs = (await savedMsgsRes.json()) as Array<{ role: string; content: string }>;
    assert.equal(savedMsgs.length, 2, 'Both user prompt and assistant reply must persist');
    assert.equal(savedMsgs[0].role, 'user');
    assert.equal(savedMsgs[1].role, 'assistant');
    assert.ok(savedMsgs[1].content.length > 20);

    console.log(
      'PASS: All API authentication (401), cross-student isolation (403), NTA quiz persistence, and SSE streaming tests succeeded.'
    );
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
}

void runApiSecurityAndPersistenceTests();
