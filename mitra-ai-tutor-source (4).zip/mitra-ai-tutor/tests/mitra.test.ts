import assert from 'node:assert/strict';
import {
  resolveModelConfig,
  getAIProviderStatus,
  buildMitraSystemInstruction,
  buildOfflineTutorFallback,
  classifyProviderError,
  markModelCooldown,
  isModelInCooldown,
  resetModelCooldownsForTest,
} from '../server/aiProvider.ts';
import {
  computeDailyProgressCard,
  computeDynamicNextRecommendation,
  computeSectionAnalytics,
} from '../src/lib/progressCalculator.ts';
import {
  CMAT_SYLLABUS_TOPICS,
  INITIAL_ERROR_LOG,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_TOPIC_PROGRESS,
  INITIAL_USER_PROFILE,
} from '../src/data/cmatCurriculum.ts';
import { QUIZ_BANK, validateQuestionBank } from '../src/data/questionBank.ts';

function runMitraTests() {
  // 1. Model Adapter Resolution & Deprecated Model Normalization
  const originalModel = process.env.MODEL;
  process.env.MODEL = 'gemini-1.5-flash';
  const normalized = resolveModelConfig();
  assert.ok(
    ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'].includes(
      normalized.activeModel
    ),
    'Deprecated model must normalize to a supported Gemini model'
  );
  assert.equal(normalized.wasNormalizedFromDeprecated, true);

  if (originalModel === undefined) {
    delete process.env.MODEL;
  } else {
    process.env.MODEL = originalModel;
  }

  // 2. AI Provider Error Classification & Circuit-Breaker Cooldowns (P0)
  resetModelCooldownsForTest();
  const authErr = classifyProviderError(new Error('HTTP 401 API_KEY_INVALID'));
  assert.equal(authErr.category, 'auth_invalid');
  assert.equal(authErr.shouldFailoverModel, false);

  const quotaErr = classifyProviderError(new Error('429 RESOURCE_EXHAUSTED quota exceeded'));
  assert.equal(quotaErr.category, 'quota_exhausted');
  assert.equal(quotaErr.shouldFailoverModel, true);
  assert.ok(quotaErr.cooldownMs > 0);

  const unsupportedErr = classifyProviderError(
    new Error('404 Model is not supported for generateContent')
  );
  assert.equal(unsupportedErr.category, 'model_unsupported');
  assert.equal(unsupportedErr.isRetryableSameModel, false);
  assert.equal(unsupportedErr.shouldFailoverModel, true);

  const timeoutErr = classifyProviderError(new Error('Request timed out after 12000ms'));
  assert.equal(timeoutErr.category, 'timeout');
  assert.equal(timeoutErr.shouldFailoverModel, true);

  markModelCooldown('dead-model-x', 60_000, 'model_unsupported', '404 Not Found');
  assert.equal(isModelInCooldown('dead-model-x'), true);
  resetModelCooldownsForTest();
  assert.equal(isModelInCooldown('dead-model-x'), false);

  // 3. Dynamic Progress & Recommendation Engine (P1 — No Hardcoded Day 1 Logic)
  const day1Card = computeDailyProgressCard({
    dayNumber: 1,
    profile: INITIAL_USER_PROFILE,
    topicProgress: INITIAL_TOPIC_PROGRESS,
    quizAttempts: INITIAL_QUIZ_ATTEMPTS,
    errorLog: INITIAL_ERROR_LOG,
  });

  const quantRow = day1Card.subjects.find((s) => s.subject === 'Quantitative Techniques');
  assert.ok(quantRow, 'Quant row must exist on Day 1 card');
  assert.equal(
    quantRow.completed,
    false,
    'Quant must NOT be marked completed while Ratio & Proportion assessment is pending'
  );
  assert.equal(quantRow.pendingAssessment, true);
  assert.equal(
    day1Card.nextRecommendedAction.topicId,
    'quant_ratio_prop',
    'Dynamic engine must prioritize pending assessment on viewed topic first'
  );

  // Once Ratio & Proportion is mastered, recommendation dynamically shifts to unresolved mistakes!
  const upgradedTopics = INITIAL_TOPIC_PROGRESS.map((t) =>
    t.topicId === 'quant_ratio_prop'
      ? { ...t, status: 'mastered' as const, bestScore: 6, totalQuestions: 6, attemptsCount: 1 }
      : t
  );
  const recAfterRatioPassed = computeDynamicNextRecommendation({
    profile: INITIAL_USER_PROFILE,
    topicProgress: upgradedTopics,
    quizAttempts: INITIAL_QUIZ_ATTEMPTS,
    errorLog: INITIAL_ERROR_LOG,
  });
  assert.ok(
    recAfterRatioPassed.label.includes('Mistake') ||
      recAfterRatioPassed.label.includes('Error') ||
      recAfterRatioPassed.topicId === 'lr_number_series_adv',
    'Once pending quiz is passed, dynamic engine must surface unresolved mistakes next'
  );

  // Once mistakes are also resolved and student moves to Day 5, recommendation targets Day 5 unstarted syllabus!
  const resolvedAllErrors = INITIAL_ERROR_LOG.map((e) => ({ ...e, resolved: true }));
  const day5Rec = computeDynamicNextRecommendation({
    profile: { ...INITIAL_USER_PROFILE, currentDay: 5 },
    topicProgress: upgradedTopics,
    quizAttempts: INITIAL_QUIZ_ATTEMPTS,
    errorLog: resolvedAllErrors,
  });
  const day5TopicIds = CMAT_SYLLABUS_TOPICS.filter((t) => t.dayNumber === 5).map((t) => t.id);
  assert.ok(
    day5TopicIds.includes(day5Rec.topicId),
    `Day 5 recommendation (${day5Rec.topicId}) must dynamically target Day 5 syllabus`
  );

  // 4. 5-Section CMAT Mastery & Accuracy Matrix
  const sectionAnalytics = computeSectionAnalytics({
    topicProgress: INITIAL_TOPIC_PROGRESS,
    quizAttempts: INITIAL_QUIZ_ATTEMPTS,
    errorLog: INITIAL_ERROR_LOG,
  });
  assert.equal(sectionAnalytics.length, 5, 'Must compute analytics for all 5 CMAT sections');

  // 5. Programmatic Question Bank Validation Across All 5 CMAT Sections + Mocks (P1)
  const bankReport = validateQuestionBank();
  assert.equal(
    bankReport.valid,
    true,
    `Question bank validation failed: ${bankReport.errors.join(' | ')}`
  );
  assert.equal(
    bankReport.coveredSubjects.length,
    5,
    'Question bank must cover all 5 official CMAT sections'
  );
  assert.ok(
    QUIZ_BANK.some((q) => q.examFormat === 'full_mock' && q.negativeMarkPerWrong === 1),
    'Question bank must include a Full 5-Section CMAT Mock with +4/-1 NTA marking'
  );
  assert.ok(
    QUIZ_BANK.filter((q) => q.examFormat === 'sectional_test').length >= 5,
    'Question bank must include timed sectional tests for all 5 CMAT sections'
  );

  // 6. System Instruction & Multi-Section Structured Offline Tutor Fallback
  const sysPrompt = buildMitraSystemInstruction({
    preferredLanguage: 'hinglish',
    explanationDepth: 'step_by_step',
    currentDay: 1,
    currentSubject: 'Quantitative Techniques',
    currentTopicTitle: 'Introduction to Ratio & Proportion',
    studyMinutesToday: 95,
    completedTopics: ['Fractions & Decimals'],
    pendingAssessments: ['Ratio & Proportion [status: viewed]'],
    quizSummary: ['Day 1 GK: 7/7'],
    unresolvedMistakes: [],
  });
  assert.ok(sysPrompt.includes('ONLY ONE practice question at a time'));

  for (const querySample of [
    'Teach me Time and Work LCM trick',
    'Teach me Syllogism and Blood Relations',
    'Explain Reading Comprehension elimination rules',
    'Fundamental Rights Articles 14 to 32',
    'Startup India DPIIT and Patent vs Trademark',
  ]) {
    const offline = buildOfflineTutorFallback(
      querySample,
      {
        preferredLanguage: 'hinglish',
        explanationDepth: 'step_by_step',
        currentDay: 1,
        currentSubject: 'Quantitative Techniques',
        currentTopicTitle: 'Introduction to Ratio & Proportion',
        studyMinutesToday: 95,
        completedTopics: [],
        pendingAssessments: [],
        quizSummary: [],
        unresolvedMistakes: [],
      },
      'Simulated offline test'
    );
    assert.ok(
      offline.content.includes('Offline Tutor Fallback'),
      `Offline module for "${querySample}" must explicitly identify itself as Offline Tutor Fallback`
    );
  }

  const providerStatus = getAIProviderStatus();
  assert.equal(providerStatus.provider, 'Google Gemini (@google/genai)');

  console.log(
    `PASS: Mitra domain, dynamic progress, circuit-breaker, and question bank (${bankReport.quizCount} sets, ${bankReport.questionCount} verified questions) tests succeeded.`
  );
}

runMitraTests();
