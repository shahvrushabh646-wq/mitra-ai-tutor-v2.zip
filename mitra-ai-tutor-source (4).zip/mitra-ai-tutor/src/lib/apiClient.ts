import { auth } from './firebase.ts';

const GUEST_TOKEN_STORAGE_KEY = 'mitra_guest_session_v1';

let inFlightGuestSessionPromise: Promise<string> | null = null;

export function getCachedGuestToken(): string | null {
  try {
    return window.localStorage.getItem(GUEST_TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function clearCachedGuestToken(): void {
  try {
    window.localStorage.removeItem(GUEST_TOKEN_STORAGE_KEY);
  } catch {
    // Ignore storage restriction
  }
}

async function fetchOrCreateGuestToken(forceRefresh = false): Promise<string> {
  if (!forceRefresh) {
    const cached = getCachedGuestToken();
    if (cached && cached.startsWith('mitra_guest.')) {
      return cached;
    }
  }

  if (inFlightGuestSessionPromise) {
    return inFlightGuestSessionPromise;
  }

  inFlightGuestSessionPromise = (async () => {
    const res = await fetch('/api/auth/guest-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    if (!res.ok) {
      throw new Error(`Failed to initialize isolated study session (HTTP ${res.status}).`);
    }
    const data = (await res.json()) as { token?: string };
    if (!data.token) {
      throw new Error('Server did not return a valid session token.');
    }
    try {
      window.localStorage.setItem(GUEST_TOKEN_STORAGE_KEY, data.token);
    } catch {
      // Ignore storage write restriction
    }
    return data.token;
  })();

  try {
    return await inFlightGuestSessionPromise;
  } finally {
    inFlightGuestSessionPromise = null;
  }
}

export async function resolveAuthBearerToken(forceRefresh = false): Promise<string> {
  const user = auth.currentUser;
  if (user) {
    return user.getIdToken(forceRefresh);
  }
  return fetchOrCreateGuestToken(forceRefresh);
}

/**
 * Authenticated fetch wrapper for all Mitra private workspace & AI endpoints.
 * Attaches Firebase ID token when signed in, or an isolated HMAC-signed guest
 * session token when browsing without Google sign-in. Automatically refreshes
 * once on 401 (e.g., if guest HMAC rotated or ID token expired).
 */
export async function apiFetch(
  input: RequestInfo | URL,
  init: RequestInit = {}
): Promise<Response> {
  const token = await resolveAuthBearerToken(false);
  const headers = new Headers(init.headers || {});
  headers.set('Authorization', `Bearer ${token}`);

  const response = await fetch(input, {
    ...init,
    headers,
  });

  if (response.status === 401) {
    if (!auth.currentUser) {
      clearCachedGuestToken();
    }
    const freshToken = await resolveAuthBearerToken(true);
    const retryHeaders = new Headers(init.headers || {});
    retryHeaders.set('Authorization', `Bearer ${freshToken}`);
    return fetch(input, {
      ...init,
      headers: retryHeaders,
    });
  }

  return response;
}
