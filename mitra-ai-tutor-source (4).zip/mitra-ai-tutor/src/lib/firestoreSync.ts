import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db, handleFirestoreError, OperationType } from './firebase.ts';
import type {
  ChatMessageItem,
  ConversationThread,
  ErrorLogRecord,
  QuizAttemptRecord,
  StudyNoteRecord,
  TopicProgressRecord,
  UserLearningProfile,
} from '../types/mitra.ts';
import {
  INITIAL_CONVERSATIONS,
  INITIAL_ERROR_LOG,
  INITIAL_MESSAGES,
  INITIAL_NOTES,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_TOPIC_PROGRESS,
  INITIAL_USER_PROFILE,
} from '../data/cmatCurriculum.ts';

// Strictly sanitize IDs to match ^[a-zA-Z0-9_\-]+$ and <= 128 chars from firebase-blueprint.json
export function sanitizeDocId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128);
  return cleaned.length > 0 ? cleaned : `id_${Date.now()}`;
}

function tsToIso(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (typeof val === 'string') return val;
  return new Date().toISOString();
}

export async function bootstrapAuthenticatedStudent(user: User): Promise<void> {
  const uid = sanitizeDocId(user.uid);
  const userPath = `users/${uid}`;
  const userRef = doc(db, 'users', uid);

  let snap;
  try {
    snap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, userPath);
  }

  if (snap.exists()) {
    return;
  }

  // First-time sign-in: seed the preserved Day 1 learning progress into user-scoped Firestore!
  const displayName = (user.displayName || 'CMAT Aspirant').trim().slice(0, 100) || 'CMAT Aspirant';
  try {
    await setDoc(userRef, {
      ownerId: uid,
      displayName,
      preferredLanguage: INITIAL_USER_PROFILE.preferredLanguage,
      explanationDepth: INITIAL_USER_PROFILE.explanationDepth,
      currentDay: INITIAL_USER_PROFILE.currentDay,
      currentSubject: INITIAL_USER_PROFILE.currentSubject.slice(0, 80),
      currentTopicId: sanitizeDocId(INITIAL_USER_PROFILE.currentTopicId),
      studyMinutesToday: INITIAL_USER_PROFILE.studyMinutesToday,
      totalStudyMinutes: INITIAL_USER_PROFILE.totalStudyMinutes,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, userPath);
  }

  // Seed Topic Progress
  for (const tp of INITIAL_TOPIC_PROGRESS) {
    const tid = sanitizeDocId(tp.topicId);
    const tpPath = `users/${uid}/topicProgress/${tid}`;
    try {
      await setDoc(doc(db, 'users', uid, 'topicProgress', tid), {
        ownerId: uid,
        topicId: tid,
        subject: tp.subject.slice(0, 80),
        status: tp.status,
        bestScore: tp.bestScore,
        totalQuestions: tp.totalQuestions,
        attemptsCount: tp.attemptsCount,
        timeSpentMinutes: tp.timeSpentMinutes,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, tpPath);
    }
  }

  // Seed Day 1 Verified Quiz Attempts
  for (const qa of INITIAL_QUIZ_ATTEMPTS) {
    const aid = sanitizeDocId(qa.id);
    const qaPath = `users/${uid}/quizAttempts/${aid}`;
    try {
      await setDoc(doc(db, 'users', uid, 'quizAttempts', aid), {
        ownerId: uid,
        quizId: sanitizeDocId(qa.quizId),
        title: qa.title.slice(0, 180),
        subject: qa.subject.slice(0, 80),
        topicId: sanitizeDocId(qa.topicId),
        score: qa.score,
        total: qa.total,
        accuracyPercent: qa.accuracyPercent,
        durationSeconds: qa.durationSeconds,
        passed: qa.passed,
        status: 'completed',
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, qaPath);
    }
  }

  // Seed Day 1 Error Log
  for (const err of INITIAL_ERROR_LOG) {
    const eid = sanitizeDocId(err.id);
    const errPath = `users/${uid}/errorLog/${eid}`;
    try {
      await setDoc(doc(db, 'users', uid, 'errorLog', eid), {
        ownerId: uid,
        questionId: sanitizeDocId(err.questionId),
        subject: err.subject.slice(0, 80),
        topicId: sanitizeDocId(err.topicId),
        questionText: err.questionText.slice(0, 3000),
        studentAnswer: err.studentAnswer.slice(0, 500),
        correctAnswer: err.correctAnswer.slice(0, 500),
        mistakeType: err.mistakeType,
        explanation: err.explanation.slice(0, 4000),
        resolved: err.resolved,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, errPath);
    }
  }

  // Seed Day 1 Study Notes
  for (const note of INITIAL_NOTES) {
    const nid = sanitizeDocId(note.id);
    const notePath = `users/${uid}/notes/${nid}`;
    try {
      await setDoc(doc(db, 'users', uid, 'notes', nid), {
        ownerId: uid,
        title: note.title.slice(0, 180),
        subject: note.subject.slice(0, 80),
        topicId: sanitizeDocId(note.topicId),
        content: note.content.slice(0, 16000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, notePath);
    }
  }

  // Seed Day 1 Conversation & Messages
  for (const conv of INITIAL_CONVERSATIONS) {
    const cid = sanitizeDocId(conv.id);
    const convPath = `users/${uid}/conversations/${cid}`;
    try {
      await setDoc(doc(db, 'users', uid, 'conversations', cid), {
        ownerId: uid,
        title: conv.title.slice(0, 160),
        subjectTag: conv.subjectTag.slice(0, 80),
        archived: conv.archived,
        messageCount: (INITIAL_MESSAGES[conv.id] || []).length,
        lastMessagePreview: conv.lastMessagePreview.slice(0, 300),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, convPath);
    }

    const msgs = INITIAL_MESSAGES[conv.id] || [];
    for (const m of msgs) {
      const mid = sanitizeDocId(m.id);
      const mPath = `users/${uid}/conversations/${cid}/messages/${mid}`;
      try {
        await setDoc(doc(db, 'users', uid, 'conversations', cid, 'messages', mid), {
          ownerId: uid,
          conversationId: cid,
          role: m.role,
          content: m.content.slice(0, 32000),
          sourceMode: m.sourceMode,
          modelUsed: m.modelUsed.slice(0, 80),
          attachmentName: (m.attachmentName || 'none').slice(0, 200),
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, mPath);
      }
    }
  }
}

export function subscribeFirestoreWorkspace(
  uid: string,
  callbacks: {
    onProfile: (p: UserLearningProfile) => void;
    onConversations: (c: ConversationThread[]) => void;
    onTopicProgress: (t: TopicProgressRecord[]) => void;
    onQuizAttempts: (q: QuizAttemptRecord[]) => void;
    onErrorLog: (e: ErrorLogRecord[]) => void;
    onNotes: (n: StudyNoteRecord[]) => void;
  }
): () => void {
  const safeUid = sanitizeDocId(uid);
  const unsubs: Array<() => void> = [];

  const profilePath = `users/${safeUid}`;
  unsubs.push(
    onSnapshot(
      doc(db, 'users', safeUid),
      (snap) => {
        if (!snap.exists()) return;
        const d = snap.data();
        callbacks.onProfile({
          ownerId: d.ownerId,
          displayName: d.displayName,
          preferredLanguage: d.preferredLanguage,
          explanationDepth: d.explanationDepth,
          currentDay: d.currentDay,
          currentSubject: d.currentSubject,
          currentTopicId: d.currentTopicId,
          studyMinutesToday: d.studyMinutesToday,
          totalStudyMinutes: d.totalStudyMinutes,
          missedDaysOffset: 0,
          createdAt: tsToIso(d.createdAt),
          updatedAt: tsToIso(d.updatedAt),
        });
      },
      (error) => handleFirestoreError(error, OperationType.GET, profilePath)
    )
  );

  const convPath = `users/${safeUid}/conversations`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', safeUid, 'conversations'), where('ownerId', '==', safeUid)),
      (snap) => {
        const items: ConversationThread[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            title: d.title,
            subjectTag: d.subjectTag,
            archived: Boolean(d.archived),
            messageCount: d.messageCount || 0,
            lastMessagePreview: d.lastMessagePreview || '',
            createdAt: tsToIso(d.createdAt),
            updatedAt: tsToIso(d.updatedAt),
          };
        });
        items.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        callbacks.onConversations(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, convPath)
    )
  );

  const tpPath = `users/${safeUid}/topicProgress`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', safeUid, 'topicProgress'), where('ownerId', '==', safeUid)),
      (snap) => {
        const items: TopicProgressRecord[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            topicId: d.topicId,
            subject: d.subject,
            status: d.status,
            bestScore: d.bestScore,
            totalQuestions: d.totalQuestions,
            attemptsCount: d.attemptsCount,
            timeSpentMinutes: d.timeSpentMinutes,
            createdAt: tsToIso(d.createdAt),
            updatedAt: tsToIso(d.updatedAt),
          };
        });
        callbacks.onTopicProgress(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, tpPath)
    )
  );

  const qaPath = `users/${safeUid}/quizAttempts`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', safeUid, 'quizAttempts'), where('ownerId', '==', safeUid)),
      (snap) => {
        const items: QuizAttemptRecord[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            quizId: d.quizId,
            title: d.title,
            subject: d.subject,
            topicId: d.topicId,
            score: d.score,
            total: d.total,
            accuracyPercent: d.accuracyPercent,
            durationSeconds: d.durationSeconds,
            passed: Boolean(d.passed),
            status: 'completed',
            createdAt: tsToIso(d.createdAt),
          };
        });
        items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        callbacks.onQuizAttempts(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, qaPath)
    )
  );

  const errPath = `users/${safeUid}/errorLog`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', safeUid, 'errorLog'), where('ownerId', '==', safeUid)),
      (snap) => {
        const items: ErrorLogRecord[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            questionId: d.questionId,
            subject: d.subject,
            topicId: d.topicId,
            questionText: d.questionText,
            studentAnswer: d.studentAnswer,
            correctAnswer: d.correctAnswer,
            mistakeType: d.mistakeType,
            explanation: d.explanation,
            resolved: Boolean(d.resolved),
            createdAt: tsToIso(d.createdAt),
            updatedAt: tsToIso(d.updatedAt),
          };
        });
        items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        callbacks.onErrorLog(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, errPath)
    )
  );

  const notesPath = `users/${safeUid}/notes`;
  unsubs.push(
    onSnapshot(
      query(collection(db, 'users', safeUid, 'notes'), where('ownerId', '==', safeUid)),
      (snap) => {
        const items: StudyNoteRecord[] = snap.docs.map((docSnap) => {
          const d = docSnap.data();
          return {
            id: docSnap.id,
            title: d.title,
            subject: d.subject,
            topicId: d.topicId,
            content: d.content,
            createdAt: tsToIso(d.createdAt),
            updatedAt: tsToIso(d.updatedAt),
          };
        });
        items.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        callbacks.onNotes(items);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, notesPath)
    )
  );

  return () => {
    for (const u of unsubs) u();
  };
}

export function subscribeConversationMessages(
  uid: string,
  conversationId: string,
  onMessages: (msgs: ChatMessageItem[]) => void
): () => void {
  const safeUid = sanitizeDocId(uid);
  const safeCid = sanitizeDocId(conversationId);
  const path = `users/${safeUid}/conversations/${safeCid}/messages`;

  return onSnapshot(
    query(
      collection(db, 'users', safeUid, 'conversations', safeCid, 'messages'),
      where('ownerId', '==', safeUid)
    ),
    (snap) => {
      const items: ChatMessageItem[] = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          conversationId: d.conversationId,
          role: d.role,
          content: d.content,
          sourceMode: d.sourceMode,
          modelUsed: d.modelUsed,
          attachmentName: d.attachmentName,
          createdAt: tsToIso(d.createdAt),
        };
      });
      items.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      onMessages(items);
    },
    (error) => handleFirestoreError(error, OperationType.LIST, path)
  );
}

// Firestore Write Mutations matching exact action branches in firestore.rules
export async function syncFirestorePreferences(
  uid: string,
  patch: Pick<UserLearningProfile, 'displayName' | 'preferredLanguage' | 'explanationDepth'>
) {
  const safeUid = sanitizeDocId(uid);
  const path = `users/${safeUid}`;
  try {
    await updateDoc(doc(db, 'users', safeUid), {
      displayName: patch.displayName.slice(0, 100) || 'Student',
      preferredLanguage: patch.preferredLanguage,
      explanationDepth: patch.explanationDepth,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function syncFirestoreStudyState(
  uid: string,
  patch: Pick<
    UserLearningProfile,
    'currentDay' | 'currentSubject' | 'currentTopicId' | 'studyMinutesToday' | 'totalStudyMinutes'
  >
) {
  const safeUid = sanitizeDocId(uid);
  const path = `users/${safeUid}`;
  try {
    await updateDoc(doc(db, 'users', safeUid), {
      currentDay: patch.currentDay,
      currentSubject: patch.currentSubject.slice(0, 80),
      currentTopicId: sanitizeDocId(patch.currentTopicId),
      studyMinutesToday: patch.studyMinutesToday,
      totalStudyMinutes: patch.totalStudyMinutes,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function syncFirestoreCreateConversation(uid: string, conv: ConversationThread) {
  const safeUid = sanitizeDocId(uid);
  const cid = sanitizeDocId(conv.id);
  const path = `users/${safeUid}/conversations/${cid}`;
  try {
    await setDoc(doc(db, 'users', safeUid, 'conversations', cid), {
      ownerId: safeUid,
      title: (conv.title || 'New Tutoring Session').slice(0, 160),
      subjectTag: (conv.subjectTag || 'General Tutoring').slice(0, 80),
      archived: Boolean(conv.archived),
      messageCount: conv.messageCount || 0,
      lastMessagePreview: (conv.lastMessagePreview || '').slice(0, 300),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncFirestoreRenameOrArchiveConversation(
  uid: string,
  conversationId: string,
  patch: { title: string; archived: boolean; subjectTag: string }
) {
  const safeUid = sanitizeDocId(uid);
  const cid = sanitizeDocId(conversationId);
  const path = `users/${safeUid}/conversations/${cid}`;
  try {
    await updateDoc(doc(db, 'users', safeUid, 'conversations', cid), {
      title: patch.title.slice(0, 160) || 'Session',
      archived: Boolean(patch.archived),
      subjectTag: patch.subjectTag.slice(0, 80) || 'General',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function syncFirestoreDeleteConversation(uid: string, conversationId: string) {
  const safeUid = sanitizeDocId(uid);
  const cid = sanitizeDocId(conversationId);
  const msgColPath = `users/${safeUid}/conversations/${cid}/messages`;
  try {
    const msgs = await getDocs(
      query(
        collection(db, 'users', safeUid, 'conversations', cid, 'messages'),
        where('ownerId', '==', safeUid)
      )
    );
    for (const m of msgs.docs) {
      await deleteDoc(m.ref);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, msgColPath);
  }

  const convPath = `users/${safeUid}/conversations/${cid}`;
  try {
    await deleteDoc(doc(db, 'users', safeUid, 'conversations', cid));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, convPath);
  }
}

export async function syncFirestoreAppendMessage(
  uid: string,
  conversationId: string,
  msg: ChatMessageItem,
  updatedTitle: string,
  messageCount: number
) {
  const safeUid = sanitizeDocId(uid);
  const cid = sanitizeDocId(conversationId);
  const mid = sanitizeDocId(msg.id);
  const mPath = `users/${safeUid}/conversations/${cid}/messages/${mid}`;
  try {
    await setDoc(doc(db, 'users', safeUid, 'conversations', cid, 'messages', mid), {
      ownerId: safeUid,
      conversationId: cid,
      role: msg.role,
      content: (msg.content || ' ').slice(0, 32000),
      sourceMode: msg.sourceMode,
      modelUsed: (msg.modelUsed || 'gemini-3.8-flash').slice(0, 80),
      attachmentName: (msg.attachmentName || 'none').slice(0, 200),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, mPath);
  }

  const convPath = `users/${safeUid}/conversations/${cid}`;
  try {
    await updateDoc(doc(db, 'users', safeUid, 'conversations', cid), {
      title: (updatedTitle || 'Study Session').slice(0, 160),
      messageCount,
      lastMessagePreview: (msg.content || '').slice(0, 300),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, convPath);
  }
}

export async function syncFirestoreUpsertTopicProgress(uid: string, tp: TopicProgressRecord) {
  const safeUid = sanitizeDocId(uid);
  const tid = sanitizeDocId(tp.topicId);
  const path = `users/${safeUid}/topicProgress/${tid}`;
  const ref = doc(db, 'users', safeUid, 'topicProgress', tid);
  let snap;
  try {
    snap = await getDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  if (snap.exists()) {
    try {
      await updateDoc(ref, {
        status: tp.status,
        bestScore: tp.bestScore,
        totalQuestions: tp.totalQuestions,
        attemptsCount: tp.attemptsCount,
        timeSpentMinutes: tp.timeSpentMinutes,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  } else {
    try {
      await setDoc(ref, {
        ownerId: safeUid,
        topicId: tid,
        subject: tp.subject.slice(0, 80),
        status: tp.status,
        bestScore: tp.bestScore,
        totalQuestions: tp.totalQuestions,
        attemptsCount: tp.attemptsCount,
        timeSpentMinutes: tp.timeSpentMinutes,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }
}

export async function syncFirestoreQuizAttempt(uid: string, qa: QuizAttemptRecord) {
  const safeUid = sanitizeDocId(uid);
  const aid = sanitizeDocId(qa.id);
  const path = `users/${safeUid}/quizAttempts/${aid}`;
  try {
    await setDoc(doc(db, 'users', safeUid, 'quizAttempts', aid), {
      ownerId: safeUid,
      quizId: sanitizeDocId(qa.quizId),
      title: qa.title.slice(0, 180),
      subject: qa.subject.slice(0, 80),
      topicId: sanitizeDocId(qa.topicId),
      score: qa.score,
      total: qa.total,
      accuracyPercent: qa.accuracyPercent,
      durationSeconds: qa.durationSeconds,
      passed: qa.passed,
      status: 'completed',
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function syncFirestoreCreateError(uid: string, err: ErrorLogRecord) {
  const safeUid = sanitizeDocId(uid);
  const eid = sanitizeDocId(err.id);
  const path = `users/${safeUid}/errorLog/${eid}`;
  const ref = doc(db, 'users', safeUid, 'errorLog', eid);
  let snap;
  try {
    snap = await getDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  if (!snap.exists()) {
    try {
      await setDoc(ref, {
        ownerId: safeUid,
        questionId: sanitizeDocId(err.questionId),
        subject: err.subject.slice(0, 80),
        topicId: sanitizeDocId(err.topicId),
        questionText: err.questionText.slice(0, 3000),
        studentAnswer: err.studentAnswer.slice(0, 500),
        correctAnswer: err.correctAnswer.slice(0, 500),
        mistakeType: err.mistakeType,
        explanation: err.explanation.slice(0, 4000),
        resolved: Boolean(err.resolved),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }
}

export async function syncFirestoreResolveError(uid: string, errorId: string, resolved: boolean, explanation: string) {
  const safeUid = sanitizeDocId(uid);
  const eid = sanitizeDocId(errorId);
  const path = `users/${safeUid}/errorLog/${eid}`;
  try {
    await updateDoc(doc(db, 'users', safeUid, 'errorLog', eid), {
      resolved: Boolean(resolved),
      explanation: explanation.slice(0, 4000),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function syncFirestoreSaveNote(uid: string, note: StudyNoteRecord) {
  const safeUid = sanitizeDocId(uid);
  const nid = sanitizeDocId(note.id);
  const path = `users/${safeUid}/notes/${nid}`;
  const ref = doc(db, 'users', safeUid, 'notes', nid);
  let snap;
  try {
    snap = await getDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  if (snap.exists()) {
    try {
      await updateDoc(ref, {
        title: note.title.slice(0, 180),
        subject: note.subject.slice(0, 80),
        topicId: sanitizeDocId(note.topicId),
        content: note.content.slice(0, 16000),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  } else {
    try {
      await setDoc(ref, {
        ownerId: safeUid,
        title: note.title.slice(0, 180),
        subject: note.subject.slice(0, 80),
        topicId: sanitizeDocId(note.topicId),
        content: note.content.slice(0, 16000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }
}

export async function syncFirestoreDeleteNote(uid: string, noteId: string) {
  const safeUid = sanitizeDocId(uid);
  const nid = sanitizeDocId(noteId);
  const path = `users/${safeUid}/notes/${nid}`;
  try {
    await deleteDoc(doc(db, 'users', safeUid, 'notes', nid));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncFirestoreTruncateMessages(
  uid: string,
  conversationId: string,
  keepMessageIds: string[]
) {
  const safeUid = sanitizeDocId(uid);
  const cid = sanitizeDocId(conversationId);
  const keepSet = new Set(keepMessageIds.map((id) => sanitizeDocId(id)));
  const msgColPath = `users/${safeUid}/conversations/${cid}/messages`;
  try {
    const snap = await getDocs(
      query(
        collection(db, 'users', safeUid, 'conversations', cid, 'messages'),
        where('ownerId', '==', safeUid)
      )
    );
    for (const d of snap.docs) {
      if (!keepSet.has(d.id)) {
        await deleteDoc(d.ref);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, msgColPath);
  }
}

