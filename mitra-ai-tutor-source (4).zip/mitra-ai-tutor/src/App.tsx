import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import type { User } from 'firebase/auth';
import { Download, Menu, X } from 'lucide-react';
import {
  auth,
  signInWithGooglePopup,
  signOutFirebase,
} from './lib/firebase.ts';
import { apiFetch } from './lib/apiClient.ts';
import {
  bootstrapAuthenticatedStudent,
  subscribeConversationMessages,
  subscribeFirestoreWorkspace,
  syncFirestoreAppendMessage,
  syncFirestoreCreateConversation,
  syncFirestoreCreateError,
  syncFirestoreDeleteConversation,
  syncFirestoreDeleteNote,
  syncFirestorePreferences,
  syncFirestoreQuizAttempt,
  syncFirestoreRenameOrArchiveConversation,
  syncFirestoreResolveError,
  syncFirestoreSaveNote,
  syncFirestoreStudyState,
  syncFirestoreTruncateMessages,
  syncFirestoreUpsertTopicProgress,
} from './lib/firestoreSync.ts';
import {
  INITIAL_CONVERSATIONS,
  INITIAL_ERROR_LOG,
  INITIAL_MESSAGES,
  INITIAL_NOTES,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_TOPIC_PROGRESS,
  INITIAL_USER_PROFILE,
} from './data/cmatCurriculum.ts';
import { TutorChatWorkspace } from './components/TutorChatWorkspace.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { StudyPlanView } from './components/StudyPlanView.tsx';
import { PracticeQuizView } from './components/PracticeQuizView.tsx';
import { StudyVaultView } from './components/StudyVaultView.tsx';
import type {
  AIProviderStatus,
  ChatAttachment,
  ChatMessageItem,
  ConversationThread,
  ErrorLogRecord,
  ExplanationDepth,
  ExplanationLanguage,
  QuizAttemptRecord,
  StudyNoteRecord,
  SubjectKey,
  SyllabusTopic,
  TopicProgressRecord,
  UserLearningProfile,
} from './types/mitra.ts';

type WorkspaceTab = 'chat' | 'dashboard' | 'plan' | 'practice' | 'vault';

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('chat');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Auth State
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);

  // Core Application State (Hydrated from Authenticated Server Store + Synced with Firestore when signed in)
  const [isLoadingWorkspace, setIsLoadingWorkspace] = useState(true);
  const [bannerError, setBannerError] = useState<string | null>(null);
  const [aiStatus, setAiStatus] = useState<AIProviderStatus | null>(null);

  const [profile, setProfile] = useState<UserLearningProfile>(INITIAL_USER_PROFILE);
  const [conversations, setConversations] = useState<ConversationThread[]>(INITIAL_CONVERSATIONS);
  const [messagesByConv, setMessagesByConv] =
    useState<Record<string, ChatMessageItem[]>>(INITIAL_MESSAGES);
  const [activeConversationId, setActiveConversationId] = useState<string>(
    INITIAL_CONVERSATIONS[0].id
  );
  const [topicProgress, setTopicProgress] =
    useState<TopicProgressRecord[]>(INITIAL_TOPIC_PROGRESS);
  const [quizAttempts, setQuizAttempts] = useState<QuizAttemptRecord[]>(INITIAL_QUIZ_ATTEMPTS);
  const [errorLog, setErrorLog] = useState<ErrorLogRecord[]>(INITIAL_ERROR_LOG);
  const [notes, setNotes] = useState<StudyNoteRecord[]>(INITIAL_NOTES);
  const [uploadedDocs, setUploadedDocs] = useState<ChatAttachment[]>([]);

  // Cross-view Navigation Intents
  const [chatPromptDraft, setChatPromptDraft] = useState<string | undefined>(undefined);
  const [chatAttachmentDraft, setChatAttachmentDraft] = useState<ChatAttachment | null>(null);
  const [pendingQuizId, setPendingQuizId] = useState<string | null>(null);
  const [vaultInitialSection, setVaultInitialSection] = useState<
    'mistakes' | 'flashcards' | 'notes' | 'papers' | 'github'
  >('mistakes');

  // Streaming State
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const [streamingModel, setStreamingModel] = useState('');
  const streamAbortRef = useRef<AbortController | null>(null);

  const loadServerWorkspace = useCallback(async () => {
    try {
      const res = await apiFetch('/api/workspace');
      if (!res.ok) throw new Error('Could not load your isolated study workspace.');
      const data = await res.json();
      setAiStatus(data.aiStatus || null);
      setUploadedDocs(data.uploadedDocuments || []);

      if (!auth.currentUser) {
        if (data.profile) setProfile(data.profile);
        if (Array.isArray(data.conversations) && data.conversations.length > 0) {
          setConversations(data.conversations);
          setActiveConversationId((prev) =>
            data.conversations.some((c: ConversationThread) => c.id === prev)
              ? prev
              : data.conversations[0].id
          );
        }
        if (data.messagesByConversation) {
          setMessagesByConv(data.messagesByConversation);
        }
        if (Array.isArray(data.topicProgress)) setTopicProgress(data.topicProgress);
        if (Array.isArray(data.quizAttempts)) setQuizAttempts(data.quizAttempts);
        if (Array.isArray(data.errorLog)) setErrorLog(data.errorLog);
        if (Array.isArray(data.notes)) setNotes(data.notes);
      }
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Network error loading workspace.');
    } finally {
      setIsLoadingWorkspace(false);
    }
  }, []);

  const refreshAiStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/ai/status');
      if (res.ok) {
        const status = (await res.json()) as AIProviderStatus;
        setAiStatus(status);
      }
    } catch {
      // Ignore transient network hiccup
    }
  }, []);

  const handleVerifyLiveAi = useCallback(async (): Promise<AIProviderStatus | null> => {
    try {
      const res = await apiFetch('/api/ai/verify', { method: 'POST' });
      if (res.ok) {
        const status = (await res.json()) as AIProviderStatus;
        setAiStatus(status);
        return status;
      }
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Live AI verification check failed.');
    }
    return null;
  }, []);

  // Firebase Auth & Real-time Firestore Subscription + Principal Workspace Sync
  useEffect(() => {
    let unsubWorkspace: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthReady(true);

      if (unsubWorkspace) {
        unsubWorkspace();
        unsubWorkspace = null;
      }

      if (user) {
        try {
          await bootstrapAuthenticatedStudent(user);
          // Also warm the isolated server principal store for this Firebase UID (for uploaded docs + AI context)
          void loadServerWorkspace();
          unsubWorkspace = subscribeFirestoreWorkspace(user.uid, {
            onProfile: (p) => setProfile(p),
            onConversations: (convs) => {
              setConversations(convs);
              if (convs.length > 0) {
                setActiveConversationId((prev) =>
                  convs.some((c) => c.id === prev) ? prev : convs[0].id
                );
              }
            },
            onTopicProgress: (tp) => setTopicProgress(tp),
            onQuizAttempts: (qa) => setQuizAttempts(qa),
            onErrorLog: (errs) => setErrorLog(errs),
            onNotes: (n) => setNotes(n),
          });
        } catch (err) {
          setBannerError(
            err instanceof Error ? err.message : 'Error syncing Firestore profile.'
          );
          setIsLoadingWorkspace(false);
        }
      } else {
        await loadServerWorkspace();
      }
    });

    return () => {
      unsubAuth();
      if (unsubWorkspace) unsubWorkspace();
    };
  }, [loadServerWorkspace]);

  // Subscribe to Active Conversation Messages in Firestore when signed in
  useEffect(() => {
    if (!authReady || !firebaseUser || !activeConversationId) return;
    const unsub = subscribeConversationMessages(
      firebaseUser.uid,
      activeConversationId,
      (msgs) => {
        setMessagesByConv((prev) => ({
          ...prev,
          [activeConversationId]: msgs,
        }));
      }
    );
    return () => unsub();
  }, [authReady, firebaseUser, activeConversationId]);

  const handleAuthAction = async () => {
    setBannerError(null);
    try {
      if (firebaseUser) {
        await signOutFirebase();
      } else {
        await signInWithGooglePopup();
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (!msg.includes('popup-closed-by-user')) {
        setBannerError(`Sign-in notice: ${msg}`);
      }
    }
  };

  // Conversation Actions
  const handleNewConversation = async () => {
    try {
      const res = await apiFetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'New Chat',
          subjectTag: profile.currentSubject,
        }),
      });
      if (!res.ok) throw new Error('Could not create new conversation.');
      const created = (await res.json()) as ConversationThread;
      setConversations((prev) => [created, ...prev]);
      setMessagesByConv((prev) => ({ ...prev, [created.id]: [] }));
      setActiveConversationId(created.id);

      if (firebaseUser) {
        await syncFirestoreCreateConversation(firebaseUser.uid, created);
      }
    } catch (err) {
      setBannerError(err instanceof Error ? err.message : 'Could not create conversation.');
    }
  };

  const handleRenameConversation = async (id: string, title: string) => {
    const existing = conversations.find((c) => c.id === id);
    if (!existing) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title } : c))
    );
    await apiFetch(`/api/conversations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    if (firebaseUser) {
      await syncFirestoreRenameOrArchiveConversation(firebaseUser.uid, id, {
        title,
        archived: existing.archived,
        subjectTag: existing.subjectTag,
      });
    }
  };

  const handleToggleArchiveConversation = async (id: string, archived: boolean) => {
    const existing = conversations.find((c) => c.id === id);
    if (!existing) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, archived } : c))
    );
    await apiFetch(`/api/conversations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ archived }),
    });
    if (firebaseUser) {
      await syncFirestoreRenameOrArchiveConversation(firebaseUser.uid, id, {
        title: existing.title,
        archived,
        subjectTag: existing.subjectTag,
      });
    }
  };

  const handleDeleteConversation = async (id: string) => {
    const remaining = conversations.filter((c) => c.id !== id);
    setConversations(remaining);
    if (activeConversationId === id) {
      if (remaining.length > 0) {
        setActiveConversationId(remaining[0].id);
      } else {
        await handleNewConversation();
      }
    }
    await apiFetch(`/api/conversations/${id}`, { method: 'DELETE' });
    if (firebaseUser) {
      await syncFirestoreDeleteConversation(firebaseUser.uid, id);
    }
  };

  // Streaming Chat Execution
  const executeChatStream = async (params: {
    text?: string;
    attachments?: ChatAttachment[];
    editMessageId?: string;
    regenerateOnly?: boolean;
    modelTier?: 'fast' | 'thinking';
    conversationTone?: 'friend' | 'coach';
  }): Promise<ChatMessageItem | null> => {
    if (isStreaming) return null;
    setBannerError(null);

    let targetConvId = activeConversationId;
    if (!targetConvId || !conversations.some((c) => c.id === targetConvId)) {
      const res = await apiFetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: (params.text || 'Study Session').slice(0, 52),
          subjectTag: profile.currentSubject,
        }),
      });
      const created = (await res.json()) as ConversationThread;
      targetConvId = created.id;
      setConversations((prev) => [created, ...prev]);
      setActiveConversationId(created.id);
      if (firebaseUser) {
        await syncFirestoreCreateConversation(firebaseUser.uid, created);
      }
    }

    const currentHistory = messagesByConv[targetConvId] || [];
    let workingHistory = [...currentHistory];
    let didTruncate = false;

    if (params.editMessageId) {
      const idx = workingHistory.findIndex((m) => m.id === params.editMessageId);
      if (idx >= 0) {
        workingHistory = workingHistory.slice(0, idx);
        didTruncate = true;
      }
    } else if (params.regenerateOnly) {
      if (
        workingHistory.length > 0 &&
        workingHistory[workingHistory.length - 1].role === 'assistant'
      ) {
        workingHistory = workingHistory.slice(0, -1);
        didTruncate = true;
      }
    }

    if (didTruncate && firebaseUser) {
      await syncFirestoreTruncateMessages(
        firebaseUser.uid,
        targetConvId,
        workingHistory.map((m) => m.id)
      );
    }

    // Optimistic User Message (never lost even if stream fails!)
    let optimisticUserMsg: ChatMessageItem | null = null;
    if (!params.regenerateOnly && params.text) {
      optimisticUserMsg = {
        id: `msg_${Date.now()}_u`,
        conversationId: targetConvId,
        role: 'user',
        content: params.text,
        sourceMode: 'user',
        modelUsed: 'user',
        attachmentName:
          params.attachments && params.attachments.length > 0
            ? params.attachments.map((a) => a.name).join(', ')
            : 'none',
        attachments: params.attachments,
        createdAt: new Date().toISOString(),
      };
      workingHistory = [...workingHistory, optimisticUserMsg];
      setMessagesByConv((prev) => ({
        ...prev,
        [targetConvId]: workingHistory,
      }));
    } else {
      setMessagesByConv((prev) => ({
        ...prev,
        [targetConvId]: workingHistory,
      }));
    }

    const abortController = new AbortController();
    streamAbortRef.current = abortController;
    setIsStreaming(true);
    setStreamingText('');
    setStreamingModel('');

    let accumulatedText = '';

    try {
      const response = await apiFetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortController.signal,
        body: JSON.stringify({
          conversationId: targetConvId,
          message: params.text,
          attachments: params.attachments,
          editMessageId: params.editMessageId,
          regenerateOnly: params.regenerateOnly,
          modelTier: params.modelTier || 'fast',
          historyOverride: workingHistory.map((m) => ({
            role: m.role,
            content: m.content,
            attachments: m.attachments,
          })),
          learningContextOverride: {
            preferredLanguage: profile.preferredLanguage,
            explanationDepth: profile.explanationDepth,
            conversationTone: params.conversationTone || 'friend',
            currentDay: profile.currentDay,
            currentSubject: profile.currentSubject,
            studyMinutesToday: profile.studyMinutesToday,
          },
        }),
      });

      if (!response.ok || !response.body) {
        const errBody = await response.json().catch(() => ({}));
        throw new Error(errBody.error || `Streaming request failed (HTTP ${response.status}).`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let currentEvent = 'message';
      let completedAssistantMessage: ChatMessageItem | null = null;

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const rawLine of lines) {
          const line = rawLine.trim();
          if (!line) continue;
          if (line.startsWith('event:')) {
            currentEvent = line.slice(6).trim();
          } else if (line.startsWith('data:')) {
            const jsonStr = line.slice(5).trim();
            try {
              const payload = JSON.parse(jsonStr);
              if (currentEvent === 'chunk') {
                accumulatedText += payload.delta || '';
                setStreamingText(accumulatedText);
                if (payload.modelUsed) setStreamingModel(payload.modelUsed);
              } else if (currentEvent === 'done') {
                const assistantMsg: ChatMessageItem = payload.assistantMessage;
                completedAssistantMessage = assistantMsg;
                const updatedConv: ConversationThread | undefined = payload.conversation;
                if (payload.aiStatus) {
                  setAiStatus(payload.aiStatus);
                }

                const finalMessages = [...workingHistory, assistantMsg];
                setMessagesByConv((prev) => ({
                  ...prev,
                  [targetConvId]: finalMessages,
                }));

                if (updatedConv) {
                  setConversations((prev) => [
                    updatedConv,
                    ...prev.filter((c) => c.id !== updatedConv.id),
                  ]);
                }

                if (firebaseUser) {
                  const titleToUse =
                    updatedConv?.title ||
                    (params.text ? params.text.slice(0, 52) : 'Study Session');
                  if (optimisticUserMsg) {
                    await syncFirestoreAppendMessage(
                      firebaseUser.uid,
                      targetConvId,
                      optimisticUserMsg,
                      titleToUse,
                      finalMessages.length - 1
                    );
                  }
                  await syncFirestoreAppendMessage(
                    firebaseUser.uid,
                    targetConvId,
                    assistantMsg,
                    titleToUse,
                    finalMessages.length
                  );
                }
              } else if (currentEvent === 'error') {
                setBannerError(payload.message || 'AI streaming error.');
              }
            } catch {
              // Ignore malformed partial SSE frame
            }
          }
        }
      }

      return completedAssistantMessage;
    } catch (err) {
      if (abortController.signal.aborted) {
        if (accumulatedText.trim()) {
          const stoppedMsg: ChatMessageItem = {
            id: `msg_${Date.now()}_stopped`,
            conversationId: targetConvId,
            role: 'assistant',
            content: `${accumulatedText}\n\n*(Stopped generating)*`,
            sourceMode: 'live',
            modelUsed: streamingModel || 'gemini-3.1-flash-lite-preview',
            attachmentName: 'none',
            createdAt: new Date().toISOString(),
          };
          setMessagesByConv((prev) => ({
            ...prev,
            [targetConvId]: [...workingHistory, stoppedMsg],
          }));
          return stoppedMsg;
        }
      } else {
        // Persist user prompt to Firestore even if streaming failed due to network interruption
        if (firebaseUser && optimisticUserMsg) {
          await syncFirestoreAppendMessage(
            firebaseUser.uid,
            targetConvId,
            optimisticUserMsg,
            params.text ? params.text.slice(0, 52) : 'Study Session',
            workingHistory.length
          ).catch(() => {});
        }
        setBannerError(
          err instanceof Error ? err.message : 'Network interruption while streaming.'
        );
      }
      return null;
    } finally {
      setIsStreaming(false);
      setStreamingText('');
      streamAbortRef.current = null;
    }
  };

  const handleStopStreaming = () => {
    streamAbortRef.current?.abort();
  };

  const handleUploadFile = async (file: File): Promise<ChatAttachment | null> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await apiFetch('/api/documents/upload', {
      method: 'POST',
      body: formData,
    });
    if (!res.ok) return null;
    const att = (await res.json()) as ChatAttachment;
    setUploadedDocs((prev) => [att, ...prev]);
    return att;
  };

  const handleUpdatePreferences = async (patch: {
    preferredLanguage?: ExplanationLanguage;
    explanationDepth?: ExplanationDepth;
  }) => {
    const nextProfile: UserLearningProfile = {
      ...profile,
      ...patch,
    };
    setProfile(nextProfile);
    await apiFetch('/api/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    if (firebaseUser) {
      await syncFirestorePreferences(firebaseUser.uid, {
        displayName: nextProfile.displayName,
        preferredLanguage: nextProfile.preferredLanguage,
        explanationDepth: nextProfile.explanationDepth,
      });
    }
  };

  const handleUpdateStudyState = async (patch: Partial<UserLearningProfile>) => {
    const next: UserLearningProfile = {
      ...profile,
      ...patch,
    };
    setProfile(next);
    await apiFetch('/api/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    if (firebaseUser) {
      await syncFirestoreStudyState(firebaseUser.uid, {
        currentDay: next.currentDay,
        currentSubject: next.currentSubject,
        currentTopicId: next.currentTopicId,
        studyMinutesToday: next.studyMinutesToday,
        totalStudyMinutes: next.totalStudyMinutes,
      });
    }
  };

  const handleMarkTopicViewed = async (topic: SyllabusTopic) => {
    const res = await apiFetch('/api/learning/topic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        topicId: topic.id,
        subject: topic.subject,
        status: 'viewed',
        bestScore: 0,
        totalQuestions: 5,
        attemptsCount: 0,
        timeSpentMinutes: 10,
      }),
    });
    const updated = (await res.json()) as TopicProgressRecord;
    setTopicProgress((prev) => [
      ...prev.filter((t) => t.topicId !== updated.topicId),
      updated,
    ]);
    await handleUpdateStudyState({
      currentSubject: topic.subject,
      currentTopicId: topic.id,
      studyMinutesToday: profile.studyMinutesToday + 10,
      totalStudyMinutes: profile.totalStudyMinutes + 10,
    });
    if (firebaseUser) {
      await syncFirestoreUpsertTopicProgress(firebaseUser.uid, updated);
    }
  };

  const handleSubmitQuizResult = async (params: {
    attempt: Omit<QuizAttemptRecord, 'id' | 'createdAt' | 'status'>;
    newErrors: Array<Omit<ErrorLogRecord, 'id' | 'createdAt' | 'updatedAt' | 'resolved'>>;
    timeSpentMinutes: number;
  }) => {
    const res = await apiFetch('/api/learning/quiz-submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (data.attempt) {
      setQuizAttempts((prev) => [data.attempt, ...prev]);
    }
    if (data.topicProgress) {
      setTopicProgress((prev) => [
        ...prev.filter((t) => t.topicId !== data.topicProgress.topicId),
        data.topicProgress,
      ]);
    }
    if (Array.isArray(data.addedErrors) && data.addedErrors.length > 0) {
      setErrorLog((prev) => {
        const map = new Map(prev.map((e) => [e.id, e]));
        for (const ne of data.addedErrors) map.set(ne.id, ne);
        return Array.from(map.values());
      });
    }
    if (data.profile) {
      setProfile(data.profile);
    }

    if (firebaseUser) {
      if (data.attempt) await syncFirestoreQuizAttempt(firebaseUser.uid, data.attempt);
      if (data.topicProgress) {
        await syncFirestoreUpsertTopicProgress(firebaseUser.uid, data.topicProgress);
      }
      if (Array.isArray(data.addedErrors)) {
        for (const err of data.addedErrors) {
          await syncFirestoreCreateError(firebaseUser.uid, err);
        }
      }
      if (data.profile) {
        await syncFirestoreStudyState(firebaseUser.uid, {
          currentDay: data.profile.currentDay,
          currentSubject: data.profile.currentSubject,
          currentTopicId: data.profile.currentTopicId,
          studyMinutesToday: data.profile.studyMinutesToday,
          totalStudyMinutes: data.profile.totalStudyMinutes,
        });
      }
    }
  };

  const handleToggleResolveError = async (
    errorId: string,
    resolved: boolean,
    explanation: string
  ) => {
    setErrorLog((prev) =>
      prev.map((e) => (e.id === errorId ? { ...e, resolved } : e))
    );
    await apiFetch(`/api/learning/error-log/${errorId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resolved }),
    });
    if (firebaseUser) {
      await syncFirestoreResolveError(firebaseUser.uid, errorId, resolved, explanation);
    }
  };

  const handleSaveNote = async (note: {
    id?: string;
    title: string;
    subject: SubjectKey;
    topicId: string;
    content: string;
  }) => {
    const res = await apiFetch('/api/learning/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(note),
    });
    const saved = (await res.json()) as StudyNoteRecord;
    setNotes((prev) => [saved, ...prev.filter((n) => n.id !== saved.id)]);
    if (firebaseUser) {
      await syncFirestoreSaveNote(firebaseUser.uid, saved);
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId));
    await apiFetch(`/api/learning/notes/${noteId}`, { method: 'DELETE' });
    if (firebaseUser) {
      await syncFirestoreDeleteNote(firebaseUser.uid, noteId);
    }
  };

  const handleGenerateAiNote = async (subject: SubjectKey, prompt: string) => {
    const res = await apiFetch('/api/ai/tool', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const data = await res.json();
    if (data.text) {
      const prefix = data.sourceMode === 'offline' ? '[Offline Revision Sheet]' : 'AI Revision Sheet';
      await handleSaveNote({
        title: `${prefix}: ${subject} (${new Date().toLocaleDateString()})`,
        subject,
        topicId: profile.currentTopicId,
        content: data.text,
      });
    }
  };

  const navItems: { id: WorkspaceTab; label: string }[] = [
    { id: 'chat', label: 'Tutor Chat' },
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'plan', label: 'CMAT Plan' },
    { id: 'practice', label: 'Practice & Mocks' },
    { id: 'vault', label: 'Study Vault' },
  ];

  const activeMessages = messagesByConv[activeConversationId] || [];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="h-[3.75rem] flex items-center justify-between gap-8 px-4 sm:px-6 bg-white border-b border-slate-200 sticky top-0 z-30">
        {/* Zone 1: Single Wordmark */}
        <a
          href="#chat"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('chat');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          Mitra
        </a>

        {/* Zone 2: 5 Clean Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          {navItems.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              onClick={(e) => {
                e.preventDefault();
                setActiveTab(item.id);
              }}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === item.id
                  ? 'text-slate-900 border-blue-700 font-semibold'
                  : 'border-transparent hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Download ZIP + Primary Auth CTA + Mobile Hamburger Escape */}
        <div className="flex items-center gap-2 shrink-0">
          <a
            href="/api/workspace/download-zip"
            download="mitra-ai-tutor-source.zip"
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-slate-900 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            title="Download full Mitra AI Tutor source code (.zip)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP</span>
          </a>

          <button
            type="button"
            onClick={handleAuthAction}
            className="px-3.5 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {firebaseUser
              ? `Sign Out (${(firebaseUser.displayName || 'Student').split(' ')[0]})`
              : 'Sign In to Cloud'}
          </button>

          <button
            type="button"
            onClick={() => setMobileNavOpen((v) => !v)}
            className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileNavOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-3 flex flex-wrap gap-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setActiveTab(item.id);
                setMobileNavOpen(false);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                activeTab === item.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700'
              }`}
            >
              {item.label}
            </button>
          ))}
          <a
            href="/api/workspace/download-zip"
            download="mitra-ai-tutor-source.zip"
            className="px-3 py-1.5 text-xs font-medium rounded-md bg-blue-50 text-blue-700 inline-flex items-center gap-1"
          >
            <Download className="w-3.5 h-3.5" />
            Download ZIP
          </a>
        </div>
      )}

      {/* Global Error / Recovery Banner */}
      {bannerError && (
        <div className="px-6 py-2.5 bg-red-50 border-b border-red-200 text-xs text-red-900 flex items-center justify-between gap-4">
          <span>{bannerError}</span>
          <button
            type="button"
            onClick={() => setBannerError(null)}
            className="font-medium underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="flex-1">
        {isLoadingWorkspace ? (
          <div className="max-w-4xl mx-auto px-6 py-16 space-y-4">
            <div className="h-7 w-64 bg-slate-200 rounded animate-pulse" />
            <div className="h-32 bg-white border border-slate-200 rounded-xl p-6" />
          </div>
        ) : activeTab === 'chat' ? (
          <TutorChatWorkspace
            conversations={conversations}
            activeConversationId={activeConversationId}
            messages={activeMessages}
            isStreaming={isStreaming}
            streamingText={streamingText}
            streamingModel={streamingModel}
            aiStatus={aiStatus}
            profile={profile}
            uploadedDocs={uploadedDocs}
            initialPromptDraft={chatPromptDraft}
            initialAttachmentDraft={chatAttachmentDraft}
            onClearInitialDraft={() => {
              setChatPromptDraft(undefined);
              setChatAttachmentDraft(null);
            }}
            onSelectConversation={(id) => setActiveConversationId(id)}
            onNewConversation={handleNewConversation}
            onRenameConversation={handleRenameConversation}
            onToggleArchiveConversation={handleToggleArchiveConversation}
            onDeleteConversation={handleDeleteConversation}
            onSendMessage={({ text, attachments, editMessageId, modelTier, conversationTone }) =>
              executeChatStream({
                text,
                attachments,
                editMessageId,
                modelTier,
                conversationTone,
              })
            }
            onRegenerateLast={(modelTier, conversationTone) =>
              void executeChatStream({
                regenerateOnly: true,
                modelTier,
                conversationTone,
              })
            }
            onStopStreaming={handleStopStreaming}
            onUploadFile={handleUploadFile}
            onUpdatePreferences={handleUpdatePreferences}
            onSaveMessageAsNote={(msg, bookmarked = false) =>
              void handleSaveNote({
                title: bookmarked
                  ? `[Bookmarked] ${profile.currentSubject} Explanation (${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`
                  : `Tutor Explanation: ${profile.currentSubject}`,
                subject: profile.currentSubject,
                topicId: profile.currentTopicId,
                content: msg.content,
              })
            }
            onRefreshAiStatus={refreshAiStatus}
            onVerifyLiveAi={handleVerifyLiveAi}
          />
        ) : activeTab === 'dashboard' ? (
          <DashboardView
            profile={profile}
            topicProgress={topicProgress}
            quizAttempts={quizAttempts}
            errorLog={errorLog}
            onResumeLesson={(prompt, topicId) => {
              void handleUpdateStudyState({ currentTopicId: topicId });
              setChatPromptDraft(prompt);
              setActiveTab('chat');
            }}
            onStartQuiz={(quizId) => {
              setPendingQuizId(quizId);
              setActiveTab('practice');
            }}
            onOpenVaultMistakes={() => {
              setVaultInitialSection('mistakes');
              setActiveTab('vault');
            }}
            onLogStudyMinutes={(mins) =>
              void handleUpdateStudyState({
                studyMinutesToday: profile.studyMinutesToday + mins,
                totalStudyMinutes: profile.totalStudyMinutes + mins,
              })
            }
          />
        ) : activeTab === 'plan' ? (
          <StudyPlanView
            profile={profile}
            topicProgress={topicProgress}
            onLearnTopicInChat={(topic) => {
              void handleUpdateStudyState({
                currentSubject: topic.subject,
                currentTopicId: topic.id,
              });
              setChatPromptDraft(topic.starterPrompt);
              setActiveTab('chat');
            }}
            onMarkTopicViewed={handleMarkTopicViewed}
            onStartQuiz={(quizId) => {
              setPendingQuizId(quizId);
              setActiveTab('practice');
            }}
            onAdjustSchedule={(patch) => void handleUpdateStudyState(patch)}
          />
        ) : activeTab === 'practice' ? (
          <PracticeQuizView
            initialQuizId={pendingQuizId}
            quizAttempts={quizAttempts}
            errorLog={errorLog}
            onClearInitialQuiz={() => setPendingQuizId(null)}
            onSubmitQuizResult={handleSubmitQuizResult}
            onResolveErrorOnRedemption={(errorId, explanation) =>
              void handleToggleResolveError(errorId, true, explanation)
            }
            onAskMitraAboutQuestion={(prompt) => {
              setChatPromptDraft(prompt);
              setActiveTab('chat');
            }}
          />
        ) : (
          <StudyVaultView
            initialSection={vaultInitialSection}
            errorLog={errorLog}
            notes={notes}
            uploadedDocs={uploadedDocs}
            aiStatus={aiStatus}
            onVerifyLiveAi={handleVerifyLiveAi}
            onToggleResolveError={handleToggleResolveError}
            onPracticeErrorInChat={(err) => {
              setChatPromptDraft(
                `Mitra, help me master this question from my Error Log:\n\nQuestion: "${err.questionText}"\nMy wrong answer: ${err.studentAnswer}\nCorrect answer: ${err.correctAnswer}\n\nFirst explain why my wrong option trapped me in simple Hinglish, then give me 1 new similar practice problem and wait for my answer.`
              );
              setActiveTab('chat');
            }}
            onSaveNote={handleSaveNote}
            onDeleteNote={handleDeleteNote}
            onGenerateAiNote={handleGenerateAiNote}
            onAskPaperInChat={(paperId, prompt) => {
              setChatAttachmentDraft({
                id: `preset_${paperId}`,
                name:
                  paperId === 'cmat_2025_slot_1'
                    ? 'NTA CMAT 2025 Slot 1 Paper.pdf'
                    : 'NTA CMAT 2025 Slot 2 Paper.pdf',
                mimeType: 'application/pdf',
                presetPaperId: paperId,
              });
              setChatPromptDraft(prompt);
              setActiveTab('chat');
            }}
          />
        )}
      </main>
    </div>
  );
}
