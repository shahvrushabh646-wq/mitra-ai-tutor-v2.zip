import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Play,
  RotateCcw,
} from 'lucide-react';
import { CMAT_SYLLABUS_TOPICS, DAILY_TIMETABLE } from '../data/cmatCurriculum.ts';
import { formatTopicStatusLabel } from '../lib/progressCalculator.ts';
import type {
  SubjectKey,
  SyllabusTopic,
  TopicProgressRecord,
  UserLearningProfile,
} from '../types/mitra.ts';

interface StudyPlanViewProps {
  profile: UserLearningProfile;
  topicProgress: TopicProgressRecord[];
  onLearnTopicInChat: (topic: SyllabusTopic) => void;
  onMarkTopicViewed: (topic: SyllabusTopic) => void;
  onStartQuiz: (quizId: string) => void;
  onAdjustSchedule: (patch: { currentDay?: number; missedDaysOffset?: number }) => void;
}

const SUBJECT_FILTERS: Array<'All' | SubjectKey> = [
  'All',
  'Quantitative Techniques',
  'Logical Reasoning',
  'Language Comprehension',
  'General Knowledge',
  'Innovation & Entrepreneurship',
];

export const StudyPlanView: React.FC<StudyPlanViewProps> = ({
  profile,
  topicProgress,
  onLearnTopicInChat,
  onMarkTopicViewed,
  onStartQuiz,
  onAdjustSchedule,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<'All' | SubjectKey>('All');
  const [filterByCurrentDay, setFilterByCurrentDay] = useState(false);

  const progressMap = useMemo(
    () => new Map(topicProgress.map((t) => [t.topicId, t])),
    [topicProgress]
  );

  const visibleTopics = useMemo(() => {
    return CMAT_SYLLABUS_TOPICS.filter((t) => {
      if (selectedSubject !== 'All' && t.subject !== selectedSubject) return false;
      if (filterByCurrentDay && t.dayNumber !== profile.currentDay) return false;
      return true;
    });
  }, [selectedSubject, filterByCurrentDay, profile.currentDay]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 space-y-8">
      {/* Header & Flexible Schedule Controls */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-1.5 max-w-2xl">
          <div className="text-xs text-slate-500">
            CMAT 2026 Complete 5-Section Curriculum · Days 1–8 Sprint · 120 Minutes / Day
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            90+ Percentile Daily Timetable & Complete Syllabus Tracker
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Covers all 5 NTA CMAT sections with interactive lessons, topic assessments, mistake revision, timed sectional tests, and a full-length mock.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => onAdjustSchedule({ currentDay: d })}
                className={`px-2.5 py-1.5 font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  profile.currentDay === d
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Day {d}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() =>
              onAdjustSchedule({
                missedDaysOffset: (profile.missedDaysOffset || 0) + 1,
              })
            }
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5" />
            Missed a Day (+1d Shift)
          </button>

          {(profile.missedDaysOffset || 0) > 0 && (
            <button
              type="button"
              onClick={() => onAdjustSchedule({ missedDaysOffset: 0 })}
              className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset (+{profile.missedDaysOffset}d)
            </button>
          )}
        </div>
      </section>

      {/* Official 120-Minute Daily Study Timetable */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">
            Daily 2-Hour Study Timetable (Lessons + Practice + Mistake Revision)
          </h2>
          <span className="text-xs font-mono text-slate-600 tabular-nums">
            Total = 120 Minutes / Session
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm tabular-nums">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs text-slate-500">
                <th className="py-2.5 px-6 font-medium">Subject</th>
                <th className="py-2.5 px-4 font-medium text-right">Daily Time</th>
                <th className="py-2.5 px-6 font-medium">Learning Activity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {DAILY_TIMETABLE.map((slot) => (
                <tr key={slot.subject} className="hover:bg-slate-50/60">
                  <td className="py-3 px-6 font-medium text-slate-900 whitespace-nowrap">
                    {slot.alternateSubject
                      ? `${slot.subject} / ${slot.alternateSubject}`
                      : slot.subject}
                  </td>
                  <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900 text-right whitespace-nowrap">
                    {slot.dailyMinutes} minutes
                  </td>
                  <td className="py-3 px-6 text-xs text-slate-600">{slot.activity}</td>
                </tr>
              ))}
              <tr className="bg-slate-50 font-semibold text-slate-900">
                <td className="py-3 px-6 text-xs">Total Daily Commitment</td>
                <td className="py-3 px-4 font-mono text-xs text-right">120 minutes</td>
                <td className="py-3 px-6 text-xs text-slate-600 font-normal">
                  Structured two-hour focused CMAT 2026 study session (6 days/week + Day 8 Full Mock)
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Topic-wise Syllabus & Completion Tracker */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold text-slate-900">
              Day-wise & Topic-wise Syllabus Modules ({visibleTopics.length})
            </h2>
            <button
              type="button"
              onClick={() => setFilterByCurrentDay((v) => !v)}
              className={`px-3 py-1 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                filterByCurrentDay
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {filterByCurrentDay ? `Showing Day ${profile.currentDay} Only` : `Filter: Day ${profile.currentDay} Only`}
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {SUBJECT_FILTERS.map((subj) => (
              <button
                key={subj}
                type="button"
                onClick={() => setSelectedSubject(subj)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedSubject === subj
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {subj === 'Innovation & Entrepreneurship'
                  ? 'Entrepreneurship'
                  : subj === 'Quantitative Techniques'
                  ? 'Quant & DI'
                  : subj}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {visibleTopics.map((topic) => {
            const rec = progressMap.get(topic.id);
            const statusLabel = formatTopicStatusLabel(rec?.status);
            const effectiveDay = topic.dayNumber + (profile.missedDaysOffset || 0);

            return (
              <div
                key={topic.id}
                className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5"
              >
                <div className="space-y-2 max-w-3xl">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 tabular-nums">
                    <span className="font-semibold text-slate-800">Day {effectiveDay}</span>
                    <span aria-hidden="true">·</span>
                    <span>{topic.subject}</span>
                    <span aria-hidden="true">·</span>
                    <span>{topic.chapter}</span>
                    <span aria-hidden="true">·</span>
                    <span>{topic.estimatedMinutes} mins</span>
                    <span aria-hidden="true">·</span>
                    {rec?.status === 'mastered' || rec?.status === 'quiz_passed' ? (
                      <span className="text-emerald-700 font-medium inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {statusLabel} ({rec.bestScore}/{rec.totalQuestions})
                      </span>
                    ) : rec?.status === 'viewed' || rec?.status === 'quiz_attempted' ? (
                      <span className="text-amber-700 font-medium inline-flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        {statusLabel}
                      </span>
                    ) : (
                      <span className="text-slate-400 inline-flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {statusLabel}
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-semibold text-slate-900">{topic.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{topic.summary}</p>

                  <div className="flex flex-wrap gap-x-4 gap-y-1 pt-1 text-xs text-slate-500">
                    {topic.keyConcepts.map((kc) => (
                      <span key={kc}>• {kc}</span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => onLearnTopicInChat(topic)}
                    className="px-3.5 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Study with Mitra
                  </button>

                  {(!rec || rec.status === 'not_started') && (
                    <button
                      type="button"
                      onClick={() => onMarkTopicViewed(topic)}
                      className="px-3.5 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-medium rounded-lg hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      Mark Lesson Viewed
                    </button>
                  )}

                  {topic.linkedQuizId && (
                    <button
                      type="button"
                      onClick={() => onStartQuiz(topic.linkedQuizId!)}
                      className="px-3.5 py-2 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      {rec?.status === 'viewed' ? 'Take Pending Quiz' : 'Practice / Test'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
