import React from 'react';

interface QuestionDiagramProps {
  diagramType?: 'slot1_pie_placement' | 'slot2_bar_bread';
}

export const QuestionDiagram: React.FC<QuestionDiagramProps> = ({ diagramType }) => {
  if (!diagramType) return null;

  if (diagramType === 'slot1_pie_placement') {
    const studying = [
      { name: 'Operations', pct: 35, count: 1260 },
      { name: 'Finance', pct: 20, count: 720 },
      { name: 'Marketing', pct: 18, count: 648 },
      { name: 'Business Analytics', pct: 15, count: 540 },
      { name: 'HR', pct: 12, count: 432 },
    ];
    const placed = [
      { name: 'Operations', pct: 33, count: 396 },
      { name: 'Business Analytics', pct: 26, count: 312 },
      { name: 'Marketing', pct: 22, count: 264 },
      { name: 'HR', pct: 11, count: 132 },
      { name: 'Finance', pct: 8, count: 96 },
    ];

    return (
      <div className="my-4 p-4 bg-slate-50 border border-slate-200 rounded-lg">
        <div className="text-xs font-medium text-slate-600 mb-3">
          NTA CMAT 2025 Slot 1 Data Set · Total Studying = <span className="font-mono font-semibold text-slate-900">3,600</span> · Total Placed = <span className="font-mono font-semibold text-slate-900">1,200</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="text-xs font-semibold text-slate-800 mb-2">
              Chart 1: Students Studying (Total = 3,600)
            </div>
            <div className="space-y-1.5">
              {studying.map((item) => (
                <div key={item.name} className="flex items-center gap-3 text-xs tabular-nums">
                  <span className="w-32 text-slate-700 truncate">{item.name}</span>
                  <div className="flex-1 h-2 bg-slate-200 rounded overflow-hidden">
                    <div
                      className="h-full bg-slate-800"
                      style={{ width: `${item.pct * 2.4}%` }}
                    />
                  </div>
                  <span className="w-12 text-right font-mono font-medium text-slate-900">
                    {item.pct}%
                  </span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-800 mb-2">
              Chart 2: Students Recently Placed (Total = 1,200)
            </div>
            <div className="space-y-1.5">
              {placed.map((item) => (
                <div key={item.name} className="flex items-center gap-3 text-xs tabular-nums">
                  <span className="w-32 text-slate-700 truncate">{item.name}</span>
                  <div className="flex-1 h-2 bg-slate-200 rounded overflow-hidden">
                    <div
                      className="h-full bg-blue-700"
                      style={{ width: `${item.pct * 2.4}%` }}
                    />
                  </div>
                  <span className="w-12 text-right font-mono font-medium text-slate-900">
                    {item.pct}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (diagramType === 'slot2_bar_bread') {
    const stores = [
      { store: 'A', multigrain: 92, wholeWheat: 44 },
      { store: 'B', multigrain: 64, wholeWheat: 88 },
      { store: 'C', multigrain: 72, wholeWheat: 80 },
      { store: 'D', multigrain: 54, wholeWheat: 40 },
      { store: 'E', multigrain: 84, wholeWheat: 72 },
    ];

    return (
      <div className="my-4 p-4 bg-slate-50 border border-slate-200 rounded-lg">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs text-slate-600">
          <span>NTA CMAT 2025 Slot 2 Bar Graph · Bread Packets Sold by 5 Stores</span>
          <span className="font-mono">
            Dark = Multigrain · Blue = Whole-wheat
          </span>
        </div>
        <div className="grid grid-cols-5 gap-3 items-end h-36 pt-4 px-2 border-b border-slate-300">
          {stores.map((s) => (
            <div key={s.store} className="flex flex-col items-center h-full justify-end">
              <div className="flex items-end gap-1.5 w-full justify-center h-28">
                <div className="flex flex-col items-center justify-end h-full">
                  <span className="text-[10px] font-mono text-slate-700 mb-0.5">
                    {s.multigrain}
                  </span>
                  <div
                    className="w-4 sm:w-5 bg-slate-800 rounded-t-sm"
                    style={{ height: `${s.multigrain}%` }}
                    title={`Store ${s.store} Multigrain: ${s.multigrain}`}
                  />
                </div>
                <div className="flex flex-col items-center justify-end h-full">
                  <span className="text-[10px] font-mono text-blue-700 mb-0.5">
                    {s.wholeWheat}
                  </span>
                  <div
                    className="w-4 sm:w-5 bg-blue-600 rounded-t-sm"
                    style={{ height: `${s.wholeWheat}%` }}
                    title={`Store ${s.store} Whole-wheat: ${s.wholeWheat}`}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-5 gap-3 pt-1.5 text-center text-xs font-semibold text-slate-800">
          {stores.map((s) => (
            <div key={s.store}>Store {s.store}</div>
          ))}
        </div>
      </div>
    );
  }

  return null;
};
