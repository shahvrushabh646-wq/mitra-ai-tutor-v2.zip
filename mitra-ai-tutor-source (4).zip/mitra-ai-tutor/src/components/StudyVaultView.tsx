import React, { useEffect, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FileText,
  GitBranch,
  Layers,
  MessageSquare,
  Plus,
  RefreshCw,
  Sparkles,
  Trash2,
} from 'lucide-react';
import {
  FLASHCARDS_DECK,
  FORMULA_SHEETS,
  OFFICIAL_REFERENCE_PAPERS,
} from '../data/studyToolsData.ts';
import { apiFetch } from '../lib/apiClient.ts';
import { MarkdownRenderer } from './MarkdownRenderer.tsx';
import type {
  AIProviderStatus,
  ChatAttachment,
  ErrorLogRecord,
  StudyNoteRecord,
  SubjectKey,
} from '../types/mitra.ts';

interface StudyVaultViewProps {
  initialSection?: 'mistakes' | 'flashcards' | 'notes' | 'papers' | 'github';
  errorLog: ErrorLogRecord[];
  notes: StudyNoteRecord[];
  uploadedDocs: ChatAttachment[];
  aiStatus: AIProviderStatus | null;
  onVerifyLiveAi?: () => Promise<AIProviderStatus | null>;
  onToggleResolveError: (errorId: string, resolved: boolean, explanation: string) => void;
  onPracticeErrorInChat: (err: ErrorLogRecord) => void;
  onSaveNote: (note: {
    id?: string;
    title: string;
    subject: SubjectKey;
    topicId: string;
    content: string;
  }) => Promise<void>;
  onDeleteNote: (noteId: string) => Promise<void>;
  onGenerateAiNote: (subject: SubjectKey, topicPrompt: string) => Promise<void>;
  onAskPaperInChat: (paperId: 'cmat_2025_slot_1' | 'cmat_2025_slot_2', prompt: string) => void;
}

export const StudyVaultView: React.FC<StudyVaultViewProps> = ({
  initialSection = 'mistakes',
  errorLog,
  notes,
  uploadedDocs,
  aiStatus,
  onVerifyLiveAi,
  onToggleResolveError,
  onPracticeErrorInChat,
  onSaveNote,
  onDeleteNote,
  onGenerateAiNote,
  onAskPaperInChat,
}) => {
  const [section, setSection] = useState<'mistakes' | 'flashcards' | 'notes' | 'papers' | 'github'>(
    initialSection
  );

  useEffect(() => {
    setSection(initialSection);
  }, [initialSection]);

  // Flashcards State
  const [flippedIds, setFlippedIds] = useState<Record<string, boolean>>({});
  const [fcSubject, setFcSubject] = useState<string>('All');

  // Notes Editor State
  const [editingNoteTitle, setEditingNoteTitle] = useState('');
  const [editingNoteSubject, setEditingNoteSubject] = useState<SubjectKey>('Quantitative Techniques');
  const [editingNoteContent, setEditingNoteContent] = useState('');
  const [showNewNoteForm, setShowNewNoteForm] = useState(false);
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);
  const [copiedNoteId, setCopiedNoteId] = useState<string | null>(null);
  const [notesFilter, setNotesFilter] = useState<'all' | 'bookmarks'>('all');
  const [mistakeStatusFilter, setMistakeStatusFilter] = useState<'all' | 'unresolved'>('all');
  const [verifyingAi, setVerifyingAi] = useState(false);

  // Reference Paper Viewer State
  const [activePaperId, setActivePaperId] = useState<'cmat_2025_slot_1' | 'cmat_2025_slot_2'>(
    'cmat_2025_slot_1'
  );

  // GitHub Integration State
  const [ghStatus, setGhStatus] = useState<{
    oauthConfigured: boolean;
    connected: boolean;
    user: { login: string; avatar_url: string; html_url: string } | null;
    callbackPath: string;
  } | null>(null);
  const [ghExportUrl, setGhExportUrl] = useState<string | null>(null);
  const [ghMessage, setGhMessage] = useState<string | null>(null);
  const [ghBusy, setGhBusy] = useState(false);

  const fetchGithubStatus = async () => {
    try {
      const res = await apiFetch('/api/github/status');
      if (res.ok) {
        const data = await res.json();
        setGhStatus(data);
      }
    } catch {
      // Ignore network hiccup
    }
  };

  useEffect(() => {
    void fetchGithubStatus();
    const handleMsg = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS' && event.data?.provider === 'github') {
        void fetchGithubStatus();
      }
    };
    window.addEventListener('message', handleMsg);
    return () => window.removeEventListener('message', handleMsg);
  }, []);

  const handleConnectGithub = async () => {
    setGhMessage(null);
    try {
      const res = await apiFetch(
        `/api/github/auth/url?origin=${encodeURIComponent(window.location.origin)}`
      );
      const data = await res.json();
      if (!res.ok || !data.url) {
        setGhMessage(data.error || 'GitHub OAuth requires GITHUB_CLIENT_ID in Secrets.');
        return;
      }
      const popup = window.open(data.url, 'github_oauth_popup', 'width=620,height=720');
      if (!popup) {
        setGhMessage('Popup was blocked by browser. Please allow popups for this site.');
      }
    } catch (err) {
      setGhMessage(err instanceof Error ? err.message : 'Could not initiate GitHub OAuth.');
    }
  };

  const handleExportGist = async () => {
    setGhBusy(true);
    setGhMessage(null);
    setGhExportUrl(null);
    try {
      const res = await apiFetch('/api/github/export-gist', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setGhMessage(data.error || 'Failed exporting to GitHub Gist.');
        return;
      }
      setGhExportUrl(data.url);
    } catch (err) {
      setGhMessage(err instanceof Error ? err.message : 'GitHub export failed.');
    } finally {
      setGhBusy(false);
    }
  };

  const handleDownloadMarkdownVault = async () => {
    try {
      const res = await apiFetch('/api/workspace/export-markdown');
      const md = await res.text();
      const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Mitra_CMAT_2026_Study_Vault.md';
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      // Ignore
    }
  };

  const activePaper =
    OFFICIAL_REFERENCE_PAPERS.find((p) => p.id === activePaperId) || OFFICIAL_REFERENCE_PAPERS[0];

  const visibleFlashcards =
    fcSubject === 'All'
      ? FLASHCARDS_DECK
      : FLASHCARDS_DECK.filter((f) => f.subject === fcSubject);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 space-y-6">
      {/* Sub-navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
          {[
            { id: 'mistakes' as const, label: `Error Log (${errorLog.filter((e) => !e.resolved).length})` },
            { id: 'flashcards' as const, label: 'Flashcards & Formulas' },
            { id: 'notes' as const, label: `Study Notes (${notes.length})` },
            { id: 'papers' as const, label: 'CMAT 2025 Papers (Slot 1 & 2)' },
            { id: 'github' as const, label: 'GitHub Sync & Setup' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSection(tab.id)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                section === tab.id
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <a
            href="/api/workspace/download-zip"
            download="mitra-ai-tutor-source.zip"
            className="px-3.5 py-2 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Download Source (.zip)
          </a>

          <button
            type="button"
            onClick={handleDownloadMarkdownVault}
            className="px-3.5 py-2 bg-white border border-slate-200 text-slate-800 text-xs font-medium rounded-lg hover:bg-slate-50 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download Full Vault (.md)
          </button>
        </div>
      </div>

      {/* SECTION 1: PERSONAL ERROR LOG & REVISION QUEUE */}
      {section === 'mistakes' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">
                Personal Mistake Notebook & Revision Queue
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Every missed quiz question is logged with your answer, correct solution, mistake category, and 1-click remedial practice with Mitra.
              </p>
            </div>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => setMistakeStatusFilter('all')}
                className={`px-3 py-1 rounded-md font-medium cursor-pointer ${
                  mistakeStatusFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({errorLog.length})
              </button>
              <button
                type="button"
                onClick={() => setMistakeStatusFilter('unresolved')}
                className={`px-3 py-1 rounded-md font-medium cursor-pointer ${
                  mistakeStatusFilter === 'unresolved'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Unresolved ({errorLog.filter((e) => !e.resolved).length})
              </button>
            </div>
          </div>

          {errorLog.filter((e) => (mistakeStatusFilter === 'unresolved' ? !e.resolved : true))
            .length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
              No unresolved mistakes right now. Any wrong answers in quizzes will automatically appear here for targeted revision.
            </div>
          ) : (
            <div className="space-y-4">
              {errorLog
                .filter((e) => (mistakeStatusFilter === 'unresolved' ? !e.resolved : true))
                .map((err) => (
                <div
                  key={err.id}
                  className="bg-white border border-slate-200 rounded-xl p-6 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                    <div>
                      <span className="font-semibold text-slate-900">{err.subject}</span>
                      <span aria-hidden="true"> · </span>
                      <span className="capitalize">
                        Mistake Type: {err.mistakeType.replace('_', ' ')}
                      </span>
                      <span aria-hidden="true"> · </span>
                      <span className={err.resolved ? 'text-emerald-700 font-medium' : 'text-amber-700 font-medium'}>
                        {err.resolved ? 'Reviewed & Resolved' : 'Needs Revision'}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => onPracticeErrorInChat(err)}
                        className="text-blue-700 font-medium hover:underline inline-flex items-center gap-1 cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        Remedial Drill with Mitra
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          onToggleResolveError(err.id, !err.resolved, err.explanation)
                        }
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium rounded-md inline-flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {err.resolved ? 'Mark Unresolved' : 'Mark Mastered'}
                      </button>
                    </div>
                  </div>

                  <div className="text-sm font-medium text-slate-900">{err.questionText}</div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-red-50/60 border border-red-200 rounded-lg text-red-950">
                      <strong>Your Recorded Answer:</strong> {err.studentAnswer}
                    </div>
                    <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-lg text-emerald-950">
                      <strong>Verified Correct Answer:</strong> {err.correctAnswer}
                    </div>
                  </div>

                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 leading-relaxed">
                    <strong>Concept Explanation:</strong> {err.explanation}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: FLASHCARDS & FORMULA SHEETS */}
      {section === 'flashcards' && (
        <div className="space-y-8">
          <section className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900">
                  Active-Recall Flashcards (Click Card to Flip)
                </h2>
                <p className="text-xs text-slate-500">
                  High-yield CMAT formulas, vocabulary, Constitutional Articles, and entrepreneurship concepts.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
                {[
                  'All',
                  'Quantitative Techniques',
                  'Logical Reasoning',
                  'Language Comprehension',
                  'General Knowledge',
                  'Innovation & Entrepreneurship',
                ].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setFcSubject(s)}
                    className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                      fcSubject === s
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {s === 'Innovation & Entrepreneurship'
                      ? 'Entrepreneurship'
                      : s === 'Quantitative Techniques'
                      ? 'Quant'
                      : s}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {visibleFlashcards.map((fc) => {
                const flipped = Boolean(flippedIds[fc.id]);
                return (
                  <button
                    key={fc.id}
                    type="button"
                    onClick={() =>
                      setFlippedIds((prev) => ({ ...prev, [fc.id]: !prev[fc.id] }))
                    }
                    className={`text-left p-5 rounded-xl border transition-colors min-h-40 flex flex-col justify-between cursor-pointer ${
                      flipped
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-900 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div
                      className={`text-[11px] flex items-center justify-between ${
                        flipped ? 'text-slate-300' : 'text-slate-500'
                      }`}
                    >
                      <span>
                        {fc.subject} · {fc.category}
                      </span>
                      <Layers className="w-3.5 h-3.5" />
                    </div>
                    <div className="my-3 text-sm font-medium leading-relaxed">
                      {flipped ? fc.back : fc.front}
                    </div>
                    <div
                      className={`text-[11px] font-medium ${
                        flipped ? 'text-blue-300' : 'text-blue-700'
                      }`}
                    >
                      {flipped ? 'Showing Answer · Click for Question' : 'Click to Reveal Answer'}
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-lg font-bold text-slate-900">
              CMAT Quick-Reference Formula Sheets
            </h2>
            <div className="grid grid-cols-1 gap-5">
              {FORMULA_SHEETS.map((sheet) => (
                <div
                  key={sheet.id}
                  className="bg-white border border-slate-200 rounded-xl overflow-hidden"
                >
                  <div className="px-6 py-3.5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-slate-900">{sheet.title}</h3>
                    <span className="text-xs text-slate-500">{sheet.subject}</span>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {sheet.items.map((item) => (
                      <div
                        key={item.name}
                        className="px-6 py-3.5 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs"
                      >
                        <div className="font-semibold text-slate-900">{item.name}</div>
                        <div className="font-mono text-blue-800">{item.formula}</div>
                        <div className="text-slate-600">{item.example}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* SECTION 3: SAVED STUDY NOTES & AI NOTE GENERATOR */}
      {section === 'notes' && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">
                Revision Notes, Bookmarked Answers & AI Summary Generator
              </h1>
              <p className="text-xs text-slate-500">
                Revisit bookmarked tutor explanations, create custom formula sheets, or generate structured revision notes using Live AI.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
                <button
                  type="button"
                  onClick={() => setNotesFilter('all')}
                  className={`px-2.5 py-1 rounded font-medium cursor-pointer ${
                    notesFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All Notes ({notes.length})
                </button>
                <button
                  type="button"
                  onClick={() => setNotesFilter('bookmarks')}
                  className={`px-2.5 py-1 rounded font-medium cursor-pointer ${
                    notesFilter === 'bookmarks'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Bookmarked ({notes.filter((n) => n.title.startsWith('[Bookmarked]')).length})
                </button>
              </div>

              <button
                type="button"
                disabled={isGeneratingNote}
                onClick={async () => {
                  setIsGeneratingNote(true);
                  try {
                    await onGenerateAiNote(
                      editingNoteSubject,
                      `Generate concise, exam-ready CMAT 2026 revision notes, 5 active-recall Q&A flashcards, and 2 solved examples for ${editingNoteSubject}.`
                    );
                  } finally {
                    setIsGeneratingNote(false);
                  }
                }}
                className="px-3.5 py-2 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isGeneratingNote ? 'Generating Revision Sheet...' : 'AI Revision Sheet'}
              </button>

              <button
                type="button"
                onClick={() => setShowNewNoteForm((v) => !v)}
                className="px-3.5 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                New Custom Note
              </button>
            </div>
          </div>

          {showNewNoteForm && (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!editingNoteTitle.trim() || !editingNoteContent.trim()) return;
                await onSaveNote({
                  title: editingNoteTitle.trim(),
                  subject: editingNoteSubject,
                  topicId: 'custom_note',
                  content: editingNoteContent.trim(),
                });
                setEditingNoteTitle('');
                setEditingNoteContent('');
                setShowNewNoteForm(false);
              }}
              className="bg-white border border-slate-200 rounded-xl p-5 space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  value={editingNoteTitle}
                  onChange={(e) => setEditingNoteTitle(e.target.value)}
                  placeholder="Note title (e.g., Cloze Passage Tricks)"
                  className="sm:col-span-2 px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
                <select
                  value={editingNoteSubject}
                  onChange={(e) => setEditingNoteSubject(e.target.value as SubjectKey)}
                  className="px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:border-blue-600"
                >
                  <option value="Quantitative Techniques">Quantitative Techniques</option>
                  <option value="Logical Reasoning">Logical Reasoning</option>
                  <option value="Language Comprehension">Language Comprehension</option>
                  <option value="General Knowledge">General Knowledge</option>
                  <option value="Innovation & Entrepreneurship">Innovation & Entrepreneurship</option>
                </select>
              </div>
              <textarea
                rows={5}
                required
                value={editingNoteContent}
                onChange={(e) => setEditingNoteContent(e.target.value)}
                placeholder="Write Markdown or LaTeX ($a^2 + b^2$) notes..."
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewNoteForm(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  Save Note
                </button>
              </div>
            </form>
          )}

          <div className="space-y-4">
            {notes
              .filter((n) =>
                notesFilter === 'bookmarks' ? n.title.startsWith('[Bookmarked]') : true
              )
              .map((n) => (
              <div
                key={n.id}
                className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-semibold text-slate-900">{n.title}</h3>
                    <div className="text-xs text-slate-500">{n.subject}</div>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-600">
                    <button
                      type="button"
                      onClick={async () => {
                        await navigator.clipboard.writeText(n.content);
                        setCopiedNoteId(n.id);
                        setTimeout(() => setCopiedNoteId(null), 1800);
                      }}
                      className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                    >
                      {copiedNoteId === n.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" /> Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> Copy
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteNote(n.id)}
                      className="inline-flex items-center gap-1 text-slate-500 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                </div>
                <MarkdownRenderer content={n.content} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 4: OFFICIAL NTA CMAT 2025 SLOT 1 & SLOT 2 PAPERS */}
      {section === 'papers' && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-slate-900">
                Official NTA CMAT Jan 2025 Question Papers & Uploaded Documents
              </h1>
              <p className="text-xs text-slate-500">
                Read the full official papers side-by-side or send any section directly to Mitra AI Tutor for step-by-step multimodal PDF explanations.
              </p>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {OFFICIAL_REFERENCE_PAPERS.map((paper) => (
                <button
                  key={paper.id}
                  type="button"
                  onClick={() => setActivePaperId(paper.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                    activePaperId === paper.id
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {paper.id === 'cmat_2025_slot_1' ? 'CMAT 2025 Slot 1' : 'CMAT 2025 Slot 2'}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div>
                <div className="text-xs text-slate-500">{activePaper.dateLabel}</div>
                <h2 className="text-base font-semibold text-slate-900 mt-0.5">
                  {activePaper.title}
                </h2>
              </div>

              <div className="space-y-2 text-xs text-slate-600">
                <div className="font-semibold text-slate-800">Paper Structure (100 MCQs):</div>
                {activePaper.sections.map((sec) => (
                  <div key={sec} className="leading-relaxed">
                    • {sec}
                  </div>
                ))}
              </div>

              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={() =>
                    onAskPaperInChat(
                      activePaper.id,
                      `Using the attached ${activePaper.title}, summarize the topic distribution across Quant, LR, Language, GK, and Entrepreneurship, and solve 2 tricky questions step by step.`
                    )
                  }
                  className="w-full px-4 py-2.5 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Analyze This Paper with Mitra AI
                </button>

                <a
                  href={activePaper.url}
                  download
                  className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 text-xs font-medium rounded-lg hover:bg-slate-50 inline-flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Official PDF
                </a>
              </div>

              {uploadedDocs.length > 0 && (
                <div className="pt-4 border-t border-slate-100 space-y-2">
                  <div className="text-xs font-semibold text-slate-800">
                    Your Uploaded Study Documents ({uploadedDocs.length})
                  </div>
                  {uploadedDocs.map((d) => (
                    <div
                      key={d.id}
                      className="flex items-center gap-2 text-xs text-slate-600 truncate"
                    >
                      <FileText className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                      <span className="truncate">{d.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden h-[640px]">
              <iframe
                src={activePaper.url}
                title={activePaper.title}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}

      {/* SECTION 5: GITHUB SYNC & SYSTEM ARCHITECTURE GUIDE */}
      {section === 'github' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-slate-700" />
                GitHub Study Vault Connection
              </h2>
              <button
                type="button"
                onClick={fetchGithubStatus}
                className="text-xs text-slate-500 hover:text-slate-900 inline-flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" /> Refresh
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Download the complete Mitra AI Tutor codebase as a portable <code>.zip</code> archive, export your study notes as Markdown, or sync directly to a private GitHub Gist.
            </p>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="text-xs font-semibold text-slate-900">
                  Full Project Source Code (.zip)
                </div>
                <div className="text-[11px] text-slate-600">
                  Includes React frontend, Express + Gemini backend, Firestore rules, and CMAT curriculum (excludes secrets & node_modules).
                </div>
              </div>
              <a
                href="/api/workspace/download-zip"
                download="mitra-ai-tutor-source.zip"
                className="px-4 py-2 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                Download Project ZIP
              </a>
            </div>

            {ghStatus?.connected && ghStatus.user ? (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-emerald-700">
                    Connected as @{ghStatus.user.login}
                  </span>
                  <a
                    href={ghStatus.user.html_url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-700 hover:underline inline-flex items-center gap-1"
                  >
                    Profile <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
                <button
                  type="button"
                  disabled={ghBusy}
                  onClick={handleExportGist}
                  className="w-full px-4 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 cursor-pointer disabled:opacity-50"
                >
                  {ghBusy ? 'Syncing Study Vault to GitHub...' : 'Sync Progress & Notes to Private GitHub Gist'}
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleConnectGithub}
                  className="px-4 py-2.5 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 inline-flex items-center gap-2 cursor-pointer"
                >
                  <GitBranch className="w-3.5 h-3.5" />
                  Connect GitHub Account
                </button>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 space-y-1.5">
                  <div className="font-semibold text-slate-800">GitHub OAuth App Setup:</div>
                  <div>
                    1. Register an OAuth App at <code className="text-[11px]">github.com/settings/developers</code>
                  </div>
                  <div>
                    2. Set Authorization callback URL to:{' '}
                    <code className="text-[11px] break-all">
                      {window.location.origin}/auth/github/callback
                    </code>
                  </div>
                  <div>
                    3. Add <code className="text-[11px]">GITHUB_CLIENT_ID</code> and{' '}
                    <code className="text-[11px]">GITHUB_CLIENT_SECRET</code> in the AI Studio Secrets panel.
                  </div>
                </div>
              </div>
            )}

            {ghMessage && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
                {ghMessage}
              </div>
            )}

            {ghExportUrl && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900 flex items-center justify-between">
                <span>Exported successfully to GitHub!</span>
                <a
                  href={ghExportUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="font-semibold underline inline-flex items-center gap-1"
                >
                  Open Gist <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-base font-semibold text-slate-900">
                AI Model Verification & User-Scoped Persistence
              </h2>
              {onVerifyLiveAi && (
                <button
                  type="button"
                  disabled={verifyingAi}
                  onClick={async () => {
                    setVerifyingAi(true);
                    try {
                      await onVerifyLiveAi();
                    } finally {
                      setVerifyingAi(false);
                    }
                  }}
                  className="px-3 py-1.5 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 ${verifyingAi ? 'animate-spin' : ''}`} />
                  {verifyingAi ? 'Probing Model...' : 'Run Live API Check'}
                </button>
              )}
            </div>
            <div className="divide-y divide-slate-100 text-xs tabular-nums">
              <div className="py-2.5 flex justify-between gap-4">
                <span className="text-slate-500">Provider SDK</span>
                <span className="font-medium text-slate-900">
                  {aiStatus?.provider || 'Google Gemini (@google/genai)'}
                </span>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <span className="text-slate-500">Active Supported Model</span>
                <span className="font-mono font-semibold text-slate-900">
                  {aiStatus?.activeModel || 'gemini-3.1-flash-lite-preview'}
                </span>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <span className="text-slate-500">Mode & Probe Status</span>
                <span
                  className={
                    aiStatus?.liveAvailable
                      ? 'font-semibold text-emerald-700'
                      : 'font-semibold text-amber-700'
                  }
                >
                  {aiStatus?.liveAvailable
                    ? aiStatus.verifiedLive
                      ? `Verified Live (${aiStatus.probeLatencyMs ?? 0}ms)`
                      : 'Live Streaming AI'
                    : `Offline Tutor Fallback${aiStatus?.errorCategory ? ` (${aiStatus.errorCategory})` : ''}`}
                </span>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <span className="text-slate-500">Workspace Isolation</span>
                <span className="font-medium text-slate-900">
                  User-Scoped Cloud Firestore + Authenticated Principal Store
                </span>
              </div>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 leading-relaxed">
              {aiStatus?.diagnosticMessage ||
                'Live AI model availability is verified via real server-side API probes, with automatic fallback to structured CMAT offline lessons if unavailable.'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
