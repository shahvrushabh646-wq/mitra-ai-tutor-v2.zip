import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Award,
  CheckCircle2,
  Clock,
  Play,
  RotateCcw,
  Target,
} from 'lucide-react';
import {
  computeDailyProgressCard,
  computeSectionAnalytics,
  formatTopicStatusLabel,
} from '../lib/progressCalculator.ts';
import { CMAT_SYLLABUS_TOPICS } from '../data/cmatCurriculum.ts';
import type {
  ErrorLogRecord,
  QuizAttemptRecord,
  TopicProgressRecord,
  UserLearningProfile,
} from '../types/mitra.ts';

interface DashboardViewProps {
  profile: UserLearningProfile;
  topicProgress: TopicProgressRecord[];
  quizAttempts: QuizAttemptRecord[];
  errorLog: ErrorLogRecord[];
  onResumeLesson: (prompt: string, topicId: string) => void;
  onStartQuiz: (quizId: string) => void;
  onOpenVaultMistakes: () => void;
  onLogStudyMinutes: (mins: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  topicProgress,
  quizAttempts,
  errorLog,
  onResumeLesson,
  onStartQuiz,
  onOpenVaultMistakes,
  onLogStudyMinutes,
}) => {
  const [selectedCardDay, setSelectedCardDay] = useState<number>(profile.currentDay || 1);

  useEffect(() => {
    setSelectedCardDay(profile.currentDay || 1);
  }, [profile.currentDay]);

  const currentDayCard = useMemo(
    () =>
      computeDailyProgressCard({
        dayNumber: profile.currentDay || 1,
        profile,
        topicProgress,
        quizAttempts,
        errorLog,
      }),
    [profile, topicProgress, quizAttempts, errorLog]
  );

  const activeCard = useMemo(
    () =>
      computeDailyProgressCard({
        dayNumber: selectedCardDay,
        profile,
        topicProgress,
        quizAttempts,
        errorLog,
      }),
    [selectedCardDay, profile, topicProgress, quizAttempts, errorLog]
  );

  const sectionAnalytics = useMemo(
    () =>
      computeSectionAnalytics({
        topicProgress,
        quizAttempts,
        errorLog,
      }),
    [topicProgress, quizAttempts, errorLog]
  );

  const masteredCount = topicProgress.filter(
    (t) => t.status === 'mastered' || t.status === 'quiz_passed'
  ).length;
  const totalSyllabusCount = CMAT_SYLLABUS_TOPICS.length;
  const unresolvedErrors = errorLog.filter((e) => !e.resolved);

  const weeklyTargetMinutes = 720; // 6 days * 120 mins
  const weeklyPct = Math.min(
    100,
    Math.round((profile.totalStudyMinutes / weeklyTargetMinutes) * 100)
  );

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 space-y-8">
      {/* Primary Focal Banner: Dynamic Next Recommended Action & 1-Click Resume */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs text-slate-500 tabular-nums">
            CMAT 2026 Target: 90+ Percentile · Day {profile.currentDay} Active ·{' '}
            {profile.studyMinutesToday} / 120 mins studied today
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            {currentDayCard.nextRecommendedAction.label}
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            {currentDayCard.nextRecommendedAction.reason}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() =>
              onResumeLesson(
                currentDayCard.nextRecommendedAction.prompt,
                currentDayCard.nextRecommendedAction.topicId
              )
            }
            className="px-4 py-2.5 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Learn with Mitra
          </button>

          {currentDayCard.nextRecommendedAction.quizId && (
            <button
              type="button"
              onClick={() => onStartQuiz(currentDayCard.nextRecommendedAction.quizId!)}
              className="px-4 py-2.5 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Take Linked Assessment
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          {unresolvedErrors.length > 0 && (
            <button
              type="button"
              onClick={() => onStartQuiz('quiz_mistake_redemption')}
              className="px-4 py-2.5 bg-amber-50 border border-amber-300 text-amber-900 text-xs font-medium rounded-lg hover:bg-amber-100 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Mistake Drill ({unresolvedErrors.length})
            </button>
          )}
        </div>
      </section>

      {/* Cumulative KPI Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Today’s Study Time</div>
          <div className="mt-1.5 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {profile.studyMinutesToday} / 120m
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
            <span>
              Weekly: {profile.totalStudyMinutes} / 720m ({weeklyPct}%)
            </span>
            <button
              type="button"
              onClick={() => onLogStudyMinutes(15)}
              className="text-blue-700 font-medium hover:underline cursor-pointer"
            >
              +15m
            </button>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Syllabus Mastery (All 5 Sections)</div>
          <div className="mt-1.5 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {masteredCount} / {totalSyllabusCount}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            {topicProgress.filter((t) => t.status === 'viewed').length} viewed with pending quiz
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Verified Quiz Accuracy</div>
          <div className="mt-1.5 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {currentDayCard.overallAccuracy}%
          </div>
          <div className="mt-2 text-xs text-slate-500 tabular-nums">
            {currentDayCard.quizzesPassed} passed out of {currentDayCard.quizzesAttempted} attempts
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs text-slate-500">Unresolved Mistake Queue</div>
          <div className="mt-1.5 text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {unresolvedErrors.length}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={onOpenVaultMistakes}
              className="text-blue-700 font-medium hover:underline cursor-pointer"
            >
              {unresolvedErrors.length > 0 ? 'Open mistake notebook ->' : 'All mistakes cleared'}
            </button>
          </div>
        </div>
      </section>

      {/* 5-Section CMAT Mastery, Accuracy & Weak-Area Matrix */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              5-Section CMAT 2026 Mastery, Accuracy & Weak-Area Matrix
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Tracks topic mastery, verified accuracy, study minutes, and unresolved mistakes across all five official NTA CMAT sections.
            </p>
          </div>

          <button
            type="button"
            onClick={() => onStartQuiz('mock_cmat_2026_full_diagnostic')}
            className="px-3.5 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Award className="w-3.5 h-3.5" />
            Take Full 5-Section CMAT Mock (+4 / -1)
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm tabular-nums">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs text-slate-500">
                <th className="py-2.5 px-6 font-medium">CMAT Section</th>
                <th className="py-2.5 px-4 font-medium">Mastered</th>
                <th className="py-2.5 px-4 font-medium">Accuracy</th>
                <th className="py-2.5 px-4 font-medium">Time Spent</th>
                <th className="py-2.5 px-4 font-medium">Open Mistakes</th>
                <th className="py-2.5 px-6 font-medium">Weak / Focus Topics</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sectionAnalytics.map((sec) => (
                <tr key={sec.subject} className="hover:bg-slate-50/60">
                  <td className="py-3.5 px-6 font-medium text-slate-900 whitespace-nowrap">
                    {sec.subject}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-800 whitespace-nowrap">
                    {sec.masteredTopics}/{sec.totalTopics} ({sec.masteryPercent}%)
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs whitespace-nowrap">
                    {sec.attemptsCount > 0 ? (
                      <span
                        className={
                          sec.accuracyPercent >= 75
                            ? 'text-emerald-700 font-semibold'
                            : 'text-amber-700 font-semibold'
                        }
                      >
                        {sec.accuracyPercent}%
                      </span>
                    ) : (
                      <span className="text-slate-400">No quiz yet</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-600 whitespace-nowrap">
                    {sec.timeSpentMinutes}m
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs whitespace-nowrap">
                    {sec.unresolvedErrors > 0 ? (
                      <span className="text-red-700 font-semibold">{sec.unresolvedErrors}</span>
                    ) : (
                      <span className="text-emerald-700">0</span>
                    )}
                  </td>
                  <td className="py-3.5 px-6 text-xs text-slate-600 max-w-xs">
                    {sec.weakTopics.length > 0 ? (
                      <span className="text-amber-800">{sec.weakTopics.join(', ')}</span>
                    ) : sec.masteredTopics > 0 ? (
                      <span className="text-emerald-700">Strong — keep revising</span>
                    ) : (
                      <span className="text-slate-400">Scheduled in Study Plan</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Reopenable Daily Progress Card & Subject Breakdown */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Verified Daily Progress Cards (Days 1–8)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Generated dynamically from recorded lessons and verified quiz attempts. Viewed topics with pending quizzes are never marked mastered prematurely.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setSelectedCardDay(d)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCardDay === d
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Day {d}
                {profile.currentDay === d ? ' · Active' : ''}
              </button>
            ))}
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 pb-4 border-b border-slate-100 tabular-nums">
            <span className="font-semibold text-slate-900">{activeCard.dateLabel}</span>
            <span>
              Time Logged:{' '}
              <strong className="font-mono text-slate-900">
                {activeCard.minutesStudied} mins
              </strong>{' '}
              / {activeCard.targetMinutes} mins target
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm tabular-nums">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 pr-4 font-medium">Subject</th>
                  <th className="py-2.5 px-4 font-medium">Target</th>
                  <th className="py-2.5 px-4 font-medium">Recorded Activity</th>
                  <th className="py-2.5 pl-4 font-medium text-right">Verification Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeCard.subjects.map((row) => (
                  <tr key={row.subject} className="hover:bg-slate-50/70">
                    <td className="py-3.5 pr-4 font-medium text-slate-900 whitespace-nowrap">
                      {row.subject}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-600 whitespace-nowrap">
                      {row.targetMinutes}m
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 max-w-md">
                      {row.detail}
                    </td>
                    <td className="py-3.5 pl-4 text-right whitespace-nowrap">
                      {row.completed && !row.pendingAssessment ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {row.statusLabel}
                        </span>
                      ) : row.pendingAssessment ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          {row.statusLabel}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
                          <Clock className="w-3.5 h-3.5" />
                          {row.statusLabel}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Strong Areas vs Revision Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <div className="text-xs font-semibold text-emerald-800 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5" />
                Verified Strong Areas
              </div>
              {activeCard.strongAreas.length === 0 ? (
                <p className="text-xs text-slate-500">
                  Complete your first topic quiz to unlock verified strengths.
                </p>
              ) : (
                <ul className="space-y-1 text-xs text-slate-700">
                  {activeCard.strongAreas.map((area) => (
                    <li key={area}>• {area}</li>
                  ))}
                </ul>
              )}
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <div className="text-xs font-semibold text-amber-800 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Pending Assessments & Revision Focus
              </div>
              {activeCard.revisionNeeded.length === 0 ? (
                <p className="text-xs text-slate-500">
                  All current assessments passed and error log cleared!
                </p>
              ) : (
                <ul className="space-y-1 text-xs text-slate-700">
                  {activeCard.revisionNeeded.map((area) => (
                    <li key={area}>• {area}</li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Verified Quiz Attempts History & Topic Mastery Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              Verified Quiz & Mock Assessment History
            </h3>
            <span className="text-xs text-slate-500 tabular-nums">
              {quizAttempts.length} recorded
            </span>
          </div>

          {quizAttempts.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No completed quizzes yet.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto pr-1">
              {quizAttempts.map((qa) => (
                <div
                  key={qa.id}
                  className="py-3 flex items-center justify-between gap-4 text-xs tabular-nums"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-900 truncate">{qa.title}</div>
                    <div className="text-slate-500 mt-0.5">
                      {qa.subject} · {Math.floor(qa.durationSeconds / 60)}m{' '}
                      {qa.durationSeconds % 60}s
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono font-semibold text-slate-900">
                      {qa.score}/{qa.total} ({qa.accuracyPercent}%)
                      {qa.rawMarks !== undefined && qa.maxMarks !== undefined
                        ? ` · ${qa.rawMarks}/${qa.maxMarks} marks`
                        : ''}
                    </div>
                    <div className={qa.passed ? 'text-emerald-700' : 'text-amber-700'}>
                      {qa.passed ? 'Passed' : 'Needs Retry'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              Topic Completion & Mastery States ({CMAT_SYLLABUS_TOPICS.length} Modules)
            </h3>
            <span className="text-xs text-slate-500">Strict 4-Stage Distinction</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto pr-1">
            {CMAT_SYLLABUS_TOPICS.map((topic) => {
              const rec = topicProgress.find((t) => t.topicId === topic.id);
              const label = formatTopicStatusLabel(rec?.status);
              return (
                <div
                  key={topic.id}
                  className="py-2.5 flex items-center justify-between gap-4 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-medium text-slate-900 truncate">{topic.title}</div>
                    <div className="text-slate-500">
                      Day {topic.dayNumber} · {topic.subject}
                    </div>
                  </div>
                  <div className="text-right shrink-0 tabular-nums">
                    <div
                      className={`font-medium ${
                        rec?.status === 'mastered' || rec?.status === 'quiz_passed'
                          ? 'text-emerald-700'
                          : rec?.status === 'viewed' || rec?.status === 'quiz_attempted'
                          ? 'text-amber-700'
                          : 'text-slate-400'
                      }`}
                    >
                      {label}
                    </div>
                    {rec && rec.attemptsCount > 0 && (
                      <div className="text-[11px] font-mono text-slate-500">
                        Best: {rec.bestScore}/{rec.totalQuestions}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
};
