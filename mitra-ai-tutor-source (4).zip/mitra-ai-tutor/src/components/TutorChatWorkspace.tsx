import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  ArchiveRestore,
  ArrowDown,
  ArrowUp,
  Bookmark,
  BookmarkPlus,
  Check,
  ChevronDown,
  Copy,
  Download,
  Edit3,
  FileText,
  Headphones,
  Loader2,
  Mic,
  PanelLeftClose,
  PanelLeftOpen,
  Paperclip,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Square,
  SquarePen,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { apiFetch } from '../lib/apiClient.ts';
import { MarkdownRenderer } from './MarkdownRenderer.tsx';
import type {
  AIProviderStatus,
  ChatAttachment,
  ChatMessageItem,
  ConversationThread,
  ExplanationDepth,
  ExplanationLanguage,
  UserLearningProfile,
} from '../types/mitra.ts';

export type ModelTier = 'fast' | 'thinking';

interface TutorChatWorkspaceProps {
  conversations: ConversationThread[];
  activeConversationId: string;
  messages: ChatMessageItem[];
  isStreaming: boolean;
  streamingText: string;
  streamingModel: string;
  aiStatus: AIProviderStatus | null;
  profile: UserLearningProfile;
  uploadedDocs: ChatAttachment[];
  initialPromptDraft?: string;
  initialAttachmentDraft?: ChatAttachment | null;
  onClearInitialDraft: () => void;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onRenameConversation: (id: string, title: string) => void;
  onToggleArchiveConversation: (id: string, archived: boolean) => void;
  onDeleteConversation: (id: string) => void;
  onSendMessage: (params: {
    text: string;
    attachments: ChatAttachment[];
    editMessageId?: string;
    modelTier?: ModelTier;
    conversationTone?: 'friend' | 'coach';
  }) => Promise<ChatMessageItem | null>;
  onRegenerateLast: (modelTier?: ModelTier, conversationTone?: 'friend' | 'coach') => void;
  onStopStreaming: () => void;
  onUploadFile: (file: File) => Promise<ChatAttachment | null>;
  onUpdatePreferences: (patch: {
    preferredLanguage?: ExplanationLanguage;
    explanationDepth?: ExplanationDepth;
  }) => void;
  onSaveMessageAsNote: (msg: ChatMessageItem, bookmarked?: boolean) => void;
  onRefreshAiStatus: () => void;
  onVerifyLiveAi?: () => Promise<AIProviderStatus | null>;
}

const DEFAULT_FALLBACK_CHIPS = [
  'Chal aage badhte hain',
  'Ek real-life example de yaar',
  'Mera ek chhota test le',
];

function parseMessageContent(rawContent: string): {
  cleanContent: string;
  followUps: string[];
  mcqOptions: string[];
} {
  if (!rawContent) {
    return { cleanContent: '', followUps: [], mcqOptions: [] };
  }

  let followUps: string[] = [];
  const completeMatch = rawContent.match(/<<<FOLLOWUPS:\s*(\[[\s\S]*?\])\s*>>>/);
  if (completeMatch?.[1]) {
    try {
      const parsed = JSON.parse(completeMatch[1]);
      if (Array.isArray(parsed)) {
        followUps = parsed
          .map((item) => String(item).trim())
          .filter((item) => item.length > 0 && item.length <= 72)
          .slice(0, 4);
      }
    } catch {
      followUps = [];
    }
  }

  // Strip complete or in-progress <<<FOLLOWUPS marker so raw tags never flash during streaming
  let cleanContent = rawContent
    .replace(/<<<FOLLOWUPS:[\s\S]*$/g, '')
    .replace(/<<<FOLLOWU[\s\S]*$/g, '')
    .replace(/<<<FOLL[\s\S]*$/g, '')
    .trimEnd();

  // Detect if Mitra posed a 4-option comprehension question with (A), (B), (C), (D)
  const hasA = /\(A\)|\bA\)/i.test(cleanContent);
  const hasB = /\(B\)|\bB\)/i.test(cleanContent);
  const hasC = /\(C\)|\bC\)/i.test(cleanContent);
  const hasD = /\(D\)|\bD\)/i.test(cleanContent);
  const mcqOptions = hasA && hasB && hasC && hasD ? ['A', 'B', 'C', 'D'] : [];

  return { cleanContent, followUps, mcqOptions };
}

function getDateBucketLabel(isoDate: string): 'Today' | 'Yesterday' | 'Previous 7 Days' | 'Earlier' {
  try {
    const d = new Date(isoDate);
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 86_400_000;
    const startOfWeek = startOfToday - 7 * 86_400_000;
    const ts = d.getTime();
    if (ts >= startOfToday) return 'Today';
    if (ts >= startOfYesterday) return 'Yesterday';
    if (ts >= startOfWeek) return 'Previous 7 Days';
    return 'Earlier';
  } catch {
    return 'Today';
  }
}

function formatDurationClock(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const res = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = res.indexOf(',');
      resolve(commaIdx >= 0 ? res.slice(commaIdx + 1) : res);
    };
    reader.onerror = () => reject(new Error('Could not read recorded audio.'));
    reader.readAsDataURL(blob);
  });
}

export const TutorChatWorkspace: React.FC<TutorChatWorkspaceProps> = ({
  conversations,
  activeConversationId,
  messages,
  isStreaming,
  streamingText,
  streamingModel,
  aiStatus,
  profile,
  uploadedDocs,
  initialPromptDraft,
  initialAttachmentDraft,
  onClearInitialDraft,
  onSelectConversation,
  onNewConversation,
  onRenameConversation,
  onToggleArchiveConversation,
  onDeleteConversation,
  onSendMessage,
  onRegenerateLast,
  onStopStreaming,
  onUploadFile,
  onUpdatePreferences,
  onSaveMessageAsNote,
  onRefreshAiStatus,
  onVerifyLiveAi,
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showSidebarSearch, setShowSidebarSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');

  // Model & Tutor Style Popovers
  const [modelTier, setModelTier] = useState<ModelTier>('fast');
  const [conversationTone, setConversationTone] = useState<'friend' | 'coach'>('friend');
  const [showModelMenu, setShowModelMenu] = useState(false);
  const [showStyleMenu, setShowStyleMenu] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);

  // Composer & Inline Message Edit State
  const [inputText, setInputText] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([]);
  const [inlineEditId, setInlineEditId] = useState<string | null>(null);
  const [inlineEditDraft, setInlineEditDraft] = useState('');

  // Action Feedback State
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [savedNoteId, setSavedNoteId] = useState<string | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<Record<string, boolean>>({});
  const [isVerifyingAi, setIsVerifyingAi] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [localNotice, setLocalNotice] = useState<string | null>(null);

  // Smart Scroll Tracking
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const [isAtBottom, setIsAtBottom] = useState(true);

  // Audio Read-Aloud (TTS) & Microphone Dictation / Voice Tutor State
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [loadingTtsId, setLoadingTtsId] = useState<string | null>(null);
  const audioCacheRef = useRef<Map<string, string>>(new Map());
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);

  const [isRecordingMic, setIsRecordingMic] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [isTranscribingMic, setIsTranscribingMic] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  // Interactive Full-Stage Voice Tutor Mode
  const [voiceModeOpen, setVoiceModeOpen] = useState(false);
  const [voiceStatusText, setVoiceStatusText] = useState('Tap the microphone to talk with Mitra');
  const [lastVoiceTranscript, setLastVoiceTranscript] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Auto-resize composer textarea smoothly like ChatGPT
  const syncTextareaHeight = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    const nextHeight = Math.min(el.scrollHeight, 180);
    el.style.height = `${Math.max(nextHeight, 44)}px`;
  }, []);

  useEffect(() => {
    syncTextareaHeight();
  }, [inputText, syncTextareaHeight, messages.length]);

  // Hydrate external cross-tab prompt drafts (e.g. from Dashboard / Practice / Study Vault)
  useEffect(() => {
    if (initialPromptDraft || initialAttachmentDraft) {
      if (initialPromptDraft) {
        setInputText(initialPromptDraft);
      }
      if (initialAttachmentDraft) {
        setPendingAttachments((prev) =>
          prev.some((p) => p.id === initialAttachmentDraft.id)
            ? prev
            : [...prev, initialAttachmentDraft]
        );
      }
      onClearInitialDraft();
      setTimeout(() => textareaRef.current?.focus(), 40);
    }
  }, [initialPromptDraft, initialAttachmentDraft, onClearInitialDraft]);

  // Keyboard shortcut: press '/' to focus composer when not typing in an input
  useEffect(() => {
    const onGlobalKey = (e: KeyboardEvent) => {
      if (
        e.key === '/' &&
        !e.metaKey &&
        !e.ctrlKey &&
        !e.altKey &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        textareaRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onGlobalKey);
    return () => window.removeEventListener('keydown', onGlobalKey);
  }, []);

  // Scroll tracking so streaming never hijacks reading when scrolled up
  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const distanceFromBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight;
    setIsAtBottom(distanceFromBottom < 96);
  };

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
    setIsAtBottom(true);
  }, []);

  useEffect(() => {
    if (isAtBottom) {
      messagesEndRef.current?.scrollIntoView({ behavior: isStreaming ? 'auto' : 'smooth' });
    }
  }, [messages.length, streamingText, isAtBottom, isStreaming]);

  // Clean up audio & mic on unmount
  useEffect(() => {
    return () => {
      activeAudioRef.current?.pause();
      if (recordingTimerRef.current) window.clearInterval(recordingTimerRef.current);
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const groupedConversations = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = conversations.filter((c) => {
      if (Boolean(c.archived) !== showArchived) return false;
      if (!q) return true;
      return (
        c.title.toLowerCase().includes(q) ||
        c.lastMessagePreview.toLowerCase().includes(q) ||
        c.subjectTag.toLowerCase().includes(q)
      );
    });

    if (showArchived) {
      return [{ label: 'Archived', items: list }];
    }

    const buckets: Record<string, ConversationThread[]> = {
      Today: [],
      Yesterday: [],
      'Previous 7 Days': [],
      Earlier: [],
    };
    for (const conv of list) {
      buckets[getDateBucketLabel(conv.updatedAt)].push(conv);
    }

    return Object.entries(buckets)
      .filter(([, items]) => items.length > 0)
      .map(([label, items]) => ({ label, items }));
  }, [conversations, searchQuery, showArchived]);

  const stopAudioPlayback = useCallback(() => {
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current.currentTime = 0;
      activeAudioRef.current = null;
    }
    setSpeakingMessageId(null);
  }, []);

  const playMessageSpeech = useCallback(
    async (msgId: string, rawText: string) => {
      if (speakingMessageId === msgId) {
        stopAudioPlayback();
        return;
      }

      stopAudioPlayback();
      const { cleanContent } = parseMessageContent(rawText);
      if (!cleanContent.trim()) return;

      setLoadingTtsId(msgId);
      setLocalNotice(null);

      try {
        let dataUrl = audioCacheRef.current.get(msgId);
        if (!dataUrl) {
          const res = await apiFetch('/api/ai/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: cleanContent }),
          });
          const data = await res.json();
          if (!res.ok || !data.audioBase64) {
            throw new Error(data.error || 'Could not synthesize tutor voice.');
          }
          dataUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
          audioCacheRef.current.set(msgId, dataUrl);
        }

        const audio = new Audio(dataUrl);
        activeAudioRef.current = audio;
        setSpeakingMessageId(msgId);
        setVoiceStatusText('Mitra is speaking...');

        audio.onended = () => {
          setSpeakingMessageId(null);
          activeAudioRef.current = null;
          setVoiceStatusText('Tap the microphone to reply');
        };
        audio.onerror = () => {
          setSpeakingMessageId(null);
          activeAudioRef.current = null;
          setVoiceStatusText('Tap the microphone to talk with Mitra');
        };

        await audio.play();
      } catch (err) {
        setLocalNotice(err instanceof Error ? err.message : 'Audio playback unavailable.');
        setVoiceStatusText('Tap the microphone to talk with Mitra');
      } finally {
        setLoadingTtsId(null);
      }
    },
    [speakingMessageId, stopAudioPlayback]
  );

  const startMicRecording = async (autoSendForVoiceTutor: boolean) => {
    setLocalNotice(null);
    stopAudioPlayback();

    if (!navigator.mediaDevices?.getUserMedia) {
      setLocalNotice('Microphone recording is not supported in this browser.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      recordedChunksRef.current = [];

      const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : '';

      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          recordedChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        const mimeType = recorder.mimeType || 'audio/webm';
        stream.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;

        if (recordedChunksRef.current.length === 0) {
          setIsRecordingMic(false);
          return;
        }

        const audioBlob = new Blob(recordedChunksRef.current, { type: mimeType });
        recordedChunksRef.current = [];
        setIsRecordingMic(false);
        setIsTranscribingMic(true);
        setVoiceStatusText('Transcribing your question...');

        try {
          const audioBase64 = await blobToBase64(audioBlob);
          const res = await apiFetch('/api/ai/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64,
              mimeType: mimeType.split(';')[0] || 'audio/webm',
            }),
          });
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.error || 'Voice transcription failed.');
          }
          const spoken = String(data.text || '').trim();
          if (!spoken) {
            setVoiceStatusText('Could not hear speech clearly — tap mic to try again');
            return;
          }

          if (autoSendForVoiceTutor) {
            setLastVoiceTranscript(spoken);
            setVoiceStatusText('Mitra is thinking...');
            const assistantReply = await onSendMessage({
              text: spoken,
              attachments: [],
              modelTier: 'fast',
              conversationTone,
            });
            if (assistantReply && assistantReply.content) {
              await playMessageSpeech(assistantReply.id, assistantReply.content);
            } else {
              setVoiceStatusText('Tap the microphone to reply');
            }
          } else {
            setInputText((prev) => (prev.trim() ? `${prev.trim()} ${spoken}` : spoken));
            setTimeout(() => textareaRef.current?.focus(), 30);
          }
        } catch (err) {
          setLocalNotice(err instanceof Error ? err.message : 'Transcription error.');
          setVoiceStatusText('Tap the microphone to try again');
        } finally {
          setIsTranscribingMic(false);
        }
      };

      recorder.start();
      setIsRecordingMic(true);
      setRecordingSeconds(0);
      setVoiceStatusText('Listening... tap Done when you finish speaking');

      if (recordingTimerRef.current) window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setLocalNotice(
        msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('notallowed')
          ? 'Microphone permission was blocked. Allow microphone access in your browser to use voice input.'
          : `Could not access microphone: ${msg}`
      );
    }
  };

  const finishMicRecording = () => {
    if (recordingTimerRef.current) {
      window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  const cancelMicRecording = () => {
    if (recordingTimerRef.current) {
      window.clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    recordedChunksRef.current = [];
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.onstop = () => {
        mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
        mediaStreamRef.current = null;
      };
      mediaRecorderRef.current.stop();
    } else {
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setIsRecordingMic(false);
    setRecordingSeconds(0);
    setVoiceStatusText('Tap the microphone to talk with Mitra');
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || isStreaming) return;

    setShowAttachMenu(false);
    setIsAtBottom(true);
    void onSendMessage({
      text: trimmed,
      attachments: pendingAttachments,
      modelTier,
      conversationTone,
    });
    setInputText('');
    setPendingAttachments([]);
  };

  const handleSubmitInlineEdit = (msg: ChatMessageItem) => {
    const trimmed = inlineEditDraft.trim();
    if (!trimmed || isStreaming) return;
    setInlineEditId(null);
    setInlineEditDraft('');
    setIsAtBottom(true);
    void onSendMessage({
      text: trimmed,
      attachments: msg.attachments || [],
      editMessageId: msg.id,
      modelTier,
      conversationTone,
    });
  };

  const handleQuickPromptSend = (promptText: string, attachments: ChatAttachment[] = []) => {
    if (isStreaming) return;
    setIsAtBottom(true);
    void onSendMessage({
      text: promptText,
      attachments,
      modelTier,
      conversationTone,
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleCopy = async (id: string, rawText: string) => {
    try {
      const { cleanContent } = parseMessageContent(rawText);
      await navigator.clipboard.writeText(cleanContent);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1800);
    } catch {
      // Clipboard fallback ignored safely
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLocalNotice(null);
    setIsUploading(true);
    setShowAttachMenu(false);
    try {
      const uploaded = await onUploadFile(file);
      if (uploaded) {
        setPendingAttachments((prev) => [...prev, uploaded]);
        textareaRef.current?.focus();
      } else {
        setLocalNotice('Could not attach document. Ensure the file is under 18 MB.');
      }
    } catch (err) {
      setLocalNotice(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const attachPresetPaper = (presetId: 'cmat_2025_slot_1' | 'cmat_2025_slot_2') => {
    const label =
      presetId === 'cmat_2025_slot_1'
        ? 'NTA CMAT 2025 Slot 1 Paper.pdf'
        : 'NTA CMAT 2025 Slot 2 Paper.pdf';
    const item: ChatAttachment = {
      id: `preset_${presetId}`,
      name: label,
      mimeType: 'application/pdf',
      presetPaperId: presetId,
    };
    setPendingAttachments((prev) =>
      prev.some((p) => p.presetPaperId === presetId) ? prev : [...prev, item]
    );
    setShowAttachMenu(false);
    textareaRef.current?.focus();
  };

  const isEmptyThread = messages.length === 0 && !isStreaming;
  const parsedStreaming = useMemo(
    () => parseMessageContent(streamingText),
    [streamingText]
  );

  // Reusable ChatGPT-style Composer Box (rendered centered on empty chat, or docked at bottom)
  const renderComposerCard = (centeredMode: boolean) => (
    <div className="w-full max-w-3xl mx-auto">
      {localNotice && (
        <div className="mb-2.5 flex items-center justify-between gap-3 px-3.5 py-2 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
          <span>{localNotice}</span>
          <button
            type="button"
            onClick={() => setLocalNotice(null)}
            className="font-medium hover:underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div
        className={`relative rounded-3xl border border-slate-300 bg-white transition-colors focus-within:border-slate-400 ${
          centeredMode ? 'shadow-sm' : 'shadow-xs'
        }`}
      >
        {/* Attached Files Row Inside Composer */}
        {pendingAttachments.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 px-4 pt-3">
            {pendingAttachments.map((att) => (
              <div
                key={att.id}
                className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-xl text-xs text-slate-800"
              >
                <FileText className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                <span className="max-w-52 truncate font-medium">{att.name}</span>
                <button
                  type="button"
                  onClick={() =>
                    setPendingAttachments((prev) => prev.filter((p) => p.id !== att.id))
                  }
                  className="text-slate-500 hover:text-slate-900 cursor-pointer"
                  aria-label={`Remove ${att.name}`}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Attachment Menu Popover */}
        {showAttachMenu && (
          <div className="absolute left-3 bottom-14 z-20 w-72 p-2 bg-white border border-slate-200 rounded-2xl shadow-lg space-y-1">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs font-medium text-slate-800 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              <Paperclip className="w-4 h-4 text-slate-600 shrink-0" />
              <span>Upload PDF, notes, or image</span>
            </button>
            <div className="my-1 border-t border-slate-100" />
            <div className="px-3 py-1 text-[11px] text-slate-400">
              Bundled Official CMAT Papers
            </div>
            <button
              type="button"
              onClick={() => attachPresetPaper('cmat_2025_slot_1')}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs font-medium text-slate-800 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              <FileText className="w-4 h-4 text-blue-700 shrink-0" />
              <span className="truncate">NTA CMAT 2025 Slot 1 PDF</span>
            </button>
            <button
              type="button"
              onClick={() => attachPresetPaper('cmat_2025_slot_2')}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-left text-xs font-medium text-slate-800 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              <FileText className="w-4 h-4 text-blue-700 shrink-0" />
              <span className="truncate">NTA CMAT 2025 Slot 2 PDF</span>
            </button>
            {uploadedDocs.length > 0 && (
              <>
                <div className="my-1 border-t border-slate-100" />
                <div className="px-3 py-1 text-[11px] text-slate-400">Recent Uploads</div>
                {uploadedDocs.slice(0, 4).map((docItem) => (
                  <button
                    key={docItem.id}
                    type="button"
                    onClick={() => {
                      setPendingAttachments((prev) =>
                        prev.some((p) => p.id === docItem.id) ? prev : [...prev, docItem]
                      );
                      setShowAttachMenu(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span className="truncate">{docItem.name}</span>
                  </button>
                ))}
              </>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.txt,.md,.csv,.json,image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Auto-growing Textarea or Active Microphone Recording Strip */}
          {isRecordingMic ? (
            <div className="flex items-center justify-between gap-3 px-4 py-3.5">
              <div className="flex items-center gap-2.5 text-sm font-medium text-slate-900 tabular-nums">
                <Mic className="w-4 h-4 text-red-600 shrink-0" />
                <span>Listening ({formatDurationClock(recordingSeconds)})</span>
                <span className="text-xs font-normal text-slate-500">
                  Speak in Hinglish, Hindi, or English...
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={cancelMicRecording}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-full cursor-pointer whitespace-nowrap"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={finishMicRecording}
                  className="px-3.5 py-1.5 text-xs font-medium bg-slate-900 text-white rounded-full hover:bg-slate-800 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
                >
                  <Check className="w-3.5 h-3.5" />
                  Done
                </button>
              </div>
            </div>
          ) : (
            <textarea
              ref={textareaRef}
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                isUploading
                  ? 'Uploading attachment...'
                  : isTranscribingMic
                  ? 'Transcribing your voice...'
                  : 'Talk to Mitra like a friend — ask a doubt, vent about prep, or say "chal shuru karte hain"...'
              }
              className="w-full resize-none bg-transparent px-4 pt-3.5 pb-2 text-[15px] leading-relaxed text-slate-900 placeholder:text-slate-400 focus:outline-none max-h-44 overflow-y-auto"
            />
          )}

          {/* Composer Bottom Action Bar */}
          <div className="flex items-center justify-between gap-2 px-3 pb-2.5 pt-1">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowAttachMenu((v) => !v)}
                disabled={isStreaming || isUploading}
                className="w-9 h-9 inline-flex items-center justify-center rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-40"
                title="Attach PDF, image, or CMAT paper"
                aria-label="Attach PDF, image, or CMAT paper"
              >
                <Plus className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={() =>
                  setModelTier((prev) => (prev === 'fast' ? 'thinking' : 'fast'))
                }
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer border ${
                  modelTier === 'thinking'
                    ? 'bg-blue-50 text-blue-800 border-blue-200'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900'
                }`}
                title="Toggle deep step-by-step math & PYQ reasoning"
              >
                {modelTier === 'thinking' ? 'Deep Reasoning On' : 'Think Step-by-Step'}
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              {!isRecordingMic && (
                <button
                  type="button"
                  onClick={() => void startMicRecording(false)}
                  disabled={isStreaming || isTranscribingMic}
                  className="w-9 h-9 inline-flex items-center justify-center rounded-full text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-40"
                  title="Dictate with microphone"
                  aria-label="Dictate with microphone"
                >
                  {isTranscribingMic ? (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-700" />
                  ) : (
                    <Mic className="w-4 h-4" />
                  )}
                </button>
              )}

              {isStreaming ? (
                <button
                  type="button"
                  onClick={onStopStreaming}
                  className="w-9 h-9 inline-flex items-center justify-center rounded-full bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Stop generating"
                  aria-label="Stop generating"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                </button>
              ) : inputText.trim().length > 0 ? (
                <button
                  type="submit"
                  disabled={isUploading || isTranscribingMic}
                  className="w-9 h-9 inline-flex items-center justify-center rounded-full bg-slate-900 text-white hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-40"
                  title="Send message"
                  aria-label="Send message"
                >
                  <ArrowUp className="w-4 h-4 stroke-[2.4]" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setVoiceModeOpen(true);
                    setVoiceStatusText('Tap the microphone below to speak with Mitra');
                  }}
                  className="h-9 px-3 inline-flex items-center gap-1.5 rounded-full bg-slate-900 text-white text-xs font-medium hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  title="Start interactive voice conversation"
                  aria-label="Start interactive voice conversation"
                >
                  <Headphones className="w-3.5 h-3.5" />
                  <span>Voice</span>
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="relative flex h-[calc(100vh-3.75rem)] bg-white overflow-hidden">
      {/* Left Collapsible Conversation History Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-[268px] border-r border-slate-200' : 'w-0 overflow-hidden'
        } bg-slate-50/90 flex flex-col shrink-0 transition-opacity duration-150`}
        aria-label="Conversation history"
      >
        <div className="p-3 space-y-2">
          <div className="flex items-center justify-between gap-1">
            <button
              type="button"
              onClick={() => setSidebarOpen(false)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 rounded-lg transition-colors cursor-pointer"
              title="Close sidebar"
              aria-label="Close sidebar"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  setShowSidebarSearch((v) => !v);
                  if (showSidebarSearch) setSearchQuery('');
                }}
                className={`p-2 rounded-lg transition-colors cursor-pointer ${
                  showSidebarSearch
                    ? 'bg-slate-200 text-slate-900'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                }`}
                title="Search chats"
                aria-label="Search chats"
              >
                <Search className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onNewConversation}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 rounded-lg transition-colors cursor-pointer"
                title="New chat"
                aria-label="New chat"
              >
                <SquarePen className="w-4 h-4" />
              </button>
            </div>
          </div>

          {showSidebarSearch && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
                placeholder="Search conversations..."
                className="w-full pl-8 pr-7 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-slate-400"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Date-Grouped Conversation List */}
        <div className="flex-1 overflow-y-auto px-2 pb-3 space-y-4">
          {groupedConversations.length === 0 ? (
            <div className="px-3 py-10 text-center text-xs text-slate-500">
              {searchQuery
                ? 'No matching chats.'
                : showArchived
                ? 'No archived chats.'
                : 'No chats yet.'}
            </div>
          ) : (
            groupedConversations.map((group) => (
              <div key={group.label} className="space-y-0.5">
                <div className="px-2.5 py-1 text-[11px] font-medium text-slate-400">
                  {group.label}
                </div>
                {group.items.map((conv) => {
                  const isSelected = conv.id === activeConversationId;
                  const isRenaming = renamingId === conv.id;

                  return (
                    <div
                      key={conv.id}
                      className={`group rounded-lg px-2.5 py-2 transition-colors ${
                        isSelected
                          ? 'bg-slate-200/80 text-slate-900'
                          : 'text-slate-700 hover:bg-slate-200/50'
                      }`}
                    >
                      {isRenaming ? (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (renameDraft.trim()) {
                              onRenameConversation(conv.id, renameDraft.trim());
                            }
                            setRenamingId(null);
                          }}
                          className="flex items-center gap-1"
                        >
                          <input
                            type="text"
                            value={renameDraft}
                            onChange={(e) => setRenameDraft(e.target.value)}
                            autoFocus
                            className="flex-1 min-w-0 px-2 py-0.5 text-xs bg-white border border-slate-400 rounded focus:outline-none"
                          />
                          <button
                            type="submit"
                            className="p-1 text-emerald-700 hover:bg-emerald-50 rounded cursor-pointer"
                            title="Save"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setRenamingId(null)}
                            className="p-1 text-slate-500 hover:bg-slate-100 rounded cursor-pointer"
                            title="Cancel"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </form>
                      ) : (
                        <div
                          role="button"
                          tabIndex={0}
                          onClick={() => onSelectConversation(conv.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              onSelectConversation(conv.id);
                            }
                          }}
                          className="flex items-center justify-between gap-2 cursor-pointer"
                        >
                          <span className="text-[13px] truncate flex-1">
                            {conv.title}
                          </span>
                          <div className="hidden group-hover:flex items-center gap-0.5 shrink-0">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setRenamingId(conv.id);
                                setRenameDraft(conv.title);
                              }}
                              className="p-1 text-slate-500 hover:text-slate-900 rounded cursor-pointer"
                              title="Rename"
                            >
                              <Edit3 className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onToggleArchiveConversation(conv.id, !conv.archived);
                              }}
                              className="p-1 text-slate-500 hover:text-slate-900 rounded cursor-pointer"
                              title={conv.archived ? 'Unarchive' : 'Archive'}
                            >
                              {conv.archived ? (
                                <ArchiveRestore className="w-3 h-3" />
                              ) : (
                                <Archive className="w-3 h-3" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteConversation(conv.id);
                              }}
                              className="p-1 text-slate-500 hover:text-red-600 rounded cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))
          )}
        </div>

        {/* Sidebar Bottom Archive Switch & ZIP Export */}
        <div className="p-2.5 border-t border-slate-200 space-y-2 text-xs text-slate-500">
          <div className="flex items-center justify-between">
            <span>Day {profile.currentDay} · {profile.currentSubject.split(' ')[0]}</span>
            <button
              type="button"
              onClick={() => setShowArchived((v) => !v)}
              className="hover:text-slate-900 transition-colors cursor-pointer whitespace-nowrap"
            >
              {showArchived ? 'View Active' : 'Archived'}
            </button>
          </div>
          <a
            href="/api/workspace/download-zip"
            download="mitra-ai-tutor-source.zip"
            className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-md text-slate-700 hover:bg-slate-100 hover:text-slate-900 transition-colors inline-flex items-center justify-center gap-1.5 font-medium"
          >
            <Download className="w-3.5 h-3.5" />
            Download Source ZIP
          </a>
        </div>
      </aside>

      {/* Main Conversational Canvas */}
      <section className="relative flex-1 flex flex-col min-w-0 bg-white">
        {/* Minimal ChatGPT-Style Stage Top Bar */}
        <div className="h-12 flex items-center justify-between gap-4 px-4 sm:px-6 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-1.5 min-w-0">
            {!sidebarOpen && (
              <>
                <button
                  type="button"
                  onClick={() => setSidebarOpen(true)}
                  className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                  title="Open sidebar"
                  aria-label="Open sidebar"
                >
                  <PanelLeftOpen className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onNewConversation}
                  className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                  title="New chat"
                  aria-label="New chat"
                >
                  <SquarePen className="w-4 h-4" />
                </button>
              </>
            )}

            {/* Model Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowModelMenu((v) => !v);
                  setShowStyleMenu(false);
                }}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-sm font-semibold text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{modelTier === 'thinking' ? 'Mitra Thinking' : 'Mitra Fast'}</span>
                <ChevronDown className="w-4 h-4 text-slate-500" />
              </button>

              {showModelMenu && (
                <div className="absolute left-0 top-11 z-30 w-80 p-2 bg-white border border-slate-200 rounded-2xl shadow-lg space-y-1">
                  <button
                    type="button"
                    onClick={() => {
                      setModelTier('fast');
                      setShowModelMenu(false);
                    }}
                    className="w-full flex items-start justify-between gap-3 p-2.5 rounded-xl hover:bg-slate-50 text-left cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-900">
                        Mitra Fast
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Instant back-and-forth tutoring & 1-question interactive drills
                      </div>
                    </div>
                    {modelTier === 'fast' && (
                      <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setModelTier('thinking');
                      setShowModelMenu(false);
                    }}
                    className="w-full flex items-start justify-between gap-3 p-2.5 rounded-xl hover:bg-slate-50 text-left cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-900">
                        Mitra Thinking
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Deeper step-by-step Quant, DI & CMAT PYQ derivations
                      </div>
                    </div>
                    {modelTier === 'thinking' && (
                      <Check className="w-4 h-4 text-slate-900 shrink-0 mt-0.5" />
                    )}
                  </button>

                  <div className="pt-2 mt-1 border-t border-slate-100 px-2.5 pb-1.5 space-y-2">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">AI Connection:</span>
                      <span
                        className={
                          aiStatus?.liveAvailable
                            ? 'font-semibold text-emerald-700'
                            : 'font-semibold text-amber-700'
                        }
                      >
                        {aiStatus?.liveAvailable
                          ? `Live AI (${aiStatus.activeModel})`
                          : 'Offline Fallback'}
                      </span>
                    </div>
                    {onVerifyLiveAi && (
                      <button
                        type="button"
                        disabled={isVerifyingAi}
                        onClick={async () => {
                          setIsVerifyingAi(true);
                          try {
                            await onVerifyLiveAi();
                          } finally {
                            setIsVerifyingAi(false);
                          }
                        }}
                        className="w-full py-1.5 px-2.5 text-xs font-medium text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3 h-3 ${isVerifyingAi ? 'animate-spin' : ''}`} />
                        {isVerifyingAi ? 'Probing Live Model...' : 'Verify Live AI Access'}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Compact Controls: Language/Depth Popover & Voice Mode */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowStyleMenu((v) => !v);
                  setShowModelMenu(false);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>{conversationTone === 'friend' ? 'Friend Vibe' : 'Coach Vibe'}</span>
                <span aria-hidden="true">·</span>
                <span className="capitalize">{profile.preferredLanguage}</span>
              </button>

              {showStyleMenu && (
                <div className="absolute right-0 top-10 z-30 w-68 p-3 bg-white border border-slate-200 rounded-2xl shadow-lg space-y-3">
                  <div>
                    <div className="text-[11px] font-medium text-slate-500 mb-1.5">
                      Talking Style (Vibe)
                    </div>
                    <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-100 rounded-lg">
                      <button
                        type="button"
                        onClick={() => setConversationTone('friend')}
                        className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                          conversationTone === 'friend'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Best Friend
                      </button>
                      <button
                        type="button"
                        onClick={() => setConversationTone('coach')}
                        className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                          conversationTone === 'coach'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Exam Coach
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="text-[11px] font-medium text-slate-500 mb-1.5">
                      Explanation Language
                    </div>
                    <div className="grid grid-cols-3 gap-1 p-0.5 bg-slate-100 rounded-lg">
                      {(['hinglish', 'english', 'hindi'] as ExplanationLanguage[]).map(
                        (lang) => (
                          <button
                            key={lang}
                            type="button"
                            onClick={() =>
                              onUpdatePreferences({ preferredLanguage: lang })
                            }
                            className={`py-1 text-xs font-medium rounded-md capitalize transition-colors cursor-pointer ${
                              profile.preferredLanguage === lang
                                ? 'bg-white text-slate-900 shadow-2xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {lang}
                          </button>
                        )
                      )}
                    </div>
                  </div>

                  <div>
                    <div className="text-[11px] font-medium text-slate-500 mb-1.5">
                      Pacing & Detail
                    </div>
                    <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-100 rounded-lg">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdatePreferences({ explanationDepth: 'step_by_step' })
                        }
                        className={`py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                          profile.explanationDepth === 'step_by_step'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Easy Steps
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdatePreferences({ explanationDepth: 'concise' })
                        }
                        className={`py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                          profile.explanationDepth === 'concise'
                            ? 'bg-white text-slate-900 shadow-2xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Short & Chatty
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Offline Fallback Banner (Only displayed if Live AI is actually unavailable) */}
        {aiStatus && !aiStatus.liveAvailable && (
          <div className="px-6 py-2 bg-amber-50 border-y border-amber-200 text-xs text-amber-900 flex items-center justify-between gap-4">
            <span>
              <strong>Offline Tutor Fallback Active:</strong> {aiStatus.diagnosticMessage}
            </span>
            <button
              type="button"
              onClick={() => {
                if (onVerifyLiveAi) {
                  void onVerifyLiveAi();
                } else {
                  onRefreshAiStatus();
                }
              }}
              className="px-2.5 py-1 bg-white border border-amber-300 rounded-md text-xs font-medium hover:bg-amber-100 inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              Verify & Reconnect Live AI
            </button>
          </div>
        )}

        {/* EMPTY CONVERSATION STATE: Centered Greeting + Composer + Starter Prompts (Like ChatGPT) */}
        {isEmptyThread ? (
          <div className="flex-1 overflow-y-auto px-4 sm:px-8 flex flex-col items-center justify-center">
            <div className="w-full max-w-3xl mx-auto py-8 space-y-7">
              <div className="text-center space-y-2">
                <h1 className="text-2xl sm:text-3xl font-semibold text-slate-900 tracking-tight text-balance">
                  Hey yaar! Kya chal raha hai aaj?
                </h1>
                <p className="text-sm text-slate-500">
                  Talk to Mitra just like a friend — clear any doubt from zero, practice Day {profile.currentDay} together, or talk by voice
                </p>
              </div>

              {renderComposerCard(true)}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {[
                  {
                    title: 'Chal Ratio & Proportion continue karte hain',
                    subtitle: 'Dost ki tarah easy example se samajhte hain test se pehle',
                    prompt:
                      'Yaar chal Ratio & Proportion wahan se continue karte hain jahan chhoda tha — ekdum dost ki tarah real-life example se samjha aur ek warm-up sawal puch!',
                  },
                  {
                    title: 'Meri 2 Number Series galtiyan samjha de',
                    subtitle: '69, 55, 26, 13, 5 aur n³ + 1 mein kahan slip hua?',
                    prompt:
                      'Bhai meri Advanced Number Series wali 2 galtiyan (Error Log wali) aaram se ek-ek karke samjha na, kahan galti hui thi?',
                  },
                  {
                    title: 'CMAT 2025 Slot 1 Pie Chart saath mein solve karein',
                    subtitle: 'Official Slot 1 PDF khol ke Q.1–Q.3 ka shortcut dekhte hain',
                    prompt:
                      'Yaar ye attached NTA CMAT 2025 Slot 1 paper ka Q.1 se Q.3 (Pie Chart wala set) saath mein solve karte hain, easy trick batana!',
                    attachPreset: 'cmat_2025_slot_1' as const,
                  },
                  {
                    title: 'Thoda chill 5-minute rapid quiz le le',
                    subtitle: 'Ek-ek sawal puchna, main jawab dunga!',
                    prompt:
                      'Chal mera ek chill rapid-fire quiz le! Ek baar mein sirf 1 chhota sawal puchna aur mere jawab ka wait karna.',
                  },
                ].map((starter) => (
                  <button
                    key={starter.title}
                    type="button"
                    onClick={() => {
                      const att: ChatAttachment[] = starter.attachPreset
                        ? [
                            {
                              id: `preset_${starter.attachPreset}`,
                              name: 'NTA CMAT 2025 Slot 1 Paper.pdf',
                              mimeType: 'application/pdf',
                              presetPaperId: starter.attachPreset,
                            },
                          ]
                        : [];
                      handleQuickPromptSend(starter.prompt, att);
                    }}
                    className="text-left px-4 py-3 rounded-2xl border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-colors cursor-pointer"
                  >
                    <div className="text-[13px] font-semibold text-slate-800">
                      {starter.title}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                      {starter.subtitle}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* POPULATED CONVERSATION STREAM */}
            <div
              ref={scrollContainerRef}
              onScroll={handleScroll}
              onClick={() => {
                if (showModelMenu) setShowModelMenu(false);
                if (showStyleMenu) setShowStyleMenu(false);
                if (showAttachMenu) setShowAttachMenu(false);
              }}
              className="flex-1 overflow-y-auto px-4 sm:px-8 pt-4 pb-8"
            >
              <div className="max-w-3xl mx-auto space-y-8">
                {messages.map((msg, idx) => {
                  const isUser = msg.role === 'user';
                  const isLastMessage = idx === messages.length - 1;
                  const isLastAssistant = !isUser && isLastMessage && !isStreaming;
                  const parsed = isUser
                    ? { cleanContent: msg.content, followUps: [], mcqOptions: [] }
                    : parseMessageContent(msg.content);

                  if (isUser) {
                    const isEditingThis = inlineEditId === msg.id;

                    return (
                      <div key={msg.id} className="group flex flex-col items-end">
                        {isEditingThis ? (
                          <div className="w-full sm:max-w-[85%] rounded-2xl border border-slate-300 bg-slate-50 p-3 space-y-2.5">
                            <textarea
                              value={inlineEditDraft}
                              onChange={(e) => setInlineEditDraft(e.target.value)}
                              rows={3}
                              autoFocus
                              className="w-full resize-none bg-transparent text-[15px] text-slate-900 focus:outline-none leading-relaxed"
                            />
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setInlineEditId(null);
                                  setInlineEditDraft('');
                                }}
                                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-full hover:bg-slate-100 cursor-pointer"
                              >
                                Cancel
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSubmitInlineEdit(msg)}
                                disabled={!inlineEditDraft.trim()}
                                className="px-3.5 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-full hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
                              >
                                Send
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            {msg.attachmentName && msg.attachmentName !== 'none' && (
                              <div className="mb-1.5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 text-xs text-slate-700">
                                <FileText className="w-3.5 h-3.5 text-blue-700 shrink-0" />
                                <span className="max-w-60 truncate">{msg.attachmentName}</span>
                              </div>
                            )}
                            <div className="max-w-[85%] sm:max-w-[78%] rounded-3xl bg-slate-100 text-slate-900 px-4 py-2.5 text-[15px] whitespace-pre-wrap leading-relaxed">
                              {msg.content}
                            </div>
                            <div className="mt-1 flex items-center gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                              <button
                                type="button"
                                onClick={() => handleCopy(msg.id, msg.content)}
                                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
                                title="Copy message"
                                aria-label="Copy message"
                              >
                                {copiedId === msg.id ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                              {!isStreaming && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setInlineEditId(msg.id);
                                    setInlineEditDraft(msg.content);
                                  }}
                                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
                                  title="Edit message"
                                  aria-label="Edit message"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    );
                  }

                  // Assistant Turn — Open Editorial Canvas like ChatGPT
                  const chipsToShow =
                    parsed.followUps.length > 0 ? parsed.followUps : DEFAULT_FALLBACK_CHIPS;

                  return (
                    <div key={msg.id} className="group flex items-start gap-3.5">
                      <div
                        className="w-7 h-7 rounded-full border border-slate-200 bg-slate-900 text-white text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5 select-none"
                        aria-hidden="true"
                      >
                        M
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="mb-1.5 flex flex-wrap items-center gap-2 text-[11px] text-slate-400 tabular-nums">
                          {msg.sourceMode === 'offline' ? (
                            <span className="font-semibold text-amber-700">
                              Offline Tutor Fallback (Structured CMAT Module — Not Live AI)
                            </span>
                          ) : (
                            <span className="text-emerald-700 font-medium">
                              Live AI · {msg.modelUsed}
                            </span>
                          )}
                          <span aria-hidden="true">·</span>
                          <span>
                            {new Date(msg.createdAt).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>

                        <MarkdownRenderer content={parsed.cleanContent} />

                        {msg.sourceMode === 'offline' && (
                          <div className="mt-3 p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex flex-wrap items-center justify-between gap-3">
                            <span>
                              {msg.errorReason
                                ? `Live AI paused (${msg.errorReason}). Showing structured offline CMAT module.`
                                : 'Generated by Mitra Offline Fallback module while Live AI was unavailable.'}
                            </span>
                            <button
                              type="button"
                              onClick={() => onRegenerateLast(modelTier, conversationTone)}
                              className="px-2.5 py-1 bg-white border border-amber-300 rounded-lg font-medium hover:bg-amber-100 whitespace-nowrap shrink-0 cursor-pointer"
                            >
                              Retry with Live AI
                            </button>
                          </div>
                        )}

                        {/* Subtle ChatGPT-Style Action Bar Under Assistant Response */}
                        <div className="mt-2 flex flex-wrap items-center gap-1 text-slate-400">
                          <button
                            type="button"
                            onClick={() => handleCopy(msg.id, parsed.cleanContent)}
                            className="p-1.5 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Copy response"
                            aria-label="Copy response"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => void playMessageSpeech(msg.id, parsed.cleanContent)}
                            disabled={loadingTtsId === msg.id}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              speakingMessageId === msg.id
                                ? 'text-blue-700 bg-blue-50'
                                : 'hover:text-slate-800 hover:bg-slate-100'
                            }`}
                            title={
                              speakingMessageId === msg.id ? 'Stop reading aloud' : 'Read aloud'
                            }
                            aria-label={
                              speakingMessageId === msg.id ? 'Stop reading aloud' : 'Read aloud'
                            }
                          >
                            {loadingTtsId === msg.id ? (
                              <Loader2 className="w-4 h-4 animate-spin text-blue-700" />
                            ) : speakingMessageId === msg.id ? (
                              <VolumeX className="w-4 h-4" />
                            ) : (
                              <Volume2 className="w-4 h-4" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onSaveMessageAsNote(
                                {
                                  ...msg,
                                  content: parsed.cleanContent,
                                },
                                false
                              );
                              setSavedNoteId(msg.id);
                              setTimeout(() => setSavedNoteId(null), 2000);
                            }}
                            className="p-1.5 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Save explanation to Study Notes"
                            aria-label="Save explanation to Study Notes"
                          >
                            {savedNoteId === msg.id ? (
                              <Check className="w-4 h-4 text-emerald-600" />
                            ) : (
                              <BookmarkPlus className="w-4 h-4" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onSaveMessageAsNote(
                                {
                                  ...msg,
                                  content: parsed.cleanContent,
                                },
                                true
                              );
                              setBookmarkedIds((prev) => ({ ...prev, [msg.id]: true }));
                            }}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              bookmarkedIds[msg.id]
                                ? 'text-amber-600 bg-amber-50'
                                : 'hover:text-slate-800 hover:bg-slate-100'
                            }`}
                            title="Bookmark important answer in Study Vault"
                            aria-label="Bookmark important answer in Study Vault"
                          >
                            <Bookmark
                              className={`w-4 h-4 ${bookmarkedIds[msg.id] ? 'fill-current' : ''}`}
                            />
                          </button>

                          {isLastAssistant && (
                            <>
                              <button
                                type="button"
                                onClick={() => onRegenerateLast(modelTier, conversationTone)}
                                className="p-1.5 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                                title="Regenerate response"
                                aria-label="Regenerate response"
                              >
                                <RotateCcw className="w-4 h-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  handleQuickPromptSend(
                                    'Continue from where you paused and give me 1 interactive practice question.'
                                  )
                                }
                                className="px-2 py-1 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                              >
                                Continue
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  handleQuickPromptSend(
                                    'Yaar thoda aur easy bhasha mein dost ki tarah real-life example deke samjha na!'
                                  )
                                }
                                className="px-2 py-1 text-xs text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                              >
                                Make it easier
                              </button>
                            </>
                          )}
                        </div>

                        {/* Interactive One-Click MCQ Answer Buttons (if Mitra asked an A/B/C/D question) */}
                        {isLastAssistant && parsed.mcqOptions.length === 4 && (
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            {parsed.mcqOptions.map((opt) => (
                              <button
                                key={opt}
                                type="button"
                                onClick={() =>
                                  handleQuickPromptSend(
                                    `My answer is Option (${opt}). Check if it's right and explain why!`
                                  )
                                }
                                className="px-3.5 py-1.5 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-full transition-colors cursor-pointer whitespace-nowrap"
                              >
                                Answer ({opt})
                              </button>
                            ))}
                            <button
                              type="button"
                              onClick={() =>
                                handleQuickPromptSend(
                                  'Give me a small hint first without revealing the final answer.'
                                )
                              }
                              className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-colors cursor-pointer whitespace-nowrap"
                            >
                              Give me a hint
                            </button>
                          </div>
                        )}

                        {/* Dynamic Contextual Follow-Up Replies Tailored to This Turn */}
                        {isLastAssistant && (
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            {chipsToShow.map((chipText) => (
                              <button
                                key={chipText}
                                type="button"
                                onClick={() => handleQuickPromptSend(chipText)}
                                className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-full hover:bg-slate-50 hover:border-slate-300 transition-colors cursor-pointer whitespace-nowrap"
                              >
                                {chipText}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}

                {/* Live Streaming Assistant Turn */}
                {isStreaming && (
                  <div className="flex items-start gap-3.5">
                    <div
                      className="w-7 h-7 rounded-full border border-slate-200 bg-slate-900 text-white text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5 select-none"
                      aria-hidden="true"
                    >
                      M
                    </div>
                    <div className="flex-1 min-w-0">
                      {parsedStreaming.cleanContent ? (
                        <MarkdownRenderer
                          content={parsedStreaming.cleanContent}
                          isStreaming={true}
                        />
                      ) : (
                        <div className="flex items-center gap-2 py-1 text-sm text-slate-500">
                          <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                          <span>
                            {streamingModel || modelTier === 'thinking'
                              ? 'Thinking step by step...'
                              : 'Mitra is replying...'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Floating Scroll-to-Bottom Button when user scrolls up */}
            {!isAtBottom && (
              <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-10">
                <button
                  type="button"
                  onClick={() => scrollToBottom('smooth')}
                  className="w-8 h-8 rounded-full bg-white border border-slate-200 shadow-md flex items-center justify-center text-slate-700 hover:text-slate-900 hover:bg-slate-50 transition-transform cursor-pointer"
                  title="Scroll to latest message"
                  aria-label="Scroll to latest message"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Docked Bottom Composer */}
            <div className="bg-white px-4 sm:px-8 pb-4 pt-1">
              {renderComposerCard(false)}
            </div>
          </>
        )}

        {/* INTERACTIVE VOICE TUTOR OVERLAY (Hands-Free ChatGPT-Like Voice Conversation) */}
        {voiceModeOpen && (
          <div className="absolute inset-0 z-40 bg-slate-950 text-white flex flex-col items-center justify-between p-6 sm:p-10">
            <div className="w-full max-w-2xl flex items-center justify-between">
              <div className="text-sm font-medium text-slate-300">
                Mitra Voice Tutor · <span className="capitalize">{profile.preferredLanguage}</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  cancelMicRecording();
                  stopAudioPlayback();
                  setVoiceModeOpen(false);
                }}
                className="p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                aria-label="Close voice conversation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex flex-col items-center text-center max-w-xl space-y-6">
              <div
                className={`w-36 h-36 rounded-full flex items-center justify-center border-2 transition-transform duration-200 ${
                  isRecordingMic
                    ? 'scale-110 border-blue-400 bg-blue-500/20'
                    : speakingMessageId
                    ? 'scale-105 border-emerald-400 bg-emerald-500/20'
                    : isStreaming || isTranscribingMic
                    ? 'border-slate-500 bg-slate-800'
                    : 'border-slate-700 bg-slate-900'
                }`}
              >
                {isTranscribingMic || isStreaming ? (
                  <Loader2 className="w-10 h-10 text-blue-300 animate-spin" />
                ) : speakingMessageId ? (
                  <Volume2 className="w-10 h-10 text-emerald-300" />
                ) : (
                  <Mic
                    className={`w-10 h-10 ${
                      isRecordingMic ? 'text-blue-300' : 'text-slate-300'
                    }`}
                  />
                )}
              </div>

              <div className="space-y-2">
                <div className="text-lg font-semibold tracking-tight">
                  {isRecordingMic
                    ? `Listening (${formatDurationClock(recordingSeconds)})`
                    : voiceStatusText}
                </div>
                {lastVoiceTranscript && (
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    You asked: “{lastVoiceTranscript}”
                  </p>
                )}
                {isStreaming && parsedStreaming.cleanContent && (
                  <p className="text-sm text-slate-200 max-w-lg mx-auto line-clamp-4 leading-relaxed">
                    {parsedStreaming.cleanContent}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-4">
              {isRecordingMic ? (
                <>
                  <button
                    type="button"
                    onClick={cancelMicRecording}
                    className="px-5 py-3 rounded-full bg-slate-800 hover:bg-slate-700 text-sm font-medium cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={finishMicRecording}
                    className="px-6 py-3 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    Send to Mitra
                  </button>
                </>
              ) : speakingMessageId ? (
                <button
                  type="button"
                  onClick={stopAudioPlayback}
                  className="px-6 py-3 rounded-full bg-slate-800 hover:bg-slate-700 text-sm font-medium inline-flex items-center gap-2 cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  Interrupt & Reply
                </button>
              ) : (
                <button
                  type="button"
                  disabled={isStreaming || isTranscribingMic}
                  onClick={() => void startMicRecording(true)}
                  className="px-7 py-3.5 rounded-full bg-white text-slate-950 hover:bg-slate-100 text-sm font-semibold inline-flex items-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  <Mic className="w-4 h-4" />
                  Tap to Speak
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  cancelMicRecording();
                  stopAudioPlayback();
                  setVoiceModeOpen(false);
                }}
                className="px-5 py-3.5 rounded-full border border-slate-700 text-slate-300 hover:text-white hover:border-slate-500 text-sm font-medium cursor-pointer"
              >
                Back to Chat
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
