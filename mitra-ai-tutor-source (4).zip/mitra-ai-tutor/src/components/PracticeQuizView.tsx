import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Award,
  CheckCircle2,
  Clock,
  Eye,
  HelpCircle,
  MessageSquare,
  Play,
  RotateCcw,
  XCircle,
} from 'lucide-react';
import { QUIZ_BANK } from '../data/questionBank.ts';
import { QuestionDiagram } from './QuestionDiagram.tsx';
import type {
  ErrorLogRecord,
  MistakeType,
  QuizAttemptRecord,
  QuizQuestion,
  QuizSet,
  SubjectKey,
} from '../types/mitra.ts';

interface PracticeQuizViewProps {
  initialQuizId?: string | null;
  quizAttempts: QuizAttemptRecord[];
  errorLog: ErrorLogRecord[];
  onClearInitialQuiz: () => void;
  onSubmitQuizResult: (params: {
    attempt: Omit<QuizAttemptRecord, 'id' | 'createdAt' | 'status'>;
    newErrors: Array<Omit<ErrorLogRecord, 'id' | 'createdAt' | 'updatedAt' | 'resolved'>>;
    timeSpentMinutes: number;
  }) => Promise<void>;
  onResolveErrorOnRedemption?: (errorId: string, explanation: string) => void;
  onAskMitraAboutQuestion: (prompt: string) => void;
}

function checkQuestionCorrect(q: QuizQuestion, rawAnswer: string | undefined): boolean {
  if (rawAnswer === undefined || rawAnswer.trim() === '') return false;
  if (q.type === 'mcq') {
    const chosenIdx = Number(rawAnswer);
    return !Number.isNaN(chosenIdx) && chosenIdx === q.correctOptionIndex;
  }
  const normalized = rawAnswer.trim().toLowerCase();
  return (q.acceptedWrittenAnswers || []).some(
    (ans) => ans.trim().toLowerCase() === normalized
  );
}

function getCorrectAnswerDisplay(q: QuizQuestion): string {
  if (q.type === 'mcq' && q.options && q.correctOptionIndex !== undefined) {
    return `Option ${q.correctOptionIndex + 1}: ${q.options[q.correctOptionIndex]}`;
  }
  return (q.acceptedWrittenAnswers || [])[0] || '';
}

function getStudentAnswerDisplay(q: QuizQuestion, rawAnswer: string | undefined): string {
  if (rawAnswer === undefined || rawAnswer.trim() === '') return 'Unattempted';
  if (q.type === 'mcq' && q.options) {
    const idx = Number(rawAnswer);
    if (!Number.isNaN(idx) && q.options[idx]) {
      return `Option ${idx + 1}: ${q.options[idx]}`;
    }
  }
  return rawAnswer.trim();
}

function buildAdaptiveMistakeQuiz(
  errorLog: ErrorLogRecord[]
): { quiz: QuizSet; errorIdByQuestionId: Map<string, { id: string; explanation: string }> } | null {
  const unresolved = errorLog.filter((e) => !e.resolved);
  if (unresolved.length === 0) return null;

  const allBankQuestions = new Map<string, QuizQuestion>();
  for (const qs of QUIZ_BANK) {
    for (const q of qs.questions) {
      allBankQuestions.set(q.id, q);
    }
  }

  const questions: QuizQuestion[] = [];
  const errorIdByQuestionId = new Map<string, { id: string; explanation: string }>();

  for (const err of unresolved) {
    const bankMatch = allBankQuestions.get(err.questionId);
    if (bankMatch) {
      questions.push(bankMatch);
      errorIdByQuestionId.set(bankMatch.id, { id: err.id, explanation: err.explanation });
    } else {
      const cleanAccepted = err.correctAnswer.replace(/^Option\s+\d+:\s*/i, '').trim();
      const synthId = `redemption_${err.id}`;
      questions.push({
        id: synthId,
        sourceLabel: 'Personal Mistake Notebook · Adaptive Revision',
        isOfficialPyq: false,
        subject: err.subject,
        topicId: err.topicId,
        difficulty: 'intermediate',
        type: 'written',
        questionText: err.questionText,
        acceptedWrittenAnswers: [cleanAccepted, err.correctAnswer],
        hint: `Avoid your previous ${err.mistakeType.replace('_', ' ')} slip ("${err.studentAnswer}").`,
        explanation: err.explanation,
      });
      errorIdByQuestionId.set(synthId, { id: err.id, explanation: err.explanation });
    }
  }

  return {
    quiz: {
      id: 'quiz_mistake_redemption',
      title: `Adaptive Mistake Redemption Drill (${questions.length} Active Mistakes)`,
      subtitle:
        'Dynamically generated from your unresolved Error Log. Answering a question right here automatically marks it resolved in your Mistake Notebook!',
      subject: unresolved[0].subject,
      topicId: unresolved[0].topicId,
      difficulty: 'intermediate',
      examFormat: 'topic_quiz',
      timeLimitMinutes: Math.max(6, questions.length * 2),
      passingPercent: 80,
      sourceBadge: 'Personal Mistake Notebook · Spaced Revision',
      questions,
    },
    errorIdByQuestionId,
  };
}

export const PracticeQuizView: React.FC<PracticeQuizViewProps> = ({
  initialQuizId,
  quizAttempts,
  errorLog,
  onClearInitialQuiz,
  onSubmitQuizResult,
  onResolveErrorOnRedemption,
  onAskMitraAboutQuestion,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [activeQuiz, setActiveQuiz] = useState<QuizSet | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [mistakeTypes, setMistakeTypes] = useState<Record<string, MistakeType>>({});
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});
  const [revealedSolutions, setRevealedSolutions] = useState<Record<string, boolean>>({});
  const [checkedSingle, setCheckedSingle] = useState<Record<string, boolean>>({});
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const adaptiveMistakeBundle = useMemo(
    () => buildAdaptiveMistakeQuiz(errorLog),
    [errorLog]
  );

  const allAvailableQuizzes = useMemo(() => {
    return adaptiveMistakeBundle
      ? [adaptiveMistakeBundle.quiz, ...QUIZ_BANK]
      : QUIZ_BANK;
  }, [adaptiveMistakeBundle]);

  const startQuizSession = useCallback((quiz: QuizSet) => {
    setActiveQuiz(quiz);
    setAnswers({});
    setMistakeTypes({});
    setRevealedHints({});
    setRevealedSolutions({});
    setCheckedSingle({});
    setSecondsElapsed(0);
    setIsSubmitted(false);
  }, []);

  useEffect(() => {
    if (initialQuizId) {
      const found = allAvailableQuizzes.find((q) => q.id === initialQuizId);
      if (found) {
        startQuizSession(found);
      }
      onClearInitialQuiz();
    }
  }, [initialQuizId, allAvailableQuizzes, onClearInitialQuiz, startQuizSession]);

  const handleFinalizeQuiz = useCallback(async () => {
    if (!activeQuiz || isSubmitted || isSaving) return;
    setIsSaving(true);

    let score = 0;
    let wrongAttempted = 0;
    let unattemptedCount = 0;
    const newErrors: Array<Omit<ErrorLogRecord, 'id' | 'createdAt' | 'updatedAt' | 'resolved'>> = [];
    const redeemedErrorIds: Array<{ id: string; explanation: string }> = [];

    for (const q of activeQuiz.questions) {
      const raw = answers[q.id];
      const isBlank = raw === undefined || raw.trim() === '';
      const ok = checkQuestionCorrect(q, raw);

      if (ok) {
        score += 1;
        if (activeQuiz.id === 'quiz_mistake_redemption' && adaptiveMistakeBundle) {
          const match = adaptiveMistakeBundle.errorIdByQuestionId.get(q.id);
          if (match) redeemedErrorIds.push(match);
        }
      } else {
        if (isBlank) {
          unattemptedCount += 1;
        } else {
          wrongAttempted += 1;
        }
        if (activeQuiz.id !== 'quiz_mistake_redemption') {
          newErrors.push({
            questionId: q.id,
            subject: q.subject,
            topicId: q.topicId,
            questionText: q.questionText,
            studentAnswer: getStudentAnswerDisplay(q, raw),
            correctAnswer: getCorrectAnswerDisplay(q),
            mistakeType: mistakeTypes[q.id] || 'conceptual',
            explanation: q.explanation,
          });
        }
      }
    }

    const total = activeQuiz.questions.length;
    const accuracyPercent = Math.round((score / total) * 100);
    const passed = accuracyPercent >= activeQuiz.passingPercent;
    const timeSpentMinutes = Math.max(1, Math.ceil(secondsElapsed / 60));

    const posMark = activeQuiz.marksPerCorrect ?? 4;
    const negMark = activeQuiz.negativeMarkPerWrong ?? 0;
    const rawMarks =
      activeQuiz.negativeMarkPerWrong !== undefined
        ? score * posMark - wrongAttempted * negMark
        : undefined;
    const maxMarks =
      activeQuiz.negativeMarkPerWrong !== undefined ? total * posMark : undefined;

    try {
      await onSubmitQuizResult({
        attempt: {
          quizId: activeQuiz.id,
          title: activeQuiz.title,
          subject: activeQuiz.subject,
          topicId: activeQuiz.topicId,
          examFormat: activeQuiz.examFormat || 'topic_quiz',
          score,
          total,
          rawMarks,
          maxMarks,
          unattemptedCount,
          accuracyPercent,
          durationSeconds: secondsElapsed,
          passed,
        },
        newErrors,
        timeSpentMinutes,
      });

      if (redeemedErrorIds.length > 0 && onResolveErrorOnRedemption) {
        for (const item of redeemedErrorIds) {
          onResolveErrorOnRedemption(item.id, item.explanation);
        }
      }

      setIsSubmitted(true);
    } finally {
      setIsSaving(false);
    }
  }, [
    activeQuiz,
    adaptiveMistakeBundle,
    answers,
    isSaving,
    isSubmitted,
    mistakeTypes,
    onResolveErrorOnRedemption,
    onSubmitQuizResult,
    secondsElapsed,
  ]);

  // Countdown Timer + Strict Auto-Submit when countdown hits 00:00
  const autoSubmitTriggeredRef = useRef(false);
  useEffect(() => {
    autoSubmitTriggeredRef.current = false;
  }, [activeQuiz]);

  useEffect(() => {
    if (!activeQuiz || isSubmitted) return;
    const limitSecs = activeQuiz.timeLimitMinutes * 60;
    if (secondsElapsed >= limitSecs && !autoSubmitTriggeredRef.current) {
      autoSubmitTriggeredRef.current = true;
      void handleFinalizeQuiz();
      return;
    }
    const timer = setInterval(() => {
      setSecondsElapsed((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [activeQuiz, isSubmitted, secondsElapsed, handleFinalizeQuiz]);

  const filteredQuizzes = useMemo(() => {
    if (categoryFilter === 'all') return allAvailableQuizzes;
    if (categoryFilter === 'full_mock') {
      return allAvailableQuizzes.filter((q) => q.examFormat === 'full_mock');
    }
    if (categoryFilter === 'sectional') {
      return allAvailableQuizzes.filter((q) => q.examFormat === 'sectional_test');
    }
    if (categoryFilter === 'pyq') {
      return allAvailableQuizzes.filter((q) => q.id.includes('cmat_2025'));
    }
    if (categoryFilter === 'mistakes') {
      return allAvailableQuizzes.filter((q) => q.id === 'quiz_mistake_redemption');
    }
    return allAvailableQuizzes.filter(
      (q) => !q.examFormat || q.examFormat === 'topic_quiz'
    );
  }, [categoryFilter, allAvailableQuizzes]);

  if (!activeQuiz) {
    const unresolvedCount = errorLog.filter((e) => !e.resolved).length;
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 space-y-8">
        <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div className="space-y-1.5">
            <div className="text-xs text-slate-500">
              Official +4 / -1 NTA Marking · Timed Sectional & Full Mocks · Adaptive Mistake Revision
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              CMAT 2026 Mocks, Timed Sectional Tests & Topic Quizzes
            </h1>
            <p className="text-sm text-slate-600 max-w-2xl">
              Practice foundational drills, timed +4/-1 sectional tests across all 5 CMAT sections, authentic NTA Jan 2025 PYQs, and your personal Mistake Redemption Drill.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {[
              { id: 'all', label: 'All Sets' },
              { id: 'full_mock', label: 'Full Mock (+4/-1)' },
              { id: 'sectional', label: 'Sectional Tests' },
              { id: 'topic', label: 'Topic Quizzes' },
              { id: 'pyq', label: 'CMAT 2025 PYQs' },
              ...(unresolvedCount > 0
                ? [{ id: 'mistakes', label: `Mistake Drill (${unresolvedCount})` }]
                : []),
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setCategoryFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  categoryFilter === tab.id
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredQuizzes.map((quiz) => {
            const past = quizAttempts.filter((a) => a.quizId === quiz.id);
            const best = past.reduce(
              (max, cur) => (cur.accuracyPercent > max ? cur.accuracyPercent : max),
              -1
            );
            const isMockOrSec =
              quiz.examFormat === 'full_mock' || quiz.examFormat === 'sectional_test';

            return (
              <div
                key={quiz.id}
                className={`bg-white border rounded-xl p-6 flex flex-col justify-between gap-5 ${
                  quiz.examFormat === 'full_mock'
                    ? 'border-blue-300 ring-1 ring-blue-100'
                    : quiz.id === 'quiz_mistake_redemption'
                    ? 'border-amber-300 bg-amber-50/20'
                    : 'border-slate-200'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 tabular-nums">
                    <span>
                      {quiz.subject} · <span className="capitalize">{quiz.difficulty}</span> ·{' '}
                      {quiz.questions.length} Qs · {quiz.timeLimitMinutes} mins
                    </span>
                    {isMockOrSec && (
                      <span className="font-mono font-semibold text-blue-800">
                        +4 / -{quiz.negativeMarkPerWrong ?? 1} NTA Marking
                      </span>
                    )}
                  </div>
                  <h2 className="text-base font-semibold text-slate-900">{quiz.title}</h2>
                  <p className="text-xs text-slate-600 leading-relaxed">{quiz.subtitle}</p>
                  <div className="pt-1 text-[11px] text-slate-500">
                    Source: {quiz.sourceBadge}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="text-xs tabular-nums">
                    {best >= 0 ? (
                      <span className="text-emerald-700 font-medium">
                        Best Score: {best}% ({past.length} attempt{past.length > 1 ? 's' : ''})
                      </span>
                    ) : (
                      <span className="text-amber-700 font-medium">
                        Assessment Pending (0 attempts)
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => startQuizSession(quiz)}
                    className="px-4 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    {best >= 0 ? 'Retake Test' : 'Start Test'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const remainingSeconds = Math.max(0, activeQuiz.timeLimitMinutes * 60 - secondsElapsed);
  const minsLeft = Math.floor(remainingSeconds / 60);
  const secsLeft = remainingSeconds % 60;
  const isNtaMarked = activeQuiz.negativeMarkPerWrong !== undefined;

  let rightCount = 0;
  let wrongAttemptedCount = 0;
  let blankCount = 0;
  const sectionScoreMap = new Map<
    SubjectKey,
    { right: number; wrong: number; total: number }
  >();

  for (const q of activeQuiz.questions) {
    const raw = answers[q.id];
    const isBlank = raw === undefined || raw.trim() === '';
    const ok = checkQuestionCorrect(q, raw);
    const secStat = sectionScoreMap.get(q.subject) || { right: 0, wrong: 0, total: 0 };
    secStat.total += 1;

    if (ok) {
      rightCount += 1;
      secStat.right += 1;
    } else if (isBlank) {
      blankCount += 1;
    } else {
      wrongAttemptedCount += 1;
      secStat.wrong += 1;
    }
    sectionScoreMap.set(q.subject, secStat);
  }

  const finalAccuracy = Math.round((rightCount / activeQuiz.questions.length) * 100);
  const posMark = activeQuiz.marksPerCorrect ?? 4;
  const negMark = activeQuiz.negativeMarkPerWrong ?? 0;
  const finalNtaMarks = rightCount * posMark - wrongAttemptedCount * negMark;
  const maxNtaMarks = activeQuiz.questions.length * posMark;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-8 py-8 space-y-6">
      {/* Sticky Quiz Control Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 sticky top-[4.25rem] z-20 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setActiveQuiz(null)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Back to Quiz Bank"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-semibold text-slate-900 truncate">
                {activeQuiz.title}
              </h1>
              <div className="text-xs text-slate-500 tabular-nums">
                {Object.keys(answers).filter((k) => (answers[k] || '').trim() !== '').length} /{' '}
                {activeQuiz.questions.length} answered · Passing mark: {activeQuiz.passingPercent}%
                {isNtaMarked ? ` · Marking: +${posMark} / -${negMark} (0 unattempted)` : ''}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div
              className={`px-3 py-1.5 rounded-lg border font-mono text-xs font-semibold tabular-nums inline-flex items-center gap-1.5 ${
                remainingSeconds < 60 && !isSubmitted
                  ? 'border-red-300 bg-red-50 text-red-700'
                  : 'border-slate-200 bg-slate-50 text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              {isSubmitted
                ? `Completed in ${Math.floor(secondsElapsed / 60)}m ${secondsElapsed % 60}s`
                : `${String(minsLeft).padStart(2, '0')}:${String(secsLeft).padStart(2, '0')}`}
            </div>

            {!isSubmitted ? (
              <button
                type="button"
                onClick={() => void handleFinalizeQuiz()}
                disabled={isSaving}
                className="px-4 py-2 bg-blue-700 text-white text-xs font-medium rounded-lg hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
              >
                {isSaving ? 'Grading & Saving...' : 'Submit & Grade'}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => startQuizSession(activeQuiz)}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-medium rounded-lg hover:bg-slate-800 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Retake Test
              </button>
            )}
          </div>
        </div>

        {/* Question Palette Navigator */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100">
          <span className="text-[11px] text-slate-400 mr-1">Questions:</span>
          {activeQuiz.questions.map((q, idx) => {
            const answered = Boolean((answers[q.id] || '').trim());
            const ok = checkQuestionCorrect(q, answers[q.id]);
            let btnStyle = 'bg-slate-100 text-slate-600 hover:bg-slate-200';
            if (isSubmitted) {
              btnStyle = ok
                ? 'bg-emerald-600 text-white'
                : answered
                ? 'bg-red-600 text-white'
                : 'bg-slate-200 text-slate-700';
            } else if (answered) {
              btnStyle = 'bg-slate-900 text-white';
            }
            return (
              <a
                key={q.id}
                href={`#question_${q.id}`}
                className={`w-6 h-6 rounded text-[11px] font-mono font-semibold inline-flex items-center justify-center transition-colors ${btnStyle}`}
              >
                {idx + 1}
              </a>
            );
          })}
        </div>
      </div>

      {/* Result Summary Banner after Submission */}
      {isSubmitted && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-medium text-slate-500 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-blue-700" />
                Verified Test Scorecard
              </div>
              <h2 className="text-xl font-bold text-slate-900 tabular-nums">
                {isNtaMarked ? (
                  <>
                    NTA Score: {finalNtaMarks} / {maxNtaMarks} Marks ({rightCount}/
                    {activeQuiz.questions.length} Correct · {finalAccuracy}%)
                  </>
                ) : (
                  <>
                    Score: {rightCount} / {activeQuiz.questions.length} ({finalAccuracy}%)
                  </>
                )}{' '}
                —{' '}
                <span
                  className={
                    finalAccuracy >= activeQuiz.passingPercent
                      ? 'text-emerald-700'
                      : 'text-amber-700'
                  }
                >
                  {finalAccuracy >= activeQuiz.passingPercent
                    ? 'Passed & Mastery Updated'
                    : 'Recorded — Review Wrong Answers Below'}
                </span>
              </h2>
            </div>
            <div className="text-xs text-slate-600 tabular-nums">
              Right: <strong className="text-emerald-700">{rightCount}</strong> · Wrong:{' '}
              <strong className="text-red-700">{wrongAttemptedCount}</strong> · Unattempted:{' '}
              <strong>{blankCount}</strong> · Avg Speed:{' '}
              {Math.round(secondsElapsed / activeQuiz.questions.length)}s/Q
            </div>
          </div>

          {sectionScoreMap.size > 1 && (
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-3 border-t border-slate-100">
              {Array.from(sectionScoreMap.entries()).map(([subj, stat]) => (
                <div
                  key={subj}
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs tabular-nums"
                >
                  <div className="font-medium text-slate-800 truncate">{subj}</div>
                  <div className="font-mono font-semibold text-slate-900 mt-0.5">
                    {stat.right}/{stat.total} right
                    {isNtaMarked ? ` (${stat.right * posMark - stat.wrong * negMark}m)` : ''}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Questions List */}
      <div className="space-y-5">
        {activeQuiz.questions.map((q, index) => {
          const userAns = answers[q.id];
          const isChecked = isSubmitted || Boolean(checkedSingle[q.id]);
          const isCorrect = checkQuestionCorrect(q, userAns);
          const showExplanation = isChecked || Boolean(revealedSolutions[q.id]);

          return (
            <div
              id={`question_${q.id}`}
              key={q.id}
              className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 scroll-mt-36"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 tabular-nums">
                <div>
                  <span className="font-semibold text-slate-900">Q.{index + 1}</span>
                  <span aria-hidden="true"> · </span>
                  <span>{q.subject}</span>
                  <span aria-hidden="true"> · </span>
                  <span className={q.isOfficialPyq ? 'text-blue-700 font-medium' : ''}>
                    {q.sourceLabel}
                  </span>
                </div>

                {isChecked && (
                  <div className="inline-flex items-center gap-1.5 font-medium">
                    {isCorrect ? (
                      <span className="text-emerald-700 inline-flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Correct
                        {isNtaMarked ? ` (+${posMark})` : ''}
                      </span>
                    ) : userAns === undefined || userAns.trim() === '' ? (
                      <span className="text-slate-500 inline-flex items-center gap-1">
                        Unattempted (0)
                      </span>
                    ) : (
                      <span className="text-red-700 inline-flex items-center gap-1">
                        <XCircle className="w-4 h-4" /> Incorrect
                        {isNtaMarked ? ` (-${negMark})` : ''}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {q.comprehensionPassage && (
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 leading-relaxed">
                  <strong>Comprehension Data:</strong> {q.comprehensionPassage}
                </div>
              )}

              <QuestionDiagram diagramType={q.diagramType} />

              <div className="text-sm sm:text-base font-medium text-slate-900 leading-relaxed">
                {q.questionText}
              </div>

              {/* Answer Input: MCQ vs Written */}
              {q.type === 'mcq' && q.options ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {q.options.map((opt, optIdx) => {
                    const selected = userAns === String(optIdx);
                    const isRightOpt = q.correctOptionIndex === optIdx;

                    let borderStyle = 'border-slate-200 hover:border-slate-300 bg-white';
                    if (showExplanation) {
                      if (isRightOpt) {
                        borderStyle = 'border-emerald-600 bg-emerald-50/70 text-emerald-950';
                      } else if (selected && !isRightOpt) {
                        borderStyle = 'border-red-500 bg-red-50/70 text-red-950';
                      }
                    } else if (selected) {
                      borderStyle = 'border-blue-700 bg-blue-50/60 text-slate-900';
                    }

                    return (
                      <button
                        key={opt}
                        type="button"
                        disabled={isSubmitted}
                        onClick={() =>
                          setAnswers((prev) =>
                            prev[q.id] === String(optIdx)
                              ? { ...prev, [q.id]: '' }
                              : { ...prev, [q.id]: String(optIdx) }
                          )
                        }
                        className={`text-left px-4 py-3 rounded-lg border text-xs sm:text-sm transition-colors flex items-start gap-2.5 cursor-pointer disabled:cursor-default ${borderStyle}`}
                      >
                        <span className="font-mono font-semibold text-slate-500 shrink-0">
                          ({optIdx + 1})
                        </span>
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="pt-1 flex flex-wrap items-center gap-3">
                  <input
                    type="text"
                    disabled={isSubmitted}
                    value={userAns || ''}
                    onChange={(e) =>
                      setAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                    }
                    placeholder="Type your exact answer..."
                    className="w-full sm:w-72 px-3.5 py-2 text-sm font-mono bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-none focus:border-blue-600"
                  />
                </div>
              )}

              {/* Interactive Controls: Hint, Check Single Answer, Show Solution, Ask Mitra */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100">
                <div className="flex flex-wrap items-center gap-3 text-xs">
                  <button
                    type="button"
                    onClick={() =>
                      setRevealedHints((prev) => ({ ...prev, [q.id]: !prev[q.id] }))
                    }
                    className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                    {revealedHints[q.id] ? 'Hide Hint' : 'Show Hint'}
                  </button>

                  {!isSubmitted && activeQuiz.examFormat !== 'full_mock' && (
                    <button
                      type="button"
                      onClick={() =>
                        setCheckedSingle((prev) => ({ ...prev, [q.id]: true }))
                      }
                      disabled={userAns === undefined || userAns === ''}
                      className="inline-flex items-center gap-1 text-blue-700 hover:underline font-medium cursor-pointer disabled:opacity-40"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Check Answer
                    </button>
                  )}

                  {activeQuiz.examFormat !== 'full_mock' || isSubmitted ? (
                    <button
                      type="button"
                      onClick={() =>
                        setRevealedSolutions((prev) => ({ ...prev, [q.id]: !prev[q.id] }))
                      }
                      className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 font-medium cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {revealedSolutions[q.id] ? 'Hide Solution' : 'Show Solution'}
                    </button>
                  ) : null}
                </div>

                <button
                  type="button"
                  onClick={() =>
                    onAskMitraAboutQuestion(
                      `Mitra, please explain this question step by step from absolute basics:\n\n"${q.questionText}"\nMy chosen answer: ${getStudentAnswerDisplay(
                        q,
                        userAns
                      )}\nCorrect answer: ${getCorrectAnswerDisplay(q)}\nExplain specifically why my wrong option fails, show the fastest CMAT shortcut, and then ask me 1 similar practice question.`
                    )
                  }
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:underline cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Why Wrong? Ask Mitra
                </button>
              </div>

              {revealedHints[q.id] && (
                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-lg text-xs text-amber-950">
                  <strong>Tutor Hint (No Spoiler):</strong> {q.hint}
                </div>
              )}

              {showExplanation && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2.5 text-xs text-slate-800 leading-relaxed">
                  {!isCorrect && userAns !== undefined && userAns.trim() !== '' && (
                    <div className="p-2.5 bg-red-50 border border-red-200 rounded-md text-red-950">
                      <strong>Why Your Selection ({getStudentAnswerDisplay(q, userAns)}) Is Wrong:</strong>{' '}
                      Compare your choice against the exact step-by-step derivation below — avoid distractor traps by anchoring to the core invariant before calculating.
                    </div>
                  )}

                  <div className="font-semibold text-emerald-800">
                    Verified Correct Answer: {getCorrectAnswerDisplay(q)}
                  </div>
                  <div>
                    <strong>Step-by-Step Solution:</strong> {q.explanation}
                  </div>
                  {q.formulaUsed && (
                    <div className="font-mono text-[11px] text-slate-600">
                      Core Rule / Formula: {q.formulaUsed}
                    </div>
                  )}

                  {!isCorrect && !isSubmitted && (
                    <div className="pt-2 flex flex-wrap items-center gap-2">
                      <span className="text-slate-600 inline-flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                        Tag mistake reason for Error Log:
                      </span>
                      {(
                        ['conceptual', 'calculation', 'reading', 'time_pressure'] as MistakeType[]
                      ).map((mt) => (
                        <button
                          key={mt}
                          type="button"
                          onClick={() =>
                            setMistakeTypes((prev) => ({ ...prev, [q.id]: mt }))
                          }
                          className={`px-2 py-0.5 rounded border text-[11px] capitalize cursor-pointer ${
                            (mistakeTypes[q.id] || 'conceptual') === mt
                              ? 'bg-slate-900 text-white border-slate-900'
                              : 'bg-white text-slate-600 border-slate-200'
                          }`}
                        >
                          {mt.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
