import type { Express, Request, Response } from 'express';
import { requireAuth } from './authMiddleware.ts';
import { getStore } from './storage.ts';
import type { ServerWorkspaceStore } from './storage.ts';

interface PrincipalGithubSession {
  token: string;
  user: { login: string; avatar_url: string; html_url: string } | null;
}

const githubByPrincipal = new Map<string, PrincipalGithubSession>();

function parseCookies(cookieHeader?: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = decodeURIComponent(part.slice(idx + 1).trim());
      out[k] = v;
    }
  }
  return out;
}

function getRedirectUri(req: Request): string {
  const fromQuery = typeof req.query.origin === 'string' ? req.query.origin.trim() : '';
  const appUrl = (process.env.APP_URL || '').replace(/\/+$/, '');
  const base = fromQuery || appUrl || `${req.protocol}://${req.get('host')}`;
  return `${base.replace(/\/+$/, '')}/auth/github/callback`;
}

export function registerGitHubRoutes(app: Express): void {
  app.get('/api/github/status', requireAuth, async (req: Request, res: Response) => {
    const principalId = req.principal!.principalId;
    const clientId = (process.env.GITHUB_CLIENT_ID || '').trim();
    const clientSecret = (process.env.GITHUB_CLIENT_SECRET || '').trim();
    const oauthConfigured = Boolean(clientId && clientSecret);

    const cookies = parseCookies(req.headers.cookie);
    const existing = githubByPrincipal.get(principalId);
    const token = cookies.mitra_gh_token || existing?.token || null;
    let ghUser = existing?.user || null;

    if (token && !ghUser) {
      try {
        const ghRes = await fetch('https://api.github.com/user', {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/vnd.github+json',
            'User-Agent': 'Mitra-AI-Tutor',
          },
        });
        if (ghRes.ok) {
          const data = (await ghRes.json()) as {
            login: string;
            avatar_url: string;
            html_url: string;
          };
          ghUser = {
            login: data.login,
            avatar_url: data.avatar_url,
            html_url: data.html_url,
          };
          githubByPrincipal.set(principalId, { token, user: ghUser });
        }
      } catch {
        // Ignore transient network errors
      }
    }

    res.json({
      oauthConfigured,
      connected: Boolean(token && ghUser),
      user: ghUser,
      callbackPath: '/auth/github/callback',
    });
  });

  app.get('/api/github/auth/url', requireAuth, (req: Request, res: Response) => {
    const clientId = (process.env.GITHUB_CLIENT_ID || '').trim();
    if (!clientId) {
      res.status(400).json({
        error:
          'GITHUB_CLIENT_ID is not configured yet. Add GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET in AI Studio Secrets to connect GitHub OAuth.',
      });
      return;
    }

    const redirectUri = getRedirectUri(req);
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      scope: 'repo gist read:user',
    });

    res.json({
      url: `https://github.com/login/oauth/authorize?${params.toString()}`,
      redirectUri,
    });
  });

  const callbackHandler = async (req: Request, res: Response) => {
    const code = typeof req.query.code === 'string' ? req.query.code : '';
    const clientId = (process.env.GITHUB_CLIENT_ID || '').trim();
    const clientSecret = (process.env.GITHUB_CLIENT_SECRET || '').trim();

    if (!code || !clientId || !clientSecret) {
      res.status(400).send('GitHub OAuth callback missing code or server credentials.');
      return;
    }

    try {
      const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          code,
        }),
      });

      const tokenData = (await tokenRes.json()) as { access_token?: string; error?: string };
      if (!tokenData.access_token) {
        res.status(400).send(`GitHub token exchange failed: ${tokenData.error || 'Unknown error'}`);
        return;
      }

      res.setHeader(
        'Set-Cookie',
        `mitra_gh_token=${encodeURIComponent(
          tokenData.access_token
        )}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=2592000`
      );

      res.send(`<!doctype html>
<html>
  <body style="font-family: system-ui, sans-serif; padding: 2rem; text-align: center;">
    <h3>GitHub Connected Successfully</h3>
    <p>Returning to Mitra AI Tutor...</p>
    <script>
      if (window.opener) {
        window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS', provider: 'github' }, '*');
        window.close();
      } else {
        window.location.href = '/';
      }
    </script>
  </body>
</html>`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      res.status(500).send(`GitHub OAuth error: ${msg}`);
    }
  };

  app.get(['/auth/github/callback', '/auth/github/callback/'], callbackHandler);

  app.post('/api/github/export-gist', requireAuth, async (req: Request, res: Response) => {
    const principalId = req.principal!.principalId;
    const cookies = parseCookies(req.headers.cookie);
    const token = cookies.mitra_gh_token || githubByPrincipal.get(principalId)?.token;
    if (!token) {
      res.status(401).json({ error: 'GitHub account is not connected.' });
      return;
    }

    const store = getStore(principalId);
    const markdown = buildProgressExportMarkdown(store);

    try {
      const ghRes = await fetch('https://api.github.com/gists', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/vnd.github+json',
          'Content-Type': 'application/json',
          'User-Agent': 'Mitra-AI-Tutor',
        },
        body: JSON.stringify({
          description: `Mitra AI Tutor — CMAT 2026 Day ${store.profile.currentDay} Progress, Notes & Error Log`,
          public: false,
          files: {
            'Mitra_CMAT_2026_Study_Vault.md': {
              content: markdown,
            },
          },
        }),
      });

      if (!ghRes.ok) {
        const errBody = await ghRes.text();
        res.status(ghRes.status).json({ error: `GitHub API error: ${errBody.slice(0, 200)}` });
        return;
      }

      const gist = (await ghRes.json()) as { html_url: string; id: string };
      res.json({ url: gist.html_url, id: gist.id });
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });
}

export function buildProgressExportMarkdown(store: ServerWorkspaceStore): string {
  const lines: string[] = [
    `# Mitra AI Tutor — CMAT 2026 Learning Vault`,
    `Generated: ${new Date().toISOString()}`,
    `Current Study Day: Day ${store.profile.currentDay} · Total Study Time: ${store.profile.totalStudyMinutes} mins`,
    ``,
    `## 1. Topic Progress`,
    ...store.topicProgress.map(
      (t) =>
        `- **${t.topicId}** (${t.subject}): Status = \`${t.status}\` · Best = ${t.bestScore}/${t.totalQuestions} · Attempts = ${t.attemptsCount}`
    ),
    ``,
    `## 2. Verified Quiz Attempts`,
    ...store.quizAttempts.map(
      (q) =>
        `- **${q.title}** (${q.subject}): **${q.score}/${q.total}** (${q.accuracyPercent}%) · ${
          q.passed ? 'Passed' : 'Needs Retry'
        }`
    ),
    ``,
    `## 3. Personal Error Log`,
    ...store.errorLog.map(
      (e) =>
        `- [${e.resolved ? 'Resolved' : 'Needs Review'}] **${e.subject}** (${e.mistakeType}): ${
          e.questionText
        }\n  - Your Answer: ${e.studentAnswer} | Correct: ${e.correctAnswer}\n  - Explanation: ${e.explanation}`
    ),
    ``,
    `## 4. Saved Study Notes & Bookmarks`,
    ...store.notes.map(
      (n) => `### ${n.title} (${n.subject})\n\n${n.content}\n`
    ),
  ];
  return lines.join('\n');
}
