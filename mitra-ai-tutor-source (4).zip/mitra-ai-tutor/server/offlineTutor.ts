import type { LearningContextSummary } from './aiProvider.ts';

interface OfflineLessonModule {
  id: string;
  section: string;
  title: string;
  keywords: string[];
  hinglishSummary: string;
  stepByStepExample: string;
  checkQuestion: string;
  followups: [string, string, string];
}

const OFFLINE_CMAT_LESSONS: OfflineLessonModule[] = [
  {
    id: 'quant_ratio_prop',
    section: 'Quantitative Techniques & DI',
    title: 'Ratio, Proportion & Mixtures',
    keywords: ['ratio', 'proportion', 'mixture', 'alligation', 'continue', 'aage', 'anupat'],
    hinglishSummary: `**Zero se samajhte hain (Cafe-style):** Ratio bas do quantities ka fair comparison (hissa) hota hai. Jab $A : B$ aur $B : C$ alag-alag diye hon, toh beech wale common member **$B$** ko LCM lekar barabar bana do!`,
    stepByStepExample: `1. **Chained Ratio Merge:** Suppose $A : B = 2 : 3$ and $B : C = 4 : 5$.
   - Common term $B$ ke numbers hain $3$ aur $4$. $\\text{LCM}(3, 4) = 12$.
   - First ratio $\\times 4 \\Rightarrow 8 : 12$. Second ratio $\\times 3 \\Rightarrow 12 : 15$.
   - Combined: **$A : B : C = 8 : 12 : 15$**.
2. **Fractional Ratio Shortcut (NTA CMAT 2025 Slot 1 Q.9):**
   - Ratio $\\frac{1}{2} : \\frac{1}{3} : \\frac{1}{5} : \\frac{1}{8}$ ko whole numbers mein badalne ke liye $\\text{LCM}(2, 3, 5, 8) = 120$ se multiply karo:
   - $60 : 40 : 24 : 15 \\Rightarrow$ Minimum whole items $= 60 + 40 + 24 + 15 = 139$.`,
    checkQuestion: `**1-Question Try Check:** Agar $A : B = 3 : 5$ aur $B : C = 10 : 7$ hai, toh combined ratio $A : B : C$ kya hoga?
(A) 3 : 10 : 7
(B) 6 : 10 : 7
(C) 6 : 15 : 7
(D) 30 : 50 : 70`,
    followups: ['(B) 6 : 10 : 7', 'Hint dikhao bina answer ke', 'Live AI dubara try karo'],
  },
  {
    id: 'quant_profit_pct',
    section: 'Quantitative Techniques & DI',
    title: 'Percentages, Profit & Loss & SI/CI',
    keywords: ['percent', 'profit', 'loss', 'discount', 'interest', 'ci', 'si', 'markup'],
    hinglishSummary: `**Core Rule:** Profit% aur Loss% hamesha **Cost Price (CP)** par nikalta hai, jabki Discount% hamesha **Marked Price (MP)** par lagta hai! Successive change ke liye $a + b + \\frac{ab}{100}$ lagao.`,
    stepByStepExample: `1. **Reverse Percentage:** Agar kisi item ka price $+25\\%$ ($+\\frac{1}{4}$) badh gaya ($4 \\rightarrow 5$), toh wapas purane kharche par aane ke liye $\\frac{1}{5} = 20\\%$ kam karna padega.
2. **Markup + Discount Formula:**
   $$\\frac{\\text{CP}}{\\text{MP}} = \\frac{100 - \\text{Discount\\%}}{100 + \\text{Profit\\%}}$$
   - Example: $20\\%$ discount dekar bhi $12\\%$ profit chahiye $\\Rightarrow \\frac{\\text{CP}}{\\text{MP}} = \\frac{80}{112} = \\frac{5}{7}$ (Markup $= \\frac{2}{5} = 40\\%$).
3. **2-Year CI vs SI Shortcut:** Difference $= P \\left(\\frac{R}{100}\\right)^2$.`,
    checkQuestion: `**1-Question Try Check:** Ek shopkeeper CP se $50\\%$ upar MP rakhta hai aur $20\\%$ discount deta hai. Uska net profit percentage kitna hai?
(A) 30%
(B) 25%
(C) 20%
(D) 15%`,
    followups: ['(C) 20%', 'Step-by-step hint do', 'Time & Work sikhana'],
  },
  {
    id: 'quant_tsd_work',
    section: 'Quantitative Techniques & DI',
    title: 'Time & Work + Time, Speed & Distance',
    keywords: ['work', 'speed', 'distance', 'train', 'boat', 'race', 'efficiency', 'pipe'],
    hinglishSummary: `**LCM Total Work Trick:** Fractions ($1/12 + 1/15$) se bacho! Days ka LCM lekar "Total Chocolates / Units" maan lo — har step integer mein solve hoga.`,
    stepByStepExample: `1. **Time & Work:** $A$ finishes in $12$ days, $B$ in $15$ days.
   - Total Work $= \\text{LCM}(12, 15) = 60$ units.
   - Efficiency: $A = 60/12 = 5$ units/day; $B = 60/15 = 4$ units/day.
   - Together $= 5 + 4 = 9$ units/day $\\Rightarrow \\text{Time} = \\frac{60}{9} = 6\\frac{2}{3}$ days.
2. **Average Speed (Equal Distance):** $\\text{Avg Speed} = \\frac{2xy}{x + y}$ (kabhi $\\frac{x+y}{2}$ mat lagana!).`,
    checkQuestion: `**1-Question Try Check:** Car $A\\rightarrow B$ $40\\text{ km/h}$ se jaati hai aur $B\\rightarrow A$ $60\\text{ km/h}$ se wapas aati hai. Round-trip average speed kya hai?
(A) 50 km/h
(B) 48 km/h
(C) 45 km/h
(D) 52 km/h`,
    followups: ['(B) 48 km/h', 'Ratio lesson dikhao', 'Live AI retry karo'],
  },
  {
    id: 'lr_series_coding',
    section: 'Logical Reasoning',
    title: 'Number Series, Coding-Decoding & Arrangements',
    keywords: ['series', 'coding', 'decoding', 'direction', 'seating', 'blood', 'syllogism', 'logical', 'reasoning', 'mistake'],
    hinglishSummary: `**CMAT LR Golden Checklist:** Number series mein pehle **difference** check karo; agar numbers tezi se badhein ($>2\\times$) toh **multiplication + offset** check karo; aur $64, 125, 216, 343$ ke aas-paas hamesha **$n^3 \\pm k$** dekho!`,
    stepByStepExample: `1. **Cube Offset Pattern (Day 1 Error Log Concept):**
   - Series: $0, 7, 26, 63, 124, ?$
   - Notice: $1^3 - 1 = 0,\\; 2^3 - 1 = 7,\\; 3^3 - 1 = 26,\\; 4^3 - 1 = 63,\\; 5^3 - 1 = 124$.
   - Next term $= 6^3 - 1 = 216 - 1 = \\mathbf{215}$.
2. **Alphabet Coding (EJOTY + Opposite Pairs):**
   - EJOTY $= 5, 10, 15, 20, 25$. Opposite letters ka sum hamesha **$27$** hota hai ($A(1)+Z(26)=27$, $M(13)+N(14)=27$).`,
    checkQuestion: `**1-Question Try Check:** Find the next term in the series: $2, 9, 28, 65, 126, ?$
(A) 197
(B) 215
(C) 217
(D) 225`,
    followups: ['(C) 217', 'Grammar rules dikhao', 'Live AI retry karo'],
  },
  {
    id: 'lang_verbal',
    section: 'Language Comprehension',
    title: 'Grammar, Fixed Prepositions, Voice & RC Strategy',
    keywords: ['grammar', 'english', 'language', 'preposition', 'article', 'voice', 'narration', 'passage', 'rc', 'vocab', 'idiom'],
    hinglishSummary: `**CMAT Verbal High-Yield Trap:** Active-Passive mein har jagah *"by"* nahi aata — kuch verbs apna fixed preposition lete hain (*known to*, *pleased with*, *contained in*, *surprised at*).`,
    stepByStepExample: `1. **Fixed Prepositions:**
   - *Senior / Junior / Superior / Prefer* ke baad **"than"** nahi, hamesha **"to"** aata hai (*"He prefers tea to coffee"*).
2. **Subject-Verb Agreement:**
   - *"Neither of"*, *"Each of"*, *"One of"* ke baad **plural noun** aata hai par **singular verb** lagta hai: *"One of the students **is** absent."*
3. **RC Elimination Rule:** Extreme words (*always, never, only, completely*) waale options CMAT inference questions mein 90% galat hote hain jab tak passage mein explicitly na likha ho.`,
    checkQuestion: `**1-Question Try Check:** Spot the correct sentence:
(A) She is senior than me by two years.
(B) One of my friend are coming today.
(C) I prefer walking to cycling.
(D) The box is contained by five books.`,
    followups: ['(C) I prefer walking to cycling.', 'GK Polity notes dikhao', 'Live AI retry karo'],
  },
  {
    id: 'gk_polity_econ',
    section: 'General Knowledge',
    title: 'Indian Constitution, Economy (RBI) & Static GK',
    keywords: ['gk', 'constitution', 'polity', 'article', 'president', 'economy', 'rbi', 'repo', 'amendment', 'general knowledge'],
    hinglishSummary: `**CMAT Static GK Anchor:** Polity Articles, Constitutional Amendments, aur RBI Monetary Policy har saal CMAT Slot 1 & Slot 2 dono mein puchte hain!`,
    stepByStepExample: `1. **Constitution Milestones:**
   - Adopted: **26 Nov 1949** · Enforced: **26 Jan 1950** · Drafting Committee Chair: **Dr. B. R. Ambedkar**.
   - **42nd Amendment (1976):** Added *Socialist, Secular, Integrity* & **Fundamental Duties (Part IV-A, Art. 51A)** on Swaran Singh Committee recommendation.
   - **Article 32:** Right to Constitutional Remedies (*"Heart & Soul"*).
2. **RBI Monetary Tools:**
   - **Repo Rate:** Rate at which RBI lends short-term funds to commercial banks (inflation rokne ke liye RBI Repo Rate badhata hai).`,
    checkQuestion: `**1-Question Try Check:** Under which Article of the Indian Constitution can a citizen directly move the Supreme Court for enforcement of Fundamental Rights?
(A) Article 19
(B) Article 21
(C) Article 32
(D) Article 226`,
    followups: ['(C) Article 32', 'Entrepreneurship basics dikhao', 'Live AI retry karo'],
  },
  {
    id: 'ent_innovation',
    section: 'Innovation & Entrepreneurship',
    title: 'Startup Funding Lifecycle, Lean MVP & IPR',
    keywords: ['innovation', 'entrepreneur', 'startup', 'bootstrapping', 'angel', 'venture', 'mvp', 'patent', 'ipr', 'unicorn'],
    hinglishSummary: `**Startup Journey ek line mein:** Khud ki jeb se shuruat = **Bootstrapping** $\\rightarrow$ Early wealthy individual = **Angel Investor** $\\rightarrow$ Institutional high-growth fund = **Venture Capital (VC)** $\\rightarrow$ Public listing = **IPO**.`,
    stepByStepExample: `1. **Lean Startup Terms (Eric Ries):**
   - **MVP (Minimum Viable Product):** Sabse basic working version launch karna taaki real customers ka feedback jaldi mile.
   - **Pivot:** Customer feedback ke baad product strategy ya business model mein smart direction change karna.
2. **Intellectual Property Rights (IPR) in India:**
   - **Patent:** Novel invention ke liye (**20 years** protection).
   - **Trademark:** Brand logo/name ke liye (**10 years**, indefinitely renewable).
   - **Copyright:** Literary/artistic/software code ke liye.`,
    checkQuestion: `**1-Question Try Check:** Starting a company using personal savings and early customer revenue without external investor equity is called:
(A) Venture Capital
(B) Crowdfunding
(C) Bootstrapping
(D) Incubating`,
    followups: ['(C) Bootstrapping', 'Ratio & Proportion padhao', 'Live AI retry karo'],
  },
];

function selectBestOfflineModule(userMessage: string, ctx: LearningContextSummary): OfflineLessonModule {
  const haystack = `${userMessage} ${ctx.currentTopicTitle} ${ctx.currentSubject}`.toLowerCase();
  const directUserLower = userMessage.toLowerCase();

  // First check direct user prompt keywords
  for (const mod of OFFLINE_CMAT_LESSONS) {
    if (mod.keywords.some((kw) => directUserLower.includes(kw))) {
      return mod;
    }
  }

  // Next check active learning context
  for (const mod of OFFLINE_CMAT_LESSONS) {
    if (mod.keywords.some((kw) => haystack.includes(kw))) {
      return mod;
    }
  }

  return OFFLINE_CMAT_LESSONS[0];
}

export function buildStructuredOfflineFallback(
  userMessage: string,
  ctx: LearningContextSummary,
  reason: string
): { content: string; errorReason: string } {
  const chosen = selectBestOfflineModule(userMessage, ctx);

  const content = `> **Offline Tutor Fallback Active (Not Live AI)**
> Live AI could not complete this turn (*${reason}*).
> **What works offline:** Curated CMAT lessons, formulas, worked examples, all timed quizzes & mock exams, flashcards, and your Error Log.
> **Offline limitations:** Cannot dynamically read newly uploaded PDFs or generate freeform custom essays until Live AI reconnects.

### ${chosen.section}: ${chosen.title}

${chosen.hinglishSummary}

#### Step-by-Step Worked Notes
${chosen.stepByStepExample}

---

${chosen.checkQuestion}

*Active Study State Preserved:* Day ${ctx.currentDay} · ${ctx.currentSubject} (${ctx.currentTopicTitle})

<<<FOLLOWUPS: ${JSON.stringify(chosen.followups)}>>>`;

  return {
    content,
    errorReason: reason,
  };
}
