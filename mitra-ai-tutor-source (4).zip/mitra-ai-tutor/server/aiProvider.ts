import fs from 'node:fs';
import path from 'node:path';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import type { GenerateContentResponse } from '@google/genai';
import { buildStructuredOfflineFallback } from './offlineTutor.ts';
import type {
  AIErrorCategory,
  AIProviderStatus,
  ChatAttachment,
  ExplanationDepth,
  ExplanationLanguage,
} from '../src/types/mitra.ts';

const DEPRECATED_MODELS = new Set([
  'gemini-1.5-flash',
  'gemini-1.5-pro',
  'gemini-pro',
  'gemini-2.0-flash',
  'gemini-2.0-pro',
  'gemini-2.0-flash-thinking',
]);

// Fast low-latency conversational default + deep reasoning option
const FAST_CONVERSATIONAL_MODEL = 'gemini-3.1-flash-lite';
const THINKING_TUTOR_MODEL = 'gemini-3.8-flash';
const DEFAULT_SUPPORTED_MODEL = FAST_CONVERSATIONAL_MODEL;

const FALLBACK_MODEL_CHAIN = [
  FAST_CONVERSATIONAL_MODEL,
  THINKING_TUTOR_MODEL,
  'gemini-flash-latest',
];

const PRESET_PAPER_PATHS: Record<string, { filePath: string; mimeType: string; label: string }> = {
  cmat_2025_slot_1: {
    filePath: path.resolve(process.cwd(), 'public/assets/aistudio/CMAT_2025_Slot_1_eb37672b.pdf'),
    mimeType: 'application/pdf',
    label: 'NTA CMAT Jan 2025 Slot 1 Official Paper (25 Jan 2025, 9 AM - 12 PM)',
  },
  cmat_2025_slot_2: {
    filePath: path.resolve(process.cwd(), 'public/assets/aistudio/CMAT_2025_Slot_2_10460396.pdf'),
    mimeType: 'application/pdf',
    label: 'NTA CMAT Jan 2025 Slot 2 Official Paper (25 Jan 2025, 3 PM - 6 PM)',
  },
};

const pdfBase64Cache = new Map<string, string>();

// Circuit Breaker: prevents hammering models that failed due to 404 (unsupported) or 429 (quota)
interface ModelCooldownState {
  untilMs: number;
  category: AIErrorCategory;
  reason: string;
}

const modelCooldownMap = new Map<string, ModelCooldownState>();

interface LiveVerificationSnapshot {
  verifiedLive: boolean;
  verifiedModel: string;
  lastVerifiedAt: string;
  probeLatencyMs: number;
  errorCategory: AIErrorCategory;
  diagnosticMessage: string;
  expiresAtMs: number;
}

let cachedLiveProbe: LiveVerificationSnapshot | null = null;

export function markModelCooldown(
  modelName: string,
  cooldownMs: number,
  category: AIErrorCategory,
  reason: string
): void {
  if (cooldownMs <= 0) return;
  modelCooldownMap.set(modelName, {
    untilMs: Date.now() + cooldownMs,
    category,
    reason,
  });
}

export function isModelInCooldown(modelName: string): boolean {
  const entry = modelCooldownMap.get(modelName);
  if (!entry) return false;
  if (Date.now() >= entry.untilMs) {
    modelCooldownMap.delete(modelName);
    return false;
  }
  return true;
}

export function getActiveCooldownModels(): string[] {
  const active: string[] = [];
  const now = Date.now();
  for (const [m, entry] of modelCooldownMap.entries()) {
    if (now < entry.untilMs) {
      active.push(m);
    } else {
      modelCooldownMap.delete(m);
    }
  }
  return active;
}

export function resetModelCooldownsForTest(): void {
  modelCooldownMap.clear();
  cachedLiveProbe = null;
}

function getApiKey(): string {
  return (process.env.GEMINI_API_KEY || '').trim();
}

export function resolveModelConfig(): {
  configuredRaw: string;
  activeModel: string;
  wasNormalizedFromDeprecated: boolean;
} {
  const configuredRaw = (process.env.GEMINI_MODEL || process.env.MODEL || '').trim();
  if (!configuredRaw) {
    return {
      configuredRaw: DEFAULT_SUPPORTED_MODEL,
      activeModel: DEFAULT_SUPPORTED_MODEL,
      wasNormalizedFromDeprecated: false,
    };
  }
  const lower = configuredRaw.toLowerCase();
  if (DEPRECATED_MODELS.has(lower)) {
    return {
      configuredRaw,
      activeModel: DEFAULT_SUPPORTED_MODEL,
      wasNormalizedFromDeprecated: true,
    };
  }
  return {
    configuredRaw,
    activeModel: configuredRaw,
    wasNormalizedFromDeprecated: false,
  };
}

export interface ClassifiedProviderError {
  category: AIErrorCategory;
  userMessage: string;
  isRetryableSameModel: boolean;
  shouldFailoverModel: boolean;
  cooldownMs: number;
}

export function classifyProviderError(err: unknown): ClassifiedProviderError {
  const raw = err instanceof Error ? err.message : String(err);
  const lower = raw.toLowerCase();

  if (
    raw.includes('401') ||
    raw.includes('403') ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    lower.includes('permission_denied') ||
    lower.includes('unauthenticated')
  ) {
    return {
      category: 'auth_invalid',
      userMessage:
        'Live AI authentication failed. Check that GEMINI_API_KEY in Settings > Secrets is valid and active.',
      isRetryableSameModel: false,
      shouldFailoverModel: false,
      cooldownMs: 0,
    };
  }

  if (
    raw.includes('404') ||
    lower.includes('not_found') ||
    lower.includes('not found') ||
    lower.includes('is not supported for generatecontent') ||
    lower.includes('unsupported model')
  ) {
    return {
      category: 'model_unsupported',
      userMessage:
        'The requested model is unavailable for this API key/region; switching to a verified supported model.',
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 15 * 60 * 1000, // 15-minute circuit breaker cooldown so we don't retry dead models
    };
  }

  if (
    raw.includes('429') ||
    lower.includes('resource_exhausted') ||
    lower.includes('quota') ||
    lower.includes('rate limit')
  ) {
    return {
      category: 'quota_exhausted',
      userMessage:
        'Gemini API quota or rate limit reached on this model. Failing over or cooling down briefly before retry.',
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 60 * 1000, // 60-second cooldown on rate-limited model
    };
  }

  if (
    lower.includes('timed out') ||
    lower.includes('timeout') ||
    lower.includes('deadline_exceeded') ||
    lower.includes('aborted')
  ) {
    return {
      category: 'timeout',
      userMessage: 'Live AI model timed out waiting for response; switching to faster backup model.',
      isRetryableSameModel: false,
      shouldFailoverModel: true,
      cooldownMs: 30 * 1000,
    };
  }

  return {
    category: 'network_error',
    userMessage: raw.slice(0, 220) || 'Temporary network interruption reaching the AI provider.',
    isRetryableSameModel: true,
    shouldFailoverModel: true,
    cooldownMs: 10 * 1000,
  };
}

export function getAIProviderStatus(): AIProviderStatus {
  const apiKey = getApiKey();
  const hasValidKey = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY');
  const { configuredRaw, activeModel, wasNormalizedFromDeprecated } = resolveModelConfig();
  const cooldownModels = getActiveCooldownModels();

  if (!hasValidKey) {
    return {
      liveAvailable: false,
      verifiedLive: false,
      errorCategory: 'missing_key',
      cooldownModels,
      provider: 'Google Gemini (@google/genai)',
      configuredModel: configuredRaw,
      activeModel,
      endpointType: 'Server-side SSE Stream & Voice Adapter (/api/chat/stream)',
      authConfigured: false,
      fallbackModeLabel: 'Offline Tutor Fallback',
      diagnosticMessage:
        'GEMINI_API_KEY is not configured on the server. Structured Offline Tutor mode is active until a key is attached in Settings > Secrets.',
    };
  }

  if (cachedLiveProbe && Date.now() < cachedLiveProbe.expiresAtMs) {
    return {
      liveAvailable: cachedLiveProbe.verifiedLive,
      verifiedLive: cachedLiveProbe.verifiedLive,
      lastVerifiedAt: cachedLiveProbe.lastVerifiedAt,
      probeLatencyMs: cachedLiveProbe.probeLatencyMs,
      errorCategory: cachedLiveProbe.errorCategory,
      cooldownModels,
      provider: 'Google Gemini (@google/genai)',
      configuredModel: configuredRaw,
      activeModel: cachedLiveProbe.verifiedModel || activeModel,
      endpointType: 'Server-side SSE Stream & Voice Adapter (/api/chat/stream)',
      authConfigured: cachedLiveProbe.errorCategory !== 'auth_invalid',
      fallbackModeLabel: 'Offline Tutor Fallback',
      diagnosticMessage: cachedLiveProbe.diagnosticMessage,
    };
  }

  // Pick first non-cooled-down model
  const candidateChain = Array.from(new Set([activeModel, ...FALLBACK_MODEL_CHAIN]));
  const healthyModel = candidateChain.find((m) => !isModelInCooldown(m)) || activeModel;

  let diagnosticMessage = `Live AI configured via @google/genai (${healthyModel}). Click "Verify Live AI" to run a real API probe.`;
  if (wasNormalizedFromDeprecated) {
    diagnosticMessage = `Deprecated model "${configuredRaw}" was normalized to supported model "${healthyModel}".`;
  }

  return {
    liveAvailable: true,
    verifiedLive: cachedLiveProbe?.verifiedLive,
    lastVerifiedAt: cachedLiveProbe?.lastVerifiedAt,
    probeLatencyMs: cachedLiveProbe?.probeLatencyMs,
    errorCategory: 'none',
    cooldownModels,
    provider: 'Google Gemini (@google/genai)',
    configuredModel: configuredRaw,
    activeModel: healthyModel,
    endpointType: 'Server-side SSE Stream & Voice Adapter (/api/chat/stream)',
    authConfigured: true,
    fallbackModeLabel: 'Offline Tutor Fallback',
    diagnosticMessage,
  };
}

function createGenAIClient(): GoogleGenAI {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is missing on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * Verifies real live model availability against the configured API key with an actual
 * lightweight generateContent probe, recording latency and circuit-breaker state.
 */
export async function verifyLiveModelAccess(forceRefresh = false): Promise<AIProviderStatus> {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return getAIProviderStatus();
  }

  if (!forceRefresh && cachedLiveProbe && Date.now() < cachedLiveProbe.expiresAtMs) {
    return getAIProviderStatus();
  }

  const ai = createGenAIClient();
  const { activeModel } = resolveModelConfig();
  const candidates = Array.from(new Set([activeModel, ...FALLBACK_MODEL_CHAIN]));

  let lastCategory: AIErrorCategory = 'network_error';
  let lastMessage = 'All candidate models failed live verification.';

  for (const modelName of candidates) {
    if (!forceRefresh && isModelInCooldown(modelName)) {
      continue;
    }

    const t0 = Date.now();
    const probeAbort = new AbortController();
    const timer = setTimeout(() => probeAbort.abort(), 6500);

    try {
      const thinkingCfg =
        modelName === 'gemini-3.1-flash-lite'
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } }
          : modelName.startsWith('gemini-3')
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
          : {};

      const response = await ai.models.generateContent({
        model: modelName,
        contents: 'Reply with the single word READY.',
        config: {
          abortSignal: probeAbort.signal,
          ...thinkingCfg,
        },
      });
      clearTimeout(timer);

      const text = (response.text || '').trim();
      if (!text) {
        throw new Error('Empty response during model verification probe.');
      }

      const latency = Date.now() - t0;
      const nowIso = new Date().toISOString();
      cachedLiveProbe = {
        verifiedLive: true,
        verifiedModel: modelName,
        lastVerifiedAt: nowIso,
        probeLatencyMs: latency,
        errorCategory: 'none',
        diagnosticMessage: `Verified live model access on "${modelName}" in ${latency}ms.`,
        expiresAtMs: Date.now() + 5 * 60 * 1000,
      };
      modelCooldownMap.delete(modelName);
      return getAIProviderStatus();
    } catch (err) {
      clearTimeout(timer);
      const classified = classifyProviderError(err);
      lastCategory = classified.category;
      lastMessage = classified.userMessage;
      if (classified.cooldownMs > 0) {
        markModelCooldown(modelName, classified.cooldownMs, classified.category, classified.userMessage);
      }
      if (!classified.shouldFailoverModel) {
        break;
      }
    }
  }

  cachedLiveProbe = {
    verifiedLive: false,
    verifiedModel: activeModel,
    lastVerifiedAt: new Date().toISOString(),
    probeLatencyMs: 0,
    errorCategory: lastCategory,
    diagnosticMessage: `Live AI verification failed (${lastCategory}): ${lastMessage}`,
    expiresAtMs: Date.now() + 30 * 1000,
  };
  return getAIProviderStatus();
}

export type ConversationTone = 'friend' | 'coach';

export interface LearningContextSummary {
  preferredLanguage: ExplanationLanguage;
  explanationDepth: ExplanationDepth;
  conversationTone?: ConversationTone;
  currentDay: number;
  currentSubject: string;
  currentTopicTitle: string;
  studyMinutesToday: number;
  completedTopics: string[];
  pendingAssessments: string[];
  quizSummary: string[];
  unresolvedMistakes: string[];
}

export function buildMitraSystemInstruction(ctx: LearningContextSummary): string {
  const isFriendTone = (ctx.conversationTone || 'friend') === 'friend';

  const langGuide =
    ctx.preferredLanguage === 'hindi'
      ? 'Talk primarily in warm, natural, everyday spoken Hindi (not stiff textbook Hindi), while always mirroring whatever language the user writes in.'
      : ctx.preferredLanguage === 'english'
      ? 'Talk in warm, relaxed, natural conversational English (like a smart close friend), unless the user writes in Hindi or Hinglish—in which case mirror their language effortlessly.'
      : 'Talk in natural, everyday Hinglish—the exact way smart Indian college friends chat with each other (warm Hindi flow + crisp English math/exam words)—and always mirror whichever language (Hinglish, English, or Hindi) and level of informality ("tu/tum/yaar" vs "aap") the user uses.';

  const vibeGuide = isFriendTone
    ? `**Talk Like a Real Smart Best Friend ("Mitra" = Dost), NEVER Like a Stiff Textbook or Formal Lecturer:**
   - Sound human, relaxed, warm, and genuinely invested in your friend. Use natural conversational connectors (e.g., in Hinglish: *"Arre tension mat le yaar"*, *"Dekh kitna simple hai"*, *"Soch ke dekh..."*, *"Pakad liya na logic?"*, *"Ekdum sahi ja raha hai!"*; or in English: *"Hey, don't stress this one at all"*, *"Think of it like this..."*, *"Ooh, super close!"*, *"Makes sense so far?"*).
   - **Read the room & match their energy:**
     - If your friend just says *"hi"*, *"hey"*, *"kya haal hai"*, *"thak gaya hoon"*, *"exam se dar lag raha hai"*, or chats casually -> **just chat back warmly like a real friend in 2–4 short lines!** Check in on how they're doing and ask what they feel like doing—NEVER dump a syllabus table or 10 bullet points when someone just says hello!
     - When explaining any concept -> start from absolute basics if needed, using a relatable everyday example (splitting a pizza/chai bill, cricket run rate, shopping discount, train ride) BEFORE introducing any formula.
     - Avoid robotic textbook headings like \`### 1. Conceptual Overview\` in casual turns. Let your explanation breathe in short paragraphs with crystal-clear step-by-step calculations.`
    : `**Supportive Exam Coach Tone:** Keep your tone encouraging, clear, structured, and crisp—like a dedicated 1-on-1 CMAT mentor focused on accuracy, speed shortcuts, and step-by-step clarity.`;

  const depthGuide =
    ctx.explanationDepth === 'concise'
      ? 'Keep each reply short, snappy, and conversational (2–4 brief paragraphs max) while still showing key calculation steps.'
      : 'Start from absolute zero basics whenever a topic feels new or tricky: define unfamiliar terms first, show EVERY intermediate arithmetic step clearly, and explain WHY each shortcut works.';

  return `You are **Mitra** (literally "Friend"), the student's warm, intelligent best friend AND rigorous personal **CMAT 2026** tutor.

### Core Teaching & Conversational Rules
1. ${vibeGuide}
2. **Language:** ${langGuide}
3. **Step-by-Step Clarity:** ${depthGuide}
4. **Interactive One-Question-at-a-Time Practice & Adaptive Difficulty:**
   - When teaching or drilling interactively in chat, give **ONLY ONE practice question at a time** (with options \`(A)\`, \`(B)\`, \`(C)\`, \`(D)\` when appropriate) and wait for the student's answer—never dump 5 ungraded questions at once unless explicitly asked for a worksheet.
   - **Wrong-Answer Diagnostics:** Whenever the student picks a wrong option or makes a calculation slip, NEVER give fake praise or skip straight to the final answer. Explicitly explain **why their chosen option/step went wrong** (e.g., base-shift trap, sign slip, LCM error), show the clean step-by-step fix, and immediately give **1 slightly easier or parallel remedial check** to confirm mastery.
   - **Adaptive Progression:** If the student answers accurately and quickly, step up to intermediate/advanced NTA CMAT PYQ difficulty; if they struggle, simplify and break the concept down further.
5. **Honest Learning State & Source Attribution:**
   - Distinguish strictly between a lesson being **viewed**, a quiz being **attempted**, a quiz being **passed**, and a topic being **mastered**. Never claim a pending assessment is completed.
   - Cite exact Slot & Question numbers when referencing attached **NTA CMAT Jan 2025 Slot 1 or Slot 2** papers; label newly created practice questions as *Mitra Practice Question*.
   - Format mathematical steps cleanly with KaTeX ($...$ inline, $$...$$ display).
6. **Contextual Quick-Reply Suggestions:**
   - At the very end of EVERY reply, on a new final line, append 3 short, natural reply options (max 6 words each, in the student's voice) in this exact format:
     \`<<<FOLLOWUPS: ["First reply", "Second reply", "Third reply"]>>>\`

### Student's Live Learning Context (Use Naturally for Continuity — Don't Recite Robotically Unless Asked)
- **Current Study Day:** Day ${ctx.currentDay} (${ctx.studyMinutesToday} / 120 mins studied today)
- **Active Topic:** ${ctx.currentSubject} — ${ctx.currentTopicTitle}
- **Completed / Mastered:** ${ctx.completedTopics.length ? ctx.completedTopics.join('; ') : 'None yet'}
- **Viewed / Pending Assessments (NOT yet mastered):** ${ctx.pendingAssessments.length ? ctx.pendingAssessments.join('; ') : 'None pending'}
- **Verified Quiz History:** ${ctx.quizSummary.length ? ctx.quizSummary.join(' | ') : 'None yet'}
- **Unresolved Mistake Notebook:** ${ctx.unresolvedMistakes.length ? ctx.unresolvedMistakes.join(' || ') : 'None'}`;
}

function loadAttachmentPart(
  attachment: ChatAttachment,
  uploadsDir: string
): { inlineData?: { mimeType: string; data: string }; text?: string } | null {
  try {
    if (attachment.presetPaperId && PRESET_PAPER_PATHS[attachment.presetPaperId]) {
      const preset = PRESET_PAPER_PATHS[attachment.presetPaperId];
      if (!fs.existsSync(preset.filePath)) return null;
      let b64 = pdfBase64Cache.get(attachment.presetPaperId);
      if (!b64) {
        b64 = fs.readFileSync(preset.filePath).toString('base64');
        pdfBase64Cache.set(attachment.presetPaperId, b64);
      }
      return {
        inlineData: {
          mimeType: preset.mimeType,
          data: b64,
        },
      };
    }

    if (attachment.uploadedFileId) {
      const safeId = path.basename(attachment.uploadedFileId);
      const fullPath = path.join(uploadsDir, safeId);
      if (!fs.existsSync(fullPath)) return null;
      const mime = attachment.mimeType || 'application/octet-stream';
      const buffer = fs.readFileSync(fullPath);

      if (mime === 'application/pdf' || mime.startsWith('image/')) {
        return {
          inlineData: {
            mimeType: mime,
            data: buffer.toString('base64'),
          },
        };
      }

      const rawText = buffer.toString('utf-8').slice(0, 45000);
      return {
        text: `[Uploaded Document: ${attachment.name}]\n\`\`\`\n${rawText}\n\`\`\``,
      };
    }
  } catch (err) {
    console.error('Attachment load error:', err);
  }
  return null;
}

export interface ConversationTurnInput {
  role: 'user' | 'assistant';
  content: string;
  attachments?: ChatAttachment[];
}

function stripFollowupsMarker(text: string): string {
  return text.replace(/<<<FOLLOWUPS:\s*\[[\s\S]*?\]\s*>>>/g, '').trim();
}

function buildGeminiContents(
  history: ConversationTurnInput[],
  uploadsDir: string
): Array<{ role: 'user' | 'model'; parts: Array<Record<string, unknown>> }> {
  const recent = history.slice(-24);
  const contents: Array<{ role: 'user' | 'model'; parts: Array<Record<string, unknown>> }> = [];
  const attachedPdfPresetAlready = new Set<string>();

  for (let i = 0; i < recent.length; i++) {
    const msg = recent[i];
    const role: 'user' | 'model' = msg.role === 'assistant' ? 'model' : 'user';
    const parts: Array<Record<string, unknown>> = [];

    if (role === 'user' && msg.attachments && msg.attachments.length > 0) {
      const isRecentAttachmentTurn = i >= recent.length - 4;
      for (const att of msg.attachments) {
        const key = att.presetPaperId || att.uploadedFileId || att.name;
        if (isRecentAttachmentTurn && !attachedPdfPresetAlready.has(key)) {
          const part = loadAttachmentPart(att, uploadsDir);
          if (part) {
            parts.push(part);
            attachedPdfPresetAlready.add(key);
          }
        } else {
          parts.push({ text: `[Referenced Attachment: ${att.name}]` });
        }
      }
    }

    const cleanedContent = role === 'model' ? stripFollowupsMarker(msg.content) : msg.content;
    parts.push({ text: cleanedContent || ' ' });
    contents.push({ role, parts });
  }

  return contents;
}

export function buildOfflineTutorFallback(
  userMessage: string,
  ctx: LearningContextSummary,
  reason: string
): { content: string; errorReason: string } {
  return buildStructuredOfflineFallback(userMessage, ctx, reason);
}

async function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function streamTutorResponse(params: {
  history: ConversationTurnInput[];
  learningContext: LearningContextSummary;
  uploadsDir: string;
  modelTier?: 'fast' | 'thinking';
  signal?: AbortSignal;
  onChunk: (deltaText: string, modelUsed: string) => void;
}): Promise<{
  fullText: string;
  sourceMode: 'live' | 'offline';
  modelUsed: string;
  errorReason?: string;
  errorCategory?: AIErrorCategory;
}> {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    const lastUser = params.history[params.history.length - 1]?.content || '';
    const offline = buildOfflineTutorFallback(
      lastUser,
      params.learningContext,
      'GEMINI_API_KEY is missing in server environment.'
    );
    params.onChunk(offline.content, 'offline-fallback');
    return {
      fullText: offline.content,
      sourceMode: 'offline',
      modelUsed: 'offline-fallback',
      errorReason: offline.errorReason,
      errorCategory: 'missing_key',
    };
  }

  const ai = createGenAIClient();
  const systemInstruction = buildMitraSystemInstruction(params.learningContext);
  const contents = buildGeminiContents(params.history, params.uploadsDir);
  const { activeModel } = resolveModelConfig();

  const preferredPrimary =
    params.modelTier === 'thinking'
      ? THINKING_TUTOR_MODEL
      : params.modelTier === 'fast'
      ? FAST_CONVERSATIONAL_MODEL
      : activeModel;

  const allCandidates = Array.from(new Set([preferredPrimary, ...FALLBACK_MODEL_CHAIN]));
  // Filter out models currently in circuit-breaker cooldown; if all are cooling down, try the primary once
  const healthyCandidates = allCandidates.filter((m) => !isModelInCooldown(m));
  const candidateModels = healthyCandidates.length > 0 ? healthyCandidates : [preferredPrimary];

  let lastErrorMsg = 'Temporary AI provider failure.';
  let lastCategory: AIErrorCategory = 'network_error';

  for (let mIdx = 0; mIdx < candidateModels.length; mIdx++) {
    const modelName = candidateModels[mIdx];
    const maxAttempts = mIdx === 0 ? 1 : 2;

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      if (params.signal?.aborted) {
        throw new Error('ABORTED_BY_USER');
      }

      const attemptAbort = new AbortController();
      let timedOutWaitingForFirstChunk = false;
      const timeoutMs = modelName === THINKING_TUTOR_MODEL ? 13000 : 9500;
      const t0 = Date.now();
      const firstChunkTimer = setTimeout(() => {
        timedOutWaitingForFirstChunk = true;
        attemptAbort.abort();
      }, timeoutMs);

      const onUserAbort = () => attemptAbort.abort();
      params.signal?.addEventListener('abort', onUserAbort, { once: true });

      try {
        const thinkingCfg =
          modelName === 'gemini-3.1-flash-lite'
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } }
            : modelName.startsWith('gemini-3')
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
            : {};

        const stream = await ai.models.generateContentStream({
          model: modelName,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
            abortSignal: attemptAbort.signal,
            ...thinkingCfg,
          },
        });

        let accumulated = '';
        let firstChunkLatency = 0;
        for await (const chunk of stream) {
          clearTimeout(firstChunkTimer);
          if (!firstChunkLatency) {
            firstChunkLatency = Date.now() - t0;
          }
          if (params.signal?.aborted) {
            break;
          }
          const c = chunk as GenerateContentResponse;
          const piece = c.text || '';
          if (piece) {
            accumulated += piece;
            params.onChunk(piece, modelName);
          }
        }
        clearTimeout(firstChunkTimer);
        params.signal?.removeEventListener('abort', onUserAbort);

        if (accumulated.trim().length > 0 || params.signal?.aborted) {
          modelCooldownMap.delete(modelName);
          cachedLiveProbe = {
            verifiedLive: true,
            verifiedModel: modelName,
            lastVerifiedAt: new Date().toISOString(),
            probeLatencyMs: firstChunkLatency || Date.now() - t0,
            errorCategory: 'none',
            diagnosticMessage: `Live streaming verified on "${modelName}" (${firstChunkLatency || Date.now() - t0}ms TTFT).`,
            expiresAtMs: Date.now() + 5 * 60 * 1000,
          };
          return {
            fullText: accumulated,
            sourceMode: 'live',
            modelUsed: modelName,
            errorCategory: 'none',
          };
        }
        throw new Error('Model returned an empty response stream.');
      } catch (err) {
        clearTimeout(firstChunkTimer);
        params.signal?.removeEventListener('abort', onUserAbort);

        if (params.signal?.aborted || (err instanceof Error && err.message === 'ABORTED_BY_USER')) {
          throw new Error('ABORTED_BY_USER');
        }

        if (timedOutWaitingForFirstChunk) {
          lastCategory = 'timeout';
          lastErrorMsg = `Model "${modelName}" timed out after ${timeoutMs}ms waiting for initial stream chunk.`;
          markModelCooldown(modelName, 30 * 1000, 'timeout', lastErrorMsg);
          break;
        }

        const classified = classifyProviderError(err);
        lastErrorMsg = classified.userMessage;
        lastCategory = classified.category;

        if (classified.cooldownMs > 0) {
          markModelCooldown(modelName, classified.cooldownMs, classified.category, classified.userMessage);
        }

        if (!classified.shouldFailoverModel) {
          // Non-recoverable auth error: stop trying other models immediately
          mIdx = candidateModels.length;
          break;
        }

        if (!classified.isRetryableSameModel) {
          break;
        }

        if (attempt === 0 && maxAttempts > 1) {
          await sleep(350);
        }
      }
    }
  }

  cachedLiveProbe = {
    verifiedLive: false,
    verifiedModel: preferredPrimary,
    lastVerifiedAt: new Date().toISOString(),
    probeLatencyMs: 0,
    errorCategory: lastCategory,
    diagnosticMessage: `Live AI paused (${lastCategory}): ${lastErrorMsg}`,
    expiresAtMs: Date.now() + 25 * 1000,
  };

  const lastUser = params.history[params.history.length - 1]?.content || '';
  const offline = buildOfflineTutorFallback(lastUser, params.learningContext, lastErrorMsg);
  params.onChunk(offline.content, 'offline-fallback');
  return {
    fullText: offline.content,
    sourceMode: 'offline',
    modelUsed: 'offline-fallback',
    errorReason: offline.errorReason,
    errorCategory: lastCategory,
  };
}

export async function generateTutorActionText(params: {
  prompt: string;
  learningContext: LearningContextSummary;
  attachments?: ChatAttachment[];
  uploadsDir: string;
}): Promise<{
  text: string;
  sourceMode: 'live' | 'offline';
  modelUsed: string;
  errorReason?: string;
  errorCategory?: AIErrorCategory;
}> {
  let finalOut = '';
  const result = await streamTutorResponse({
    history: [
      {
        role: 'user',
        content: params.prompt,
        attachments: params.attachments,
      },
    ],
    learningContext: params.learningContext,
    uploadsDir: params.uploadsDir,
    modelTier: 'fast',
    onChunk: (delta) => {
      finalOut += delta;
    },
  });

  return {
    text: stripFollowupsMarker(result.fullText || finalOut),
    sourceMode: result.sourceMode,
    modelUsed: result.modelUsed,
    errorReason: result.errorReason,
    errorCategory: result.errorCategory,
  };
}

export async function transcribeStudentAudio(params: {
  audioBase64: string;
  mimeType: string;
}): Promise<{ text: string }> {
  const ai = createGenAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3.5-transcribe',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: params.mimeType || 'audio/webm',
            data: params.audioBase64,
          },
        },
        {
          text: 'Transcribe the student speech accurately. Keep Hindi, Hinglish, English words, numbers, and mathematical expressions cleanly readable. Output only the spoken transcript without extra commentary.',
        },
      ],
    },
  });

  return {
    text: (response.text || '').trim(),
  };
}

function cleanMarkdownForSpeech(markdown: string): string {
  return stripFollowupsMarker(markdown)
    .replace(/```[\s\S]*?```/g, ' See the code or calculation block on screen. ')
    .replace(/\$\$([\s\S]*?)\$\$/g, ' $1 ')
    .replace(/\$([^$\n]+)\$/g, ' $1 ')
    .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, '$1 over $2')
    .replace(/\\times/g, ' times ')
    .replace(/\\div/g, ' divided by ')
    .replace(/\\rightarrow/g, ' gives ')
    .replace(/[#>*_`~|]/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 1600);
}

export async function synthesizeTutorSpeech(params: {
  text: string;
}): Promise<{ audioBase64: string; mimeType: string }> {
  const spokenText = cleanMarkdownForSpeech(params.text);
  if (!spokenText) {
    throw new Error('No readable text provided for speech synthesis.');
  }

  const ai = createGenAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash-lite-tts',
    contents: [
      {
        role: 'user',
        parts: [
          {
            text: spokenText,
            speechMetadata: {
              style: 'Warm, upbeat, relaxed close friend and study buddy chatting naturally',
            },
          } as Record<string, unknown>,
        ],
      },
    ],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Puck' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error('Speech synthesis did not return audio data.');
  }

  return {
    audioBase64: base64Audio,
    mimeType: 'audio/wav',
  };
}
