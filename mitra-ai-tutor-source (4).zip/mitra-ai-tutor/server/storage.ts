import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  INITIAL_USER_PROFILE,
  INITIAL_TOPIC_PROGRESS,
  INITIAL_QUIZ_ATTEMPTS,
  INITIAL_ERROR_LOG,
  INITIAL_NOTES,
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
} from '../src/data/cmatCurriculum.ts';
import type {
  UserLearningProfile,
  ConversationThread,
  ChatMessageItem,
  TopicProgressRecord,
  QuizAttemptRecord,
  ErrorLogRecord,
  StudyNoteRecord,
  ChatAttachment,
} from '../src/types/mitra.ts';

export interface ServerWorkspaceStore {
  ownerPrincipalId: string;
  profile: UserLearningProfile;
  conversations: ConversationThread[];
  messagesByConversation: Record<string, ChatMessageItem[]>;
  topicProgress: TopicProgressRecord[];
  quizAttempts: QuizAttemptRecord[];
  errorLog: ErrorLogRecord[];
  notes: StudyNoteRecord[];
  uploadedDocuments: ChatAttachment[];
}

export class ForbiddenOwnershipError extends Error {
  public readonly statusCode = 403;
  constructor(message = 'Forbidden: Resource belongs to a different user workspace.') {
    super(message);
    this.name = 'ForbiddenOwnershipError';
  }
}

const IS_SERVERLESS_RUNTIME =
  Boolean(process.env.VERCEL) || Boolean(process.env.AWS_LAMBDA_FUNCTION_NAME);
const DATA_DIR = IS_SERVERLESS_RUNTIME
  ? path.join(os.tmpdir(), 'mitra-data')
  : path.resolve(process.cwd(), 'data');
const PRINCIPALS_DIR = path.join(DATA_DIR, 'principals');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

function ensureDirs() {
  if (!fs.existsSync(PRINCIPALS_DIR)) {
    fs.mkdirSync(PRINCIPALS_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

function hashPrincipalKey(principalId: string): string {
  return crypto.createHash('sha256').update(principalId).digest('hex').slice(0, 32);
}

export function getPrincipalUploadsDir(principalId: string): string {
  ensureDirs();
  const dir = path.join(UPLOADS_DIR, hashPrincipalKey(principalId));
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

function getPrincipalStorePath(principalId: string): string {
  return path.join(PRINCIPALS_DIR, `${hashPrincipalKey(principalId)}.json`);
}

function createInitialStoreForPrincipal(principalId: string): ServerWorkspaceStore {
  const shortSuffix = hashPrincipalKey(principalId).slice(0, 8);
  const seededConvs = structuredClone(INITIAL_CONVERSATIONS).map((c) => ({
    ...c,
    id: `${c.id}_${shortSuffix}`,
  }));
  const seededMessages: Record<string, ChatMessageItem[]> = {};
  for (let i = 0; i < INITIAL_CONVERSATIONS.length; i++) {
    const origId = INITIAL_CONVERSATIONS[i].id;
    const scopedId = seededConvs[i].id;
    seededMessages[scopedId] = (structuredClone(INITIAL_MESSAGES[origId]) || []).map((m) => ({
      ...m,
      id: `${m.id}_${shortSuffix}`,
      conversationId: scopedId,
    }));
  }

  return {
    ownerPrincipalId: principalId,
    profile: {
      ...structuredClone(INITIAL_USER_PROFILE),
      ownerId: principalId,
    },
    conversations: seededConvs,
    messagesByConversation: seededMessages,
    topicProgress: structuredClone(INITIAL_TOPIC_PROGRESS),
    quizAttempts: structuredClone(INITIAL_QUIZ_ATTEMPTS),
    errorLog: structuredClone(INITIAL_ERROR_LOG),
    notes: structuredClone(INITIAL_NOTES),
    uploadedDocuments: [],
  };
}

const memoryStores = new Map<string, ServerWorkspaceStore>();
// Tracks globally created conversation IDs -> owning principalId to enforce 403 on cross-user access
const conversationOwnerRegistry = new Map<string, string>();
const noteOwnerRegistry = new Map<string, string>();
const errorOwnerRegistry = new Map<string, string>();

function registerOwnership(store: ServerWorkspaceStore) {
  for (const c of store.conversations) {
    conversationOwnerRegistry.set(c.id, store.ownerPrincipalId);
  }
  for (const n of store.notes) {
    noteOwnerRegistry.set(n.id, store.ownerPrincipalId);
  }
  for (const e of store.errorLog) {
    errorOwnerRegistry.set(e.id, store.ownerPrincipalId);
  }
}

export function assertConversationOwnership(principalId: string, conversationId: string): void {
  const knownOwner = conversationOwnerRegistry.get(conversationId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError('Access denied: Conversation belongs to another student.');
  }
}

export function assertNoteOwnership(principalId: string, noteId: string): void {
  const knownOwner = noteOwnerRegistry.get(noteId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError('Access denied: Study note belongs to another student.');
  }
}

export function assertErrorItemOwnership(principalId: string, errorId: string): void {
  const knownOwner = errorOwnerRegistry.get(errorId);
  if (knownOwner && knownOwner !== principalId) {
    throw new ForbiddenOwnershipError('Access denied: Error log item belongs to another student.');
  }
}

/**
 * Retrieves the strictly isolated workspace store for a single authenticated principal.
 * Cloud Firebase principals ("firebase:<uid>") keep durable data in Firestore and only hold
 * isolated per-UID memory state on the server (never persisted to shared disk files).
 * Isolated guest principals ("guest:<sessionId>") persist only to their hashed session file.
 */
export function getStore(principalId: string): ServerWorkspaceStore {
  if (!principalId || typeof principalId !== 'string') {
    throw new Error('principalId is required to access workspace storage.');
  }
  ensureDirs();

  const cached = memoryStores.get(principalId);
  if (cached) return cached;

  const isCloudFirebaseUser = principalId.startsWith('firebase:');
  if (!isCloudFirebaseUser) {
    const filePath = getPrincipalStorePath(principalId);
    if (fs.existsSync(filePath)) {
      try {
        const raw = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw) as ServerWorkspaceStore;
        if (
          parsed &&
          parsed.ownerPrincipalId === principalId &&
          parsed.profile &&
          Array.isArray(parsed.topicProgress)
        ) {
          memoryStores.set(principalId, parsed);
          registerOwnership(parsed);
          return parsed;
        }
      } catch (err) {
        console.error('Isolated principal store read error, re-initializing:', err);
      }
    }
  }

  const fresh = createInitialStoreForPrincipal(principalId);
  saveStore(principalId, fresh);
  return fresh;
}

export function saveStore(principalId: string, store: ServerWorkspaceStore): void {
  ensureDirs();
  store.ownerPrincipalId = principalId;
  memoryStores.set(principalId, store);
  registerOwnership(store);

  // Cloud-authenticated Firebase users store durable state in Firestore (ai-studio-mitraaitutor-...),
  // never writing private student records to shared local JSON files.
  if (principalId.startsWith('firebase:')) {
    return;
  }

  const filePath = getPrincipalStorePath(principalId);
  const tmpPath = `${filePath}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(store, null, 2), 'utf-8');
  fs.renameSync(tmpPath, filePath);
}

export function updateProfile(
  principalId: string,
  patch: Partial<UserLearningProfile>
): UserLearningProfile {
  const store = getStore(principalId);
  const safePatch: Partial<UserLearningProfile> = {};
  if (typeof patch.displayName === 'string') safePatch.displayName = patch.displayName.slice(0, 100);
  if (patch.preferredLanguage && ['hinglish', 'english', 'hindi'].includes(patch.preferredLanguage)) {
    safePatch.preferredLanguage = patch.preferredLanguage;
  }
  if (patch.explanationDepth && ['step_by_step', 'concise'].includes(patch.explanationDepth)) {
    safePatch.explanationDepth = patch.explanationDepth;
  }
  if (typeof patch.currentDay === 'number' && Number.isFinite(patch.currentDay)) {
    safePatch.currentDay = Math.max(1, Math.min(365, Math.round(patch.currentDay)));
  }
  if (typeof patch.currentSubject === 'string') {
    safePatch.currentSubject = patch.currentSubject.slice(0, 80) as UserLearningProfile['currentSubject'];
  }
  if (typeof patch.currentTopicId === 'string') {
    safePatch.currentTopicId = patch.currentTopicId.slice(0, 128);
  }
  if (typeof patch.studyMinutesToday === 'number' && Number.isFinite(patch.studyMinutesToday)) {
    safePatch.studyMinutesToday = Math.max(0, Math.min(1440, Math.round(patch.studyMinutesToday)));
  }
  if (typeof patch.totalStudyMinutes === 'number' && Number.isFinite(patch.totalStudyMinutes)) {
    safePatch.totalStudyMinutes = Math.max(0, Math.min(500000, Math.round(patch.totalStudyMinutes)));
  }
  if (typeof patch.missedDaysOffset === 'number' && Number.isFinite(patch.missedDaysOffset)) {
    safePatch.missedDaysOffset = Math.max(0, Math.min(60, Math.round(patch.missedDaysOffset)));
  }

  store.profile = {
    ...store.profile,
    ...safePatch,
    ownerId: principalId,
    updatedAt: new Date().toISOString(),
  };
  saveStore(principalId, store);
  return store.profile;
}

export function createConversation(
  principalId: string,
  title?: string,
  subjectTag?: string
): ConversationThread {
  const store = getStore(principalId);
  const now = new Date().toISOString();
  const conv: ConversationThread = {
    id: `conv_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
    title: (title || 'New Tutoring Session').slice(0, 160),
    subjectTag: (subjectTag || store.profile.currentSubject || 'General Tutoring').slice(0, 80),
    archived: false,
    messageCount: 0,
    lastMessagePreview: '',
    createdAt: now,
    updatedAt: now,
  };
  store.conversations.unshift(conv);
  store.messagesByConversation[conv.id] = [];
  conversationOwnerRegistry.set(conv.id, principalId);
  saveStore(principalId, store);
  return conv;
}

export function updateConversationMeta(
  principalId: string,
  conversationId: string,
  patch: Partial<Pick<ConversationThread, 'title' | 'archived' | 'subjectTag'>>
): ConversationThread | null {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const idx = store.conversations.findIndex((c) => c.id === conversationId);
  if (idx === -1) return null;
  store.conversations[idx] = {
    ...store.conversations[idx],
    ...(patch.title !== undefined ? { title: String(patch.title).slice(0, 160) } : {}),
    ...(patch.archived !== undefined ? { archived: Boolean(patch.archived) } : {}),
    ...(patch.subjectTag !== undefined ? { subjectTag: String(patch.subjectTag).slice(0, 80) } : {}),
    updatedAt: new Date().toISOString(),
  };
  saveStore(principalId, store);
  return store.conversations[idx];
}

export function deleteConversation(principalId: string, conversationId: string): boolean {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const before = store.conversations.length;
  store.conversations = store.conversations.filter((c) => c.id !== conversationId);
  delete store.messagesByConversation[conversationId];
  if (store.conversations.length < before) {
    conversationOwnerRegistry.delete(conversationId);
  }
  saveStore(principalId, store);
  return store.conversations.length < before;
}

export function appendMessage(
  principalId: string,
  conversationId: string,
  message: Omit<ChatMessageItem, 'id' | 'conversationId' | 'createdAt'> & { id?: string }
): ChatMessageItem {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  let conv = store.conversations.find((c) => c.id === conversationId);
  if (!conv) {
    // Allow Cloud Firestore conversations hydrated on client to initialize cleanly for this principal
    const now = new Date().toISOString();
    conv = {
      id: conversationId,
      title: 'Study Session',
      subjectTag: store.profile.currentSubject || 'General Tutoring',
      archived: false,
      messageCount: 0,
      lastMessagePreview: '',
      createdAt: now,
      updatedAt: now,
    };
    store.conversations.unshift(conv);
    conversationOwnerRegistry.set(conv.id, principalId);
  }
  const list = store.messagesByConversation[conv.id] || [];
  const now = new Date().toISOString();
  const item: ChatMessageItem = {
    id: message.id || `msg_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    conversationId: conv.id,
    role: message.role,
    content: message.content,
    sourceMode: message.sourceMode,
    modelUsed: message.modelUsed,
    attachmentName: message.attachmentName || 'none',
    attachments: message.attachments,
    errorReason: message.errorReason,
    errorCategory: message.errorCategory,
    createdAt: now,
  };
  list.push(item);
  store.messagesByConversation[conv.id] = list;

  if (
    message.role === 'user' &&
    (conv.title === 'New Tutoring Session' || conv.title === 'Study Session' || conv.title === 'New Chat') &&
    message.content.trim().length > 0
  ) {
    const clean = message.content.replace(/\s+/g, ' ').trim();
    conv.title = clean.length > 52 ? `${clean.slice(0, 52)}...` : clean;
  }

  conv.messageCount = list.length;
  conv.lastMessagePreview = message.content.replace(/\s+/g, ' ').trim().slice(0, 220);
  conv.updatedAt = now;

  store.conversations = [
    conv,
    ...store.conversations.filter((c) => c.id !== conv!.id),
  ];

  saveStore(principalId, store);
  return item;
}

export function truncateConversationFromMessage(
  principalId: string,
  conversationId: string,
  messageId: string
): ChatMessageItem[] {
  assertConversationOwnership(principalId, conversationId);
  const store = getStore(principalId);
  const list = store.messagesByConversation[conversationId] || [];
  const idx = list.findIndex((m) => m.id === messageId);
  if (idx !== -1) {
    store.messagesByConversation[conversationId] = list.slice(0, idx);
    const conv = store.conversations.find((c) => c.id === conversationId);
    if (conv) {
      const remaining = store.messagesByConversation[conversationId];
      conv.messageCount = remaining.length;
      conv.lastMessagePreview =
        remaining[remaining.length - 1]?.content.slice(0, 220) || '';
      conv.updatedAt = new Date().toISOString();
    }
    saveStore(principalId, store);
  }
  return store.messagesByConversation[conversationId] || [];
}

export function upsertTopicProgress(
  principalId: string,
  record: Omit<TopicProgressRecord, 'createdAt' | 'updatedAt'>
): TopicProgressRecord {
  const store = getStore(principalId);
  const now = new Date().toISOString();
  const idx = store.topicProgress.findIndex((t) => t.topicId === record.topicId);
  if (idx >= 0) {
    store.topicProgress[idx] = {
      ...store.topicProgress[idx],
      ...record,
      updatedAt: now,
    };
    saveStore(principalId, store);
    return store.topicProgress[idx];
  }
  const created: TopicProgressRecord = {
    ...record,
    createdAt: now,
    updatedAt: now,
  };
  store.topicProgress.push(created);
  saveStore(principalId, store);
  return created;
}

export function recordQuizSubmission(
  principalId: string,
  params: {
    attempt: Omit<QuizAttemptRecord, 'id' | 'createdAt' | 'status'>;
    newErrors: Array<Omit<ErrorLogRecord, 'id' | 'createdAt' | 'updatedAt' | 'resolved'>>;
    timeSpentMinutes: number;
  }
): {
  attempt: QuizAttemptRecord;
  topicProgress: TopicProgressRecord;
  addedErrors: ErrorLogRecord[];
} {
  const store = getStore(principalId);
  const now = new Date().toISOString();

  const attempt: QuizAttemptRecord = {
    ...params.attempt,
    id: `att_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    status: 'completed',
    createdAt: now,
  };
  store.quizAttempts.unshift(attempt);

  const existingTopic = store.topicProgress.find((t) => t.topicId === attempt.topicId);
  const bestScore = Math.max(existingTopic?.bestScore || 0, attempt.score);
  const attemptsCount = (existingTopic?.attemptsCount || 0) + 1;
  const timeSpentMinutes = (existingTopic?.timeSpentMinutes || 0) + Math.max(1, params.timeSpentMinutes);

  let nextStatus: TopicProgressRecord['status'] = 'quiz_attempted';
  if (attempt.accuracyPercent >= 85) {
    nextStatus = 'mastered';
  } else if (attempt.passed) {
    nextStatus = 'quiz_passed';
  } else if (existingTopic?.status === 'mastered' || existingTopic?.status === 'quiz_passed') {
    nextStatus = existingTopic.status;
  }

  const topicProgress = upsertTopicProgress(principalId, {
    topicId: attempt.topicId,
    subject: attempt.subject,
    status: nextStatus,
    bestScore,
    totalQuestions: attempt.total,
    attemptsCount,
    timeSpentMinutes,
  });

  store.profile.studyMinutesToday += Math.max(1, params.timeSpentMinutes);
  store.profile.totalStudyMinutes += Math.max(1, params.timeSpentMinutes);
  store.profile.updatedAt = now;

  const addedErrors: ErrorLogRecord[] = [];
  for (const errItem of params.newErrors) {
    const existingErrIdx = store.errorLog.findIndex(
      (e) => e.questionId === errItem.questionId && !e.resolved
    );
    if (existingErrIdx >= 0) {
      store.errorLog[existingErrIdx] = {
        ...store.errorLog[existingErrIdx],
        studentAnswer: errItem.studentAnswer,
        updatedAt: now,
      };
      addedErrors.push(store.errorLog[existingErrIdx]);
    } else {
      const createdErr: ErrorLogRecord = {
        ...errItem,
        id: `err_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
        resolved: false,
        createdAt: now,
        updatedAt: now,
      };
      store.errorLog.unshift(createdErr);
      errorOwnerRegistry.set(createdErr.id, principalId);
      addedErrors.push(createdErr);
    }
  }

  saveStore(principalId, store);
  return { attempt, topicProgress, addedErrors };
}

export function updateErrorLogItem(
  principalId: string,
  errorId: string,
  patch: Partial<Pick<ErrorLogRecord, 'resolved' | 'explanation' | 'mistakeType'>>
): ErrorLogRecord | null {
  assertErrorItemOwnership(principalId, errorId);
  const store = getStore(principalId);
  const idx = store.errorLog.findIndex((e) => e.id === errorId);
  if (idx === -1) return null;
  store.errorLog[idx] = {
    ...store.errorLog[idx],
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  saveStore(principalId, store);
  return store.errorLog[idx];
}

export function saveStudyNote(
  principalId: string,
  note: Omit<StudyNoteRecord, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
): StudyNoteRecord {
  if (note.id) {
    assertNoteOwnership(principalId, note.id);
  }
  const store = getStore(principalId);
  const now = new Date().toISOString();
  if (note.id) {
    const idx = store.notes.findIndex((n) => n.id === note.id);
    if (idx >= 0) {
      store.notes[idx] = {
        ...store.notes[idx],
        title: String(note.title || 'Untitled Note').slice(0, 180),
        subject: note.subject,
        topicId: String(note.topicId || 'general').slice(0, 128),
        content: String(note.content || '').slice(0, 16000),
        updatedAt: now,
      };
      saveStore(principalId, store);
      return store.notes[idx];
    }
  }
  const created: StudyNoteRecord = {
    id: `note_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    title: String(note.title || 'Untitled Note').slice(0, 180),
    subject: note.subject,
    topicId: String(note.topicId || 'general').slice(0, 128),
    content: String(note.content || '').slice(0, 16000),
    createdAt: now,
    updatedAt: now,
  };
  store.notes.unshift(created);
  noteOwnerRegistry.set(created.id, principalId);
  saveStore(principalId, store);
  return created;
}

export function deleteStudyNote(principalId: string, noteId: string): boolean {
  assertNoteOwnership(principalId, noteId);
  const store = getStore(principalId);
  const before = store.notes.length;
  store.notes = store.notes.filter((n) => n.id !== noteId);
  if (store.notes.length < before) {
    noteOwnerRegistry.delete(noteId);
  }
  saveStore(principalId, store);
  return store.notes.length < before;
}

export function registerUploadedDocument(
  principalId: string,
  doc: ChatAttachment
): ChatAttachment {
  const store = getStore(principalId);
  store.uploadedDocuments.unshift(doc);
  saveStore(principalId, store);
  return doc;
}
