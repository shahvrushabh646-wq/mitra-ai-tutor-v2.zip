import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.aistudio',
  'data',
  'uploads',
  '.vite',
  '.cache',
  'coverage',
]);

const EXCLUDED_FILES = new Set([
  '.env',
  '.env.local',
  '.env.production',
  '.env.development',
  '.DS_Store',
  'bun.lock',
  'package-lock.json',
]);

// Precomputed standard IEEE 802.3 CRC-32 lookup table
const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosDateTime(date: Date): { dosTime: number; dosDate: number } {
  const year = Math.max(1980, date.getFullYear());
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = Math.floor(date.getSeconds() / 2);

  const dosTime = ((hours & 0x1f) << 11) | ((minutes & 0x3f) << 5) | (seconds & 0x1f);
  const dosDate = (((year - 1980) & 0x7f) << 9) | ((month & 0x0f) << 5) | (day & 0x1f);
  return { dosTime, dosDate };
}

interface ZipEntryRecord {
  relPath: string;
  absPath: string;
  mtime: Date;
}

function collectProjectFiles(rootDir: string, currentDir: string, acc: ZipEntryRecord[]): void {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  entries.sort((a, b) => a.name.localeCompare(b.name));

  for (const entry of entries) {
    const name = entry.name;
    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS.has(name)) continue;
      collectProjectFiles(rootDir, path.join(currentDir, name), acc);
    } else if (entry.isFile()) {
      if (EXCLUDED_FILES.has(name)) continue;
      if (name.startsWith('.env.') && name !== '.env.example') continue;
      if (name.endsWith('.zip') || name.endsWith('.log')) continue;

      const absPath = path.join(currentDir, name);
      const stat = fs.statSync(absPath);
      // Skip unexpectedly huge binary artifacts (>10MB)
      if (stat.size > 10 * 1024 * 1024) continue;

      const relPath = path.relative(rootDir, absPath).split(path.sep).join('/');
      acc.push({
        relPath: `mitra-ai-tutor/${relPath}`,
        absPath,
        mtime: stat.mtime,
      });
    }
  }
}

/**
 * Builds a clean, portable PKZIP archive buffer of the Mitra AI Tutor codebase,
 * excluding node_modules, build artifacts, and secret .env files.
 */
export function buildProjectZipBuffer(rootDir: string): Buffer {
  const files: ZipEntryRecord[] = [];
  collectProjectFiles(rootDir, rootDir, files);

  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let localOffset = 0;

  for (const file of files) {
    const rawData = fs.readFileSync(file.absPath);
    const uncompressedSize = rawData.length;
    const checksum = crc32(rawData);

    const deflated = zlib.deflateRawSync(rawData, { level: 6 });
    const useDeflate = deflated.length < uncompressedSize;
    const payload = useDeflate ? deflated : rawData;
    const method = useDeflate ? 8 : 0; // 8 = DEFLATE, 0 = STORE
    const compressedSize = payload.length;

    const nameBuf = Buffer.from(file.relPath, 'utf8');
    const { dosTime, dosDate } = toDosDateTime(file.mtime);
    const generalPurposeFlag = 0x0800; // Bit 11 = UTF-8 filename encoding

    // Local File Header (30 bytes + filename)
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); // Signature
    localHeader.writeUInt16LE(20, 4); // Version needed (2.0)
    localHeader.writeUInt16LE(generalPurposeFlag, 6);
    localHeader.writeUInt16LE(method, 8);
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(checksum, 14);
    localHeader.writeUInt32LE(compressedSize, 18);
    localHeader.writeUInt32LE(uncompressedSize, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28); // Extra field length

    localParts.push(localHeader, nameBuf, payload);

    // Central Directory File Header (46 bytes + filename)
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); // Signature
    centralHeader.writeUInt16LE(20, 4); // Version made by
    centralHeader.writeUInt16LE(20, 6); // Version needed
    centralHeader.writeUInt16LE(generalPurposeFlag, 8);
    centralHeader.writeUInt16LE(method, 10);
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(checksum, 16);
    centralHeader.writeUInt32LE(compressedSize, 20);
    centralHeader.writeUInt32LE(uncompressedSize, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30); // Extra length
    centralHeader.writeUInt16LE(0, 32); // Comment length
    centralHeader.writeUInt16LE(0, 34); // Disk number start
    centralHeader.writeUInt16LE(0, 36); // Internal file attributes
    centralHeader.writeUInt32LE(0, 38); // External file attributes
    centralHeader.writeUInt32LE(localOffset, 42); // Relative offset of local header

    centralParts.push(centralHeader, nameBuf);

    localOffset += localHeader.length + nameBuf.length + payload.length;
  }

  const centralDirBuffer = Buffer.concat(centralParts);
  const centralDirSize = centralDirBuffer.length;
  const centralDirOffset = localOffset;

  // End of Central Directory Record (22 bytes)
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); // Signature
  eocd.writeUInt16LE(0, 4); // Number of this disk
  eocd.writeUInt16LE(0, 6); // Disk where central directory starts
  eocd.writeUInt16LE(files.length, 8); // Entries on this disk
  eocd.writeUInt16LE(files.length, 10); // Total entries
  eocd.writeUInt32LE(centralDirSize, 12); // Size of central directory
  eocd.writeUInt32LE(centralDirOffset, 16); // Offset of central directory
  eocd.writeUInt16LE(0, 20); // Comment length

  return Buffer.concat([...localParts, centralDirBuffer, eocd]);
}
