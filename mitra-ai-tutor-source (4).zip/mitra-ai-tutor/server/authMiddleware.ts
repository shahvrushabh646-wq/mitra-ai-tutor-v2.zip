import crypto from 'node:crypto';
import https from 'node:https';
import type { NextFunction, Request, Response } from 'express';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

export interface AuthenticatedPrincipal {
  /** Globally unique server namespace key: "firebase:<uid>" or "guest:<sessionId>" */
  principalId: string;
  authMode: 'firebase' | 'guest';
  uid: string;
  email?: string;
  emailVerified: boolean;
}

declare global {
  namespace Express {
    interface Request {
      principal?: AuthenticatedPrincipal;
    }
  }
}

const FIREBASE_PROJECT_ID = firebaseConfig.projectId;
const GOOGLE_CERTS_URL =
  'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

// Deterministic fallback secret so isolated guest tokens remain valid across serverless cold starts.
const GUEST_HMAC_SECRET =
  process.env.SESSION_HMAC_SECRET ||
  crypto
    .createHash('sha256')
    .update(`mitra-session-secret-${FIREBASE_PROJECT_ID}-${process.env.VERCEL_PROJECT_ID || 'v2'}`)
    .digest('hex');

let cachedGoogleCerts: Record<string, string> | null = null;
let cachedGoogleCertsExpiresAt = 0;

function fetchGooglePublicCerts(): Promise<Record<string, string>> {
  const now = Date.now();
  if (cachedGoogleCerts && now < cachedGoogleCertsExpiresAt) {
    return Promise.resolve(cachedGoogleCerts);
  }

  return new Promise((resolve, reject) => {
    const req = https.get(GOOGLE_CERTS_URL, { timeout: 5000 }, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        try {
          if (res.statusCode !== 200) {
            reject(new Error(`Failed fetching SecureToken certs (HTTP ${res.statusCode})`));
            return;
          }
          const parsed = JSON.parse(body) as Record<string, string>;
          const cacheControl = String(res.headers['cache-control'] || '');
          const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
          const ttlSeconds = maxAgeMatch ? Number(maxAgeMatch[1]) : 3600;
          cachedGoogleCerts = parsed;
          cachedGoogleCertsExpiresAt = Date.now() + ttlSeconds * 1000;
          resolve(parsed);
        } catch (err) {
          reject(err);
        }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Timed out fetching Firebase public certificates.'));
    });
  });
}

function base64UrlDecode(str: string): Buffer {
  const pad = 4 - (str.length % 4);
  const normalized = str.replace(/-/g, '+').replace(/_/g, '/') + (pad < 4 ? '='.repeat(pad) : '');
  return Buffer.from(normalized, 'base64');
}

export async function verifyFirebaseIdToken(idToken: string): Promise<AuthenticatedPrincipal> {
  const parts = idToken.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed Firebase ID token.');
  }

  const [headerB64, payloadB64, signatureB64] = parts;
  const header = JSON.parse(base64UrlDecode(headerB64).toString('utf8')) as {
    alg?: string;
    kid?: string;
  };
  const payload = JSON.parse(base64UrlDecode(payloadB64).toString('utf8')) as {
    iss?: string;
    aud?: string;
    sub?: string;
    exp?: number;
    iat?: number;
    email?: string;
    email_verified?: boolean;
  };

  if (header.alg !== 'RS256' || !header.kid) {
    throw new Error('Unsupported token algorithm or missing key ID.');
  }

  const nowSec = Math.floor(Date.now() / 1000);
  if (!payload.exp || payload.exp < nowSec - 30) {
    throw new Error('Firebase ID token has expired.');
  }
  if (payload.aud !== FIREBASE_PROJECT_ID) {
    throw new Error('Firebase ID token audience mismatch.');
  }
  if (payload.iss !== `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`) {
    throw new Error('Firebase ID token issuer mismatch.');
  }
  if (!payload.sub || typeof payload.sub !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(payload.sub)) {
    throw new Error('Invalid Firebase UID in token.');
  }

  const certs = await fetchGooglePublicCerts();
  const certPem = certs[header.kid];
  if (!certPem) {
    throw new Error('Unknown signing certificate for Firebase ID token.');
  }

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(`${headerB64}.${payloadB64}`);
  verifier.end();
  const signatureValid = verifier.verify(certPem, base64UrlDecode(signatureB64));
  if (!signatureValid) {
    throw new Error('Invalid cryptographic signature on Firebase ID token.');
  }

  return {
    principalId: `firebase:${payload.sub}`,
    authMode: 'firebase',
    uid: payload.sub,
    email: payload.email,
    emailVerified: Boolean(payload.email_verified),
  };
}

export function issueIsolatedGuestToken(existingSessionId?: string): {
  token: string;
  sessionId: string;
  principalId: string;
} {
  const cleanExisting =
    existingSessionId && /^[a-zA-Z0-9_-]{16,64}$/.test(existingSessionId)
      ? existingSessionId
      : `gst_${crypto.randomBytes(16).toString('hex')}`;

  const issuedAt = Math.floor(Date.now() / 1000);
  const body = `${cleanExisting}.${issuedAt}`;
  const sig = crypto
    .createHmac('sha256', GUEST_HMAC_SECRET)
    .update(body)
    .digest('base64url');

  return {
    token: `mitra_guest.${body}.${sig}`,
    sessionId: cleanExisting,
    principalId: `guest:${cleanExisting}`,
  };
}

export function verifyIsolatedGuestToken(token: string): AuthenticatedPrincipal {
  if (!token.startsWith('mitra_guest.')) {
    throw new Error('Not a Mitra guest session token.');
  }
  const parts = token.split('.');
  if (parts.length !== 4) {
    throw new Error('Malformed guest session token.');
  }
  const [, sessionId, issuedAtStr, providedSig] = parts;
  if (!/^[a-zA-Z0-9_-]{16,64}$/.test(sessionId)) {
    throw new Error('Invalid guest session identifier.');
  }
  const issuedAt = Number(issuedAtStr);
  if (!Number.isFinite(issuedAt) || issuedAt <= 0) {
    throw new Error('Invalid guest token timestamp.');
  }

  const expectedSig = crypto
    .createHmac('sha256', GUEST_HMAC_SECRET)
    .update(`${sessionId}.${issuedAtStr}`)
    .digest('base64url');

  const sigBufA = Buffer.from(providedSig);
  const sigBufB = Buffer.from(expectedSig);
  if (sigBufA.length !== sigBufB.length || !crypto.timingSafeEqual(sigBufA, sigBufB)) {
    throw new Error('Invalid guest session token signature.');
  }

  return {
    principalId: `guest:${sessionId}`,
    authMode: 'guest',
    uid: sessionId,
    emailVerified: false,
  };
}

function extractBearerToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    const raw = authHeader.slice(7).trim();
    if (raw.length > 0) return raw;
  }
  return null;
}

/**
 * Enforces per-user authentication and strict principal isolation on all private
 * workspace, conversation, AI streaming, and learning progress endpoints.
 */
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const token = extractBearerToken(req);
  if (!token) {
    res.status(401).json({
      error: 'Authentication required. Missing Bearer session or Firebase ID token.',
      code: 'UNAUTHENTICATED',
    });
    return;
  }

  try {
    if (token.startsWith('mitra_guest.')) {
      req.principal = verifyIsolatedGuestToken(token);
      next();
      return;
    }

    req.principal = await verifyFirebaseIdToken(token);
    next();
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Invalid authentication token.';
    res.status(401).json({
      error: `Authentication failed: ${msg}`,
      code: 'INVALID_TOKEN',
    });
  }
}

export function isValidResourceId(id: unknown): id is string {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(id);
}
